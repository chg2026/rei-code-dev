/* CHG Contractor Portal — Contractor-side JavaScript */

// ═══════════════════════════════
// AUTH
// ═══════════════════════════════
function doLogin() {
  const e = g('l-email').value, p = g('l-pw').value;
  if (!e || !p) { toast('Please enter your email and password', 'var(--coral)'); return; }
  g('login-page').style.display = 'none';
  g('app').style.display = 'block';
  g('photo-req-badge').style.display = 'inline';
  updateQuotaBadge();
  navTo('dashboard');
}
function doLogout() {
  g('app').style.display = 'none';
  g('login-page').style.display = 'flex';
}
function updateQuotaBadge() {
  const d = g('quota-display');
  if (d) d.textContent = CHG.state.quotaUsed + ' / ' + CHG.state.quotaMax + ' used';
}

// ═══════════════════════════════
// DASHBOARD
// ═══════════════════════════════
function renderCtDashboard() {
  // KPIs
  const jobs = CHG.data.jobs;
  const active = jobs.filter(j => j.status === 'active').length;
  const totalContract = jobs.filter(j => j.status !== 'bid').reduce((s, j) => s + j.contract, 0);
  const totalPaid = CHG.data.invoices.filter(i => i.status === 'paid').reduce((s, i) => s + i.amt, 0);
  const pendingInv = CHG.data.invoices.filter(i => i.status === 'pending').reduce((s, i) => s + i.amt, 0);
  const kpiEl = g('dash-kpis');
  if (kpiEl) kpiEl.innerHTML = `
    <div class="kpi"><div class="kl">Active jobs</div><div class="kv">${active}</div><div class="ks">2 in progress</div></div>
    <div class="kpi"><div class="kl">Pending invoices</div><div class="kv amber">${fmtC(pendingInv)}</div><div class="ks">2 awaiting approval</div></div>
    <div class="kpi"><div class="kl">Paid this month</div><div class="kv green">${fmtC(totalPaid)}</div><div class="ks">3 payments received</div></div>
    <div class="kpi"><div class="kl">Docs expiring</div><div class="kv red">2</div><div class="ks">COI + GL exp. Aug 1</div></div>`;

  // Active jobs
  const jobsEl = g('dash-jobs');
  if (jobsEl) jobsEl.innerHTML = jobs.filter(j => j.status === 'active' || j.status === 'upcoming').map(j => `
    <div class="fi" style="cursor:pointer" onclick="navTo('jobs')">
      <div style="flex:1">
        <div class="fi-title">${j.name}</div>
        <div class="fi-sub">${j.sub} · Due ${j.due}</div>
        ${j.progress > 0 ? `<div class="prog" style="margin-top:4px"><div class="prog-f" style="width:${j.progress}%;background:${j.progress>60?'#1D9E75':j.progress>30?'#BA7517':'#E24B4A'}"></div></div>` : ''}
      </div>
      <div style="text-align:right;flex-shrink:0">
        <div style="font-size:12px;font-weight:600;color:${j.progress>60?'var(--teal)':'var(--amber)'}">${j.progress || '—'}%</div>
        <span class="pill ${j.status==='active'?'p-blue':j.status==='upcoming'?'p-amber':'p-gray'}">${j.status}</span>
      </div>
    </div>`).join('');

  // Quote activity
  const quotesEl = g('dash-quotes');
  if (quotesEl) quotesEl.innerHTML = CHG.data.quotes.slice(0, 3).map(q => `
    <div class="fi">
      <div style="flex:1">
        <div class="fi-title">${q.num} — ${q.job}</div>
        <div class="fi-sub">${q.recip} · ${q.sent}</div>
      </div>
      <span class="pill ${q.status==='accepted'?'p-teal':q.status==='pending'?'p-amber':'p-red'}">${q.status}</span>
    </div>`).join('');

  // Activity
  const actEl = g('dash-activity');
  if (actEl) actEl.innerHTML = `
    <div class="fi"><div class="fi-dot" style="background:#D85A30"></div><div class="fi-body"><div class="fi-title">Payment of $12,500 approved — Maple Grove</div><div class="fi-time">2 days ago</div></div></div>
    <div class="fi"><div class="fi-dot" style="background:#185FA5"></div><div class="fi-body"><div class="fi-title">RFI from Marcus Reed — Unit 14B spec</div><div class="fi-time">3 days ago · <span style="color:var(--blue);cursor:pointer" onclick="navTo('messages')">Reply</span></div></div></div>
    <div class="fi"><div class="fi-dot" style="background:#BA7517"></div><div class="fi-body"><div class="fi-title">Photo update requested — Maple Grove Units 21–34</div><div class="fi-time">5 days ago · <span style="color:var(--coral);cursor:pointer" onclick="navTo('photos')">Upload now</span></div></div></div>
    <div class="fi"><div class="fi-dot" style="background:#7F77DD"></div><div class="fi-body"><div class="fi-title">New bid invitation — Birchwood Townhomes</div><div class="fi-time">1 week ago · <span style="color:var(--blue);cursor:pointer" onclick="navTo('bids')">View bid</span></div></div></div>`;

  // Compliance
  const compEl = g('dash-compliance');
  if (compEl) compEl.innerHTML = CHG.data.docs.filter(d => d.type === 'compliance').map(d => `
    <div class="crm-stat-row">
      <div>
        <div class="crm-stat-label">${d.name}</div>
        <div style="font-size:10px;color:var(--t3)">Expires: ${d.expiry}</div>
      </div>
      <span class="pill ${d.status==='current'?'p-teal':d.status==='expiring'?'p-amber':'p-red'}">${d.status==='current'?'Current':d.status==='expiring'?'Expiring soon':'Expired'}</span>
    </div>`).join('');
}

// ═══════════════════════════════
// JOBS / MINI CRM
// ═══════════════════════════════
function renderCtJobs() {
  renderJobsTab('active');
  renderCRMTab();
}

function renderJobsTab(filter) {
  const jobs = CHG.data.jobs;
  const filtered = filter === 'active' ? jobs.filter(j => j.status === 'active' || j.status === 'upcoming' || j.status === 'bid') : jobs;
  const el = g('tab-' + filter);
  if (!el) return;
  el.innerHTML = `
    <div class="g4 mb-12">
      <div class="kpi"><div class="kl">Total jobs</div><div class="kv">${jobs.length}</div></div>
      <div class="kpi"><div class="kl">Total contract value</div><div class="kv">${fmtC(jobs.reduce((s,j)=>s+j.contract,0))}</div></div>
      <div class="kpi"><div class="kl">Total invoiced</div><div class="kv">${fmtC(CHG.data.invoices.reduce((s,i)=>s+i.amt,0))}</div></div>
      <div class="kpi"><div class="kl">Total collected</div><div class="kv green">${fmtC(CHG.data.invoices.filter(i=>i.status==='paid').reduce((s,i)=>s+i.amt,0))}</div></div>
    </div>
    <div class="card">
      <div class="chd"><div class="ctitle">${filter === 'active' ? 'Active & upcoming jobs' : 'All jobs'}</div></div>
      <table class="tbl tbl-fixed">
        <thead><tr><th style="width:28%">Job / property</th><th style="width:10%">Trade</th><th style="width:12%">Contract</th><th style="width:12%">Invoiced</th><th style="width:10%">Paid</th><th style="width:12%">Progress</th><th style="width:10%">Due</th><th style="width:16%">Status / actions</th></tr></thead>
        <tbody>
          ${filtered.map(j => `
          <tr onclick="showJobDetail('${j.id}')" style="cursor:pointer">
            <td><div style="font-size:11px;font-weight:600">${j.name}</div><div style="font-size:10px;color:var(--t2)">${j.sub}</div></td>
            <td>${j.trade}</td>
            <td>${j.contract > 0 ? fmtC(j.contract) : '—'}</td>
            <td>${j.invoiced > 0 ? fmtC(j.invoiced) : '—'}</td>
            <td class="${j.paid > 0 ? 'green' : ''}">${j.paid > 0 ? fmtC(j.paid) : '—'}</td>
            <td>${j.progress > 0 ? `<div style="font-size:10px;font-weight:600;color:${j.progress>60?'var(--teal)':'var(--amber)'}">${j.progress}%</div><div class="prog"><div class="prog-f" style="width:${j.progress}%;background:${j.progress>60?'#1D9E75':'#BA7517'}"></div></div>` : '<span style="font-size:10px;color:var(--t3)">—</span>'}</td>
            <td style="font-size:10px;color:var(--t2)">${j.due}</td>
            <td>
              <span class="pill ${j.status==='active'?'p-blue':j.status==='upcoming'?'p-amber':j.status==='complete'?'p-teal':'p-purple'}">${j.status}</span>
              ${j.photoRequested ? '<div style="font-size:9px;color:var(--amber-d);margin-top:3px;font-weight:600">&#128247; Photo requested</div>' : ''}
            </td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

function renderCRMTab() {
  const el = g('tab-crm');
  if (!el) return;
  const jobs = CHG.data.jobs;
  const quotes = CHG.data.quotes;
  const invoices = CHG.data.invoices;
  const totalRevenue = invoices.filter(i => i.status === 'paid').reduce((s, i) => s + i.amt, 0);
  const outstanding = invoices.filter(i => i.status !== 'paid').reduce((s, i) => s + i.amt, 0);
  const wonQuotes = quotes.filter(q => q.status === 'accepted').length;
  const winRate = Math.round((wonQuotes / quotes.length) * 100);

  el.innerHTML = `
    <div class="g4 mb-12">
      <div class="kpi"><div class="kl">Revenue collected YTD</div><div class="kv green">${fmtC(totalRevenue)}</div></div>
      <div class="kpi"><div class="kl">Outstanding receivables</div><div class="kv amber">${fmtC(outstanding)}</div></div>
      <div class="kpi"><div class="kl">Quote win rate</div><div class="kv">${winRate}%</div><div class="ks">${wonQuotes} of ${quotes.length} won</div></div>
      <div class="kpi"><div class="kl">Active operators</div><div class="kv">1</div><div class="ks">Vestry Capital</div></div>
    </div>
    <div class="g2">
      <div class="card">
        <div class="ctitle mb-12">Job pipeline overview</div>
        ${['active','upcoming','bid','complete'].map(s => {
          const count = jobs.filter(j => j.status === s).length;
          const val = jobs.filter(j => j.status === s).reduce((sum, j) => sum + j.contract, 0);
          const colors = { active: 'p-blue', upcoming: 'p-amber', bid: 'p-purple', complete: 'p-teal' };
          return `<div class="crm-stat-row"><div style="display:flex;align-items:center;gap:8px"><span class="pill ${colors[s]}">${s}</span><span class="crm-stat-label">${count} job${count!==1?'s':''}</span></div><div class="crm-stat-val">${val > 0 ? fmtC(val) : '—'}</div></div>`;
        }).join('')}
        <div style="margin-top:12px;padding-top:12px;border-top:var(--bl);display:flex;justify-content:space-between;align-items:center">
          <span style="font-size:11px;color:var(--t2)">Total pipeline value</span>
          <span style="font-size:13px;font-weight:700;color:var(--t1)">${fmtC(jobs.reduce((s,j)=>s+j.contract,0))}</span>
        </div>
      </div>
      <div class="card">
        <div class="ctitle mb-12">Quote history summary</div>
        <div class="crm-stat-row"><div class="crm-stat-label">Total quotes sent</div><div class="crm-stat-val">${quotes.length}</div></div>
        <div class="crm-stat-row"><div class="crm-stat-label">Accepted</div><div class="crm-stat-val green">${quotes.filter(q=>q.status==='accepted').length}</div></div>
        <div class="crm-stat-row"><div class="crm-stat-label">Pending response</div><div class="crm-stat-val amber">${quotes.filter(q=>q.status==='pending').length}</div></div>
        <div class="crm-stat-row"><div class="crm-stat-label">Declined</div><div class="crm-stat-val red">${quotes.filter(q=>q.status==='declined').length}</div></div>
        <div class="crm-stat-row"><div class="crm-stat-label">Total value sent</div><div class="crm-stat-val">${fmtC(quotes.reduce((s,q)=>s+q.amt,0))}</div></div>
        <div class="crm-stat-row"><div class="crm-stat-label">Value won</div><div class="crm-stat-val green">${fmtC(quotes.filter(q=>q.status==='accepted').reduce((s,q)=>s+q.amt,0))}</div></div>
        <div style="margin-top:12px"><button class="btn btn-sm btn-p" onclick="navTo('quotes')">+ New quote</button> <button class="btn btn-sm" onclick="navTo('quote-history')" style="margin-left:6px">View all quotes</button></div>
      </div>
    </div>
    <div class="card">
      <div class="ctitle mb-12">Invoice & payment history</div>
      <table class="tbl tbl-fixed">
        <thead><tr><th style="width:14%">Invoice #</th><th style="width:30%">Job</th><th style="width:18%">Description</th><th style="width:12%">Amount</th><th style="width:12%">Date</th><th style="width:14%">Status</th></tr></thead>
        <tbody>
          ${CHG.data.invoices.map(i => `
          <tr><td style="font-size:11px;font-weight:500">${i.num}</td><td>${i.job}</td><td style="font-size:10px;color:var(--t2)">${i.desc}</td>
          <td class="${i.status==='paid'?'green':''}" style="font-weight:${i.status==='paid'?600:400}">${fmtC(i.amt)}</td>
          <td style="color:var(--t2)">${i.date}</td>
          <td><span class="pill ${i.status==='paid'?'p-teal':i.status==='approved'?'p-blue':'p-amber'}">${i.status.charAt(0).toUpperCase()+i.status.slice(1)}</span></td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

function showJobDetail(jobId) {
  const j = CHG.data.jobs.find(x => x.id === jobId);
  if (!j) return;
  const el = g('tab-active');
  if (!el) return;
  const milestones = [
    { t: 'Mobilization & material delivery', done: true, date: 'Jan 15' },
    { t: 'Units 1–20 board installation', done: true, date: 'Mar 10' },
    { t: 'Units 1–20 tape & mud', done: true, date: 'Apr 5' },
    { t: 'Units 21–34 board installation', done: true, date: 'May 20' },
    { t: 'Units 21–34 tape & mud', done: false, date: 'Jul 5' },
    { t: 'Final finish & texture', done: false, date: 'Jul 20' },
    { t: 'Punch list & completion', done: false, date: 'Jul 31' },
  ];
  el.innerHTML = `
    <button class="btn btn-sm mb-12" onclick="switchTab('jobs-tabs','active');renderJobsTab('active')">&#8592; Back to jobs</button>
    <div class="g2">
      <div>
        <div class="card mb-12">
          <div style="font-size:16px;font-weight:700;color:var(--t1);margin-bottom:3px">${j.name}</div>
          <div style="font-size:12px;color:var(--t2);margin-bottom:12px">${j.sub} · ${j.trade}</div>
          <div class="g2" style="gap:8px;margin-bottom:12px">
            <div class="kpi"><div class="kl">Contract value</div><div class="kv">${fmtC(j.contract)}</div></div>
            <div class="kpi"><div class="kl">Progress</div><div class="kv ${j.progress>60?'green':'amber'}">${j.progress}%</div></div>
            <div class="kpi"><div class="kl">Invoiced</div><div class="kv">${fmtC(j.invoiced)}</div></div>
            <div class="kpi"><div class="kl">Paid</div><div class="kv green">${fmtC(j.paid)}</div></div>
          </div>
          ${j.photoRequested ? `<div style="background:var(--amber-l);border-radius:var(--r);padding:9px 11px;margin-bottom:12px;font-size:11px;color:var(--amber-d)"><strong>&#128247; Photo update requested</strong> — Marcus Reed is requesting progress photos of this job. <span style="cursor:pointer;text-decoration:underline" onclick="navTo('photos')">Upload now &#8594;</span></div>` : ''}
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button class="btn btn-p btn-sm" onclick="openModal('update-progress-modal')">Submit progress update</button>
            <button class="btn btn-sm" onclick="openModal('invoice-modal')">Submit invoice</button>
            <button class="btn btn-sm" onclick="navTo('photos')">Upload photos</button>
            <button class="btn btn-sm" onclick="openModal('co-modal')">Change order</button>
          </div>
        </div>
        <div class="card">
          <div class="ctitle mb-12">Milestones</div>
          ${milestones.map(m => `
          <div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:var(--bl)">
            <div style="width:15px;height:15px;border-radius:50%;background:${m.done?'var(--teal-l)':'var(--bg2)'};border:.5px solid ${m.done?'#9FE1CB':'rgba(0,0,0,.12)'};display:flex;align-items:center;justify-content:center;flex-shrink:0">
              ${m.done?'<svg width="8" height="8" viewBox="0 0 8 8" fill="none"><path d="M1.5 4l2 2 3-3" stroke="#085041" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>':''}
            </div>
            <span style="font-size:11px;color:${m.done?'var(--t2)':'var(--t1)'};${m.done?'text-decoration:line-through':''}; flex:1">${m.t}</span>
            <span style="font-size:10px;color:var(--t3)">${m.date}</span>
          </div>`).join('')}
        </div>
      </div>
      <div>
        <div class="card mb-12">
          <div class="ctitle mb-12">Job messages</div>
          ${CHG.data.messages.filter(m => m.jobId === j.id).map(m => `
          <div class="fi" style="cursor:pointer" onclick="navTo('messages')">
            <div class="av av-s ${m.withAv}">${m.withInitials}</div>
            <div class="fi-body">
              <div class="fi-title">${m.subject}</div>
              <div class="fi-time">${m.with} · ${m.date}</div>
            </div>
            ${m.unread ? '<div style="width:7px;height:7px;border-radius:50%;background:var(--coral);flex-shrink:0;margin-top:4px"></div>' : ''}
          </div>`).join('') || '<div style="font-size:11px;color:var(--t3);text-align:center;padding:16px 0">No messages for this job yet</div>'}
          <button class="btn btn-sm" style="margin-top:8px;width:100%" onclick="navTo('messages')">Open all messages &#8594;</button>
        </div>
        <div class="card mb-12">
          <div class="ctitle mb-12">Recent photos</div>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px">
            ${[{c:'#E1F5EE',p:'Board install',n:8},{c:'#E6F1FB',p:'Tape & mud',n:5},{c:'#FAEEDA',p:'Finish',n:3}].map(ph=>`
            <div style="background:${ph.c};border-radius:var(--r);aspect-ratio:1;display:flex;align-items:center;justify-content:center;cursor:pointer;position:relative" onclick="navTo('photos')">
              <span style="font-size:10px;color:var(--t2);text-align:center;padding:4px">${ph.p}</span>
              <span style="position:absolute;top:3px;right:3px;background:rgba(0,0,0,.15);color:var(--t1);font-size:9px;padding:1px 4px;border-radius:4px">${ph.n}</span>
            </div>`).join('')}
          </div>
          <button class="btn btn-sm" style="margin-top:8px;width:100%" onclick="navTo('photos')">Upload more photos &#8594;</button>
        </div>
        <div class="card">
          <div class="ctitle mb-12">Quotes for this job</div>
          ${CHG.data.quotes.filter(q => q.job.toLowerCase().includes(j.name.split(' ')[0].toLowerCase())).map(q => `
          <div class="crm-stat-row">
            <div><div style="font-size:11px;font-weight:500">${q.num}</div><div style="font-size:10px;color:var(--t2)">${q.sent}</div></div>
            <div style="text-align:right"><div style="font-size:12px;font-weight:600">${fmtC(q.amt)}</div><span class="pill ${q.status==='accepted'?'p-teal':q.status==='pending'?'p-amber':'p-red'}">${q.status}</span></div>
          </div>`).join('') || '<div style="font-size:11px;color:var(--t3);text-align:center;padding:12px 0">No quotes sent for this job yet</div>'}
          <button class="btn btn-sm btn-p" style="margin-top:8px" onclick="navTo('quotes')">+ Send new quote</button>
        </div>
      </div>
    </div>`;
}

// ═══════════════════════════════
// BIDS
// ═══════════════════════════════
function renderBids() {
  const kpis = g('bids-kpis');
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Open invitations</div><div class="kv amber">2</div></div>
    <div class="kpi"><div class="kl">Submitted bids</div><div class="kv">3</div></div>
    <div class="kpi"><div class="kl">Won this year</div><div class="kv green">5</div></div>`;
  const openTbody = g('bids-open-tbody');
  if (openTbody) openTbody.innerHTML = `
    <tr>
      <td><div style="font-size:11px;font-weight:600">Birchwood Townhomes</div><div style="font-size:10px;color:var(--t2)">Boise ID · 22 units · Drywall</div></td>
      <td>Drywall</td><td>$28K–$35K</td>
      <td style="color:var(--amber);font-weight:600">Jul 5</td>
      <td><button class="btn btn-sm btn-p" onclick="openModal('bid-modal');document.getElementById('bid-project').value='Birchwood Townhomes — Drywall'">Submit bid</button> <button class="btn btn-sm" onclick="navTo('quotes')">Send quote instead</button></td>
    </tr>
    <tr>
      <td><div style="font-size:11px;font-weight:600">Lakeview Commons</div><div style="font-size:10px;color:var(--t2)">Nashville TN · 94 units · Drywall</div></td>
      <td>Drywall</td><td>$85K–$110K</td>
      <td>Jul 20</td>
      <td><button class="btn btn-sm btn-p" onclick="openModal('bid-modal');document.getElementById('bid-project').value='Lakeview Commons — Drywall'">Submit bid</button></td>
    </tr>`;
  const subTbody = g('bids-submitted-tbody');
  if (subTbody) subTbody.innerHTML = `
    <tr><td>Maple Grove Apartments</td><td>$32,000</td><td>Jan 10</td><td><span class="pill p-teal">Awarded</span></td><td style="font-size:10px;color:var(--teal)">Jan 15 · Won &#10003;</td></tr>
    <tr><td>Riverside SFR</td><td>$9,600</td><td>Mar 5</td><td><span class="pill p-teal">Awarded</span></td><td style="font-size:10px;color:var(--teal)">Mar 10 · Won &#10003;</td></tr>
    <tr><td>Harborview Flats</td><td>$47,500</td><td>Jun 1</td><td><span class="pill p-amber">Under review</span></td><td style="font-size:10px;color:var(--t2)">Pending decision</td></tr>`;
}

function submitBid() {
  const amt = g('bid-amt').value;
  if (!amt) { toast('Please enter your bid amount', 'var(--coral)'); return; }
  closeModal('bid-modal');
  toast('Bid proposal submitted — operator will review and respond via portal');
}

// ═══════════════════════════════
// QUOTE BUILDER
// ═══════════════════════════════
function renderQuoteBuilder() {
  renderLineItems();
  recalcQuote();
  syncPreview();
  g('quote-send-btn').style.display = 'block';
  updateQuotaWarning();
}

function updateQuotaWarning() {
  const qw = g('quota-warning');
  const qud = g('quota-used-display');
  const qul = g('quota-upgrade-link');
  const S = CHG.state;
  if (!qw) return;
  const recip = S.recipType;
  if (recip === 'operator') {
    qw.style.display = 'none';
  } else {
    qw.style.display = 'block';
    if (qud) qud.textContent = S.quotaUsed;
    if (S.quotaUsed >= S.quotaMax) {
      qw.firstElementChild.style.background = 'var(--red-l)';
      qw.firstElementChild.style.color = 'var(--red)';
    }
  }
}

function selRecip(type) {
  if (type !== 'operator' && CHG.state.quotaUsed >= CHG.state.quotaMax) {
    openModal('upgrade-gate-modal');
    return;
  }
  CHG.state.recipType = type;
  ['op', 'ct', 'cl'].forEach(t => {
    const el = g('tile-' + t);
    if (!el) return;
    el.className = 'tier-card';
    if ((t === 'op' && type === 'operator') || (t === 'ct' && type === 'contractor') || (t === 'cl' && type === 'client')) {
      el.classList.add(t === 'op' ? 'sel-teal' : t === 'ct' ? 'sel-blue' : 'sel-coral');
    }
  });
  const rf = g('recip-field');
  const pf = g('prev-footer');
  const pr = g('prev-recip');
  const msgs = {
    operator: `<div style="background:var(--teal-l);border-radius:var(--r);padding:9px 11px;font-size:11px;color:var(--teal-d)">Sending to <strong>Vestry Capital (Marcus Reed)</strong> — free &amp; unlimited. Lands in operator portal automatically.</div>`,
    contractor: `<div style="background:var(--blue-l);border-radius:var(--r);padding:9px 11px">
      <div style="font-size:11px;font-weight:600;color:var(--blue-d);margin-bottom:6px">Contractor details — they will receive a text &amp; email with a link to view and sign up</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <div class="field" style="margin-bottom:0"><label>Company / name</label><input type="text" id="recip-name" placeholder="e.g. Southwest Wall Co." oninput="if(document.getElementById('prev-recip'))document.getElementById('prev-recip').textContent=this.value||'[Contractor name]'"></div>
        <div class="field" style="margin-bottom:0"><label>Phone number</label><input type="tel" id="recip-phone" placeholder="(555) 555-5555"></div>
        <div class="field" style="margin-bottom:0"><label>Email (optional)</label><input type="email" id="recip-email" placeholder="contractor@email.com"></div>
        <div class="field" style="margin-bottom:0"><label>Trade</label><select><option>Drywall</option><option>HVAC</option><option>Electrical</option><option>Flooring</option><option>Plumbing</option><option>Painting</option><option>Other</option></select></div>
      </div>
      <div style="margin-top:8px;font-size:10px;color:var(--blue-d)">They receive a text + email with a secure link. They sign up with phone # to view &amp; accept the quote. They get a full CHG Contractor Portal account. You become their operator.</div>
    </div>`,
    client: `<div style="background:var(--coral-l);border-radius:var(--r);padding:9px 11px">
      <div style="font-size:11px;font-weight:600;color:var(--coral-d);margin-bottom:6px">Client details — they receive an SMS link and sign up with phone number to view the quote</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <div class="field" style="margin-bottom:0"><label>Client name</label><input type="text" id="recip-client-name" placeholder="e.g. John Smith" oninput="if(document.getElementById('prev-recip'))document.getElementById('prev-recip').textContent=this.value||'[Client name]'"></div>
        <div class="field" style="margin-bottom:0"><label>Phone number</label><input type="tel" id="recip-client-phone" placeholder="(555) 555-5555"></div>
        <div class="field" style="margin-bottom:0"><label>Email (optional)</label><input type="email" placeholder="client@email.com"></div>
        <div class="field" style="margin-bottom:0"><label>Job address</label><input type="text" placeholder="123 Main St, City ST"></div>
      </div>
      <div style="margin-top:8px;font-size:10px;color:var(--coral-d)">Client receives SMS with a secure quote link. They sign up with phone # to view &amp; sign. No portal account — client view only. Quote footer shows CHG Contractor Portal branding.</div>
    </div>`,
  };
  if (rf) rf.innerHTML = msgs[type] || '';
  if (pf) pf.style.display = type === 'client' ? 'block' : 'none';
  if (pr && type === 'operator') pr.textContent = 'Vestry Capital — Marcus Reed';
  if (pr && type !== 'operator') pr.textContent = type === 'contractor' ? '[Contractor name]' : '[Client name]';
  updateQuotaWarning();
}

function addLineItem() {
  CHG.state.lineItems.push({ id: CHG.state.nextLineId++, desc: '', qty: 1, price: 0 });
  renderLineItems();
}
function removeLineItem(id) {
  CHG.state.lineItems = CHG.state.lineItems.filter(l => l.id !== id);
  renderLineItems();
  recalcQuote();
}
function renderLineItems() {
  const el = g('line-items');
  if (!el) return;
  el.innerHTML = CHG.state.lineItems.map(l => `
    <div class="li-grid">
      <input class="li-inp" type="text" value="${l.desc}" placeholder="Description of work or material" oninput="CHG.state.lineItems.find(x=>x.id===${l.id}).desc=this.value;syncPreview()">
      <input class="li-inp" type="number" value="${l.qty}" min="0" step="0.01" style="text-align:right" oninput="CHG.state.lineItems.find(x=>x.id===${l.id}).qty=parseFloat(this.value)||0;recalcQuote()">
      <input class="li-inp" type="number" value="${l.price}" min="0" step="0.01" placeholder="0.00" style="text-align:right" oninput="CHG.state.lineItems.find(x=>x.id===${l.id}).price=parseFloat(this.value)||0;recalcQuote()">
      <div class="li-tot" id="lt-${l.id}">${fmtCDec(l.qty * l.price)}</div>
      <button class="del-btn" onclick="removeLineItem(${l.id})">&#215;</button>
    </div>`).join('');
  recalcQuote();
}

function syncPreview() {
  const wt = g('q-warranty');
  if (wt) {
    const wp = g('prev-warranty');
    if (wp) wp.textContent = wt.value || '—';
  }
  // Call shared syncPreview
  if (typeof window.syncPreviewBase === 'function') window.syncPreviewBase();
  else {
    const S = CHG.state;
    const items = S.lineItems;
    const sub = items.reduce((s, l) => s + (l.qty * l.price), 0);
    const taxRate = (parseFloat((g('q-tax') || {}).value || 0)) / 100;
    const taxAmt = sub * taxRate;
    const total = sub + taxAmt;
    const set = (id, val) => { const el = g(id); if (el) el.textContent = val; };
    set('prev-title', (g('q-title') || {}).value || 'QUOTE');
    set('prev-num', (g('q-num') || {}).value || '—');
    const exp = (g('q-expiry') || {}).value;
    if (exp) { try { set('prev-date', 'Valid until: ' + new Date(exp + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })); } catch(e) {} }
    const jobEl = g('q-job');
    set('prev-job', jobEl ? (jobEl.options[jobEl.selectedIndex] || {}).text : '');
    set('prev-scope', (g('q-scope') || {}).value || '');
    set('prev-notes', (g('q-notes') || {}).value || '');
    const termsEl = g('q-terms');
    set('prev-terms', termsEl ? (termsEl.options[termsEl.selectedIndex] || {}).text : '');
    set('prev-sub', fmtCDec(sub));
    set('prev-tax', fmtCDec(taxAmt));
    set('prev-total', fmtCDec(total));
    const tbody = g('prev-tbody');
    if (tbody) tbody.innerHTML = items.map(l => `
      <tr>
        <td style="padding:5px 7px;font-size:11px;border-bottom:.5px solid rgba(0,0,0,.06)">${l.desc || '—'}</td>
        <td style="padding:5px 7px;font-size:11px;text-align:right;border-bottom:.5px solid rgba(0,0,0,.06)">${l.qty}</td>
        <td style="padding:5px 7px;font-size:11px;text-align:right;border-bottom:.5px solid rgba(0,0,0,.06)">${fmtCDec(l.price)}</td>
        <td style="padding:5px 7px;font-size:11px;font-weight:600;text-align:right;border-bottom:.5px solid rgba(0,0,0,.06)">${fmtCDec(l.qty * l.price)}</td>
      </tr>`).join('');
  }
}

function openSendFlow() {
  const tot = CHG.state.lineItems.reduce((s, l) => s + (l.qty * l.price), 0);
  const title = (g('q-title') || {}).value || 'Quote';
  const type = CHG.state.recipType;

  if (type !== 'operator' && CHG.state.quotaUsed >= CHG.state.quotaMax) {
    openModal('upgrade-gate-modal'); return;
  }

  g('send-modal-title').textContent = type === 'operator' ? 'Send to Vestry Capital' : type === 'contractor' ? 'Send to contractor' : 'Send to client';

  const bodyMap = {
    operator: `
      <div style="background:var(--teal-l);border-radius:var(--r);padding:10px;margin-bottom:12px">
        <div style="font-size:11px;font-weight:600;color:var(--teal-d);margin-bottom:2px">${title}</div>
        <div style="font-size:12px;color:var(--teal-d)">Total: <strong>${fmtCDec(tot)}</strong> — to Marcus Reed, Vestry Capital</div>
      </div>
      <div style="font-size:11px;color:var(--t2);margin-bottom:12px;line-height:1.55">This quote will appear in Marcus Reed's <strong>Received Quotes</strong> inbox immediately. He can review, approve, and respond from the operator portal.</div>
      <div class="field"><label>Message to operator (optional)</label><textarea placeholder="Hi Marcus, please find my quote for this scope..." rows="3">Hi Marcus, please find attached my quote for the Birchwood Townhomes drywall scope. Happy to discuss any questions before the July 5 deadline.</textarea></div>
      <div style="display:flex;gap:8px"><button class="btn btn-teal" style="flex:1" onclick="sendQuote('operator')">Send to Vestry Capital</button><button class="btn" onclick="closeModal('send-modal')">Cancel</button></div>`,
    contractor: `
      <div style="background:var(--blue-l);border-radius:var(--r);padding:10px;margin-bottom:12px">
        <div style="font-size:11px;font-weight:600;color:var(--blue-d);margin-bottom:2px">${title}</div>
        <div style="font-size:12px;color:var(--blue-d)">Total: <strong>${fmtCDec(tot)}</strong> — ${CHG.state.quotaMax - CHG.state.quotaUsed - 1} free quote${CHG.state.quotaMax - CHG.state.quotaUsed - 1 !== 1 ? 's' : ''} remaining after this</div>
      </div>
      <div style="font-size:11px;color:var(--t2);margin-bottom:12px;line-height:1.55">The contractor will receive a <strong>text message and email</strong> with a secure link. They sign up with their phone number to view and accept the quote. They get a full CHG Contractor Portal account — and you become their operator.</div>
      <div class="field"><label>Message (optional)</label><textarea placeholder="Add a personal note..." rows="2"></textarea></div>
      <div style="display:flex;gap:8px"><button class="btn btn-b" style="flex:1" onclick="sendQuote('contractor')">Send via text &amp; email</button><button class="btn" onclick="closeModal('send-modal')">Cancel</button></div>`,
    client: `
      <div style="background:var(--coral-l);border-radius:var(--r);padding:10px;margin-bottom:12px">
        <div style="font-size:11px;font-weight:600;color:var(--coral-d);margin-bottom:2px">${title}</div>
        <div style="font-size:12px;color:var(--coral-d)">Total: <strong>${fmtCDec(tot)}</strong> — ${CHG.state.quotaMax - CHG.state.quotaUsed - 1} free quote${CHG.state.quotaMax - CHG.state.quotaUsed - 1 !== 1 ? 's' : ''} remaining after this</div>
      </div>
      <div style="font-size:11px;color:var(--t2);margin-bottom:12px;line-height:1.55">The client will receive a <strong>text message</strong> with a secure link to view their quote. They sign up with their phone number to view and sign. The quote footer will display <strong>CHG Contractor Portal</strong> branding.</div>
      <div class="field"><label>Message to client (optional)</label><textarea placeholder="Hi [Name], here is your quote for..." rows="2"></textarea></div>
      <div style="display:flex;gap:8px"><button class="btn btn-p" style="flex:1" onclick="sendQuote('client')">Send via SMS</button><button class="btn" onclick="closeModal('send-modal')">Cancel</button></div>`,
  };

  g('send-modal-body').innerHTML = bodyMap[type] || '';
  openModal('send-modal');
}

function sendQuote(type) {
  closeModal('send-modal');
  const tot = CHG.state.lineItems.reduce((s, l) => s + (l.qty * l.price), 0);
  if (type !== 'operator') CHG.state.quotaUsed++;
  updateQuotaBadge();
  CHG.data.quotes.unshift({
    num: 'QTE-2025-0' + (CHG.data.quotes.length + 14),
    job: (g('q-job') || { options: [{ text: 'New project' }], selectedIndex: 0 }).options[(g('q-job') || { selectedIndex: 0 }).selectedIndex]?.text || 'New project',
    recip: type === 'operator' ? 'Vestry Capital' : type === 'contractor' ? (g('recip-name') || { value: '[Contractor]' }).value || '[Contractor]' : (g('recip-client-name') || { value: '[Client]' }).value || '[Client]',
    recipType: type, amt: Math.round(tot), sent: 'Just now', status: 'pending', viewed: false,
  });
  const msgs = {
    operator: 'Quote sent to Vestry Capital — appears in operator portal now',
    contractor: 'Quote sent via text & email — they will receive a link to view and sign up',
    client: 'Quote sent via SMS — client will receive a secure link to view and sign',
  };
  toast(msgs[type] || 'Quote sent', type === 'operator' ? 'var(--teal)' : type === 'contractor' ? 'var(--blue)' : 'var(--coral)');
  updateQuotaWarning();
}

// ═══════════════════════════════
// QUOTE HISTORY
// ═══════════════════════════════
function renderQuoteHistory() {
  const kpis = g('qh-kpis');
  const quotes = CHG.data.quotes;
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Total sent</div><div class="kv">${quotes.length}</div></div>
    <div class="kpi"><div class="kl">Accepted</div><div class="kv green">${quotes.filter(q=>q.status==='accepted').length}</div><div class="ks">${fmtC(quotes.filter(q=>q.status==='accepted').reduce((s,q)=>s+q.amt,0))} won</div></div>
    <div class="kpi"><div class="kl">Pending</div><div class="kv amber">${quotes.filter(q=>q.status==='pending').length}</div></div>
    <div class="kpi"><div class="kl">Win rate</div><div class="kv">${Math.round(quotes.filter(q=>q.status==='accepted').length/quotes.length*100)}%</div></div>`;
  filterQuoteHistory('all');
}
function filterQuoteHistory(type) {
  const tbody = g('qh-tbody');
  if (!tbody) return;
  const quotes = type === 'all' ? CHG.data.quotes : CHG.data.quotes.filter(q => q.recipType === type);
  const tpPill = { operator: 'p-teal', contractor: 'p-blue', client: 'p-coral' };
  const tpLabel = { operator: 'Operator', contractor: 'Contractor', client: 'Client' };
  const stPill = { accepted: 'p-teal', pending: 'p-amber', declined: 'p-red' };
  tbody.innerHTML = quotes.map(q => `
    <tr>
      <td style="font-size:11px;font-weight:600">${q.num}</td>
      <td>${q.job}</td>
      <td><div style="font-size:11px">${q.recip}</div><span class="pill ${tpPill[q.recipType]}" style="font-size:9px">${tpLabel[q.recipType]}</span></td>
      <td style="font-weight:600">${fmtC(q.amt)}</td>
      <td style="color:var(--t2)">${q.sent}</td>
      <td><span class="pill ${stPill[q.status]}">${q.status.charAt(0).toUpperCase() + q.status.slice(1)}</span></td>
      <td>
        <span style="font-size:10px;color:var(--blue);cursor:pointer" onclick="toast('Quote PDF downloaded')">&#8595; PDF</span>
        ${q.status === 'pending' ? '<span style="font-size:10px;color:var(--t3);margin-left:6px;cursor:pointer" onclick="toast(\'Reminder sent to recipient\')">Remind</span>' : ''}
        ${q.status === 'accepted' && q.recipType !== 'client' ? '<span style="font-size:10px;color:var(--teal);margin-left:6px;cursor:pointer" onclick="toast(\'Converting quote to invoice...\')">&#8594; Invoice</span>' : ''}
      </td>
    </tr>`).join('');
}

// ═══════════════════════════════
// DOCUMENTS
// ═══════════════════════════════
function renderDocs() {
  CHG.state.docFilter = 'all';
  renderDocTable(CHG.data.docs);
}
function setDocFilter(f, el) {
  CHG.state.docFilter = f;
  document.querySelectorAll('#doc-filter-list .li-item').forEach(i => i.classList.remove('on'));
  el.classList.add('on');
  let docs = CHG.data.docs;
  if (f !== 'all') {
    if (f === 'expiring' || f === 'expired') docs = docs.filter(d => d.status === f);
    else docs = docs.filter(d => d.type === f);
  }
  renderDocTable(docs);
  const h = g('docs-heading');
  if (h) h.textContent = (f === 'all' ? 'All documents' : f.charAt(0).toUpperCase() + f.slice(1)) + ' — ' + docs.length + ' file' + (docs.length !== 1 ? 's' : '');
}
function filterDocsSearch(q) {
  const docs = q ? CHG.data.docs.filter(d => d.name.toLowerCase().includes(q.toLowerCase())) : CHG.data.docs;
  renderDocTable(docs);
}
function renderDocTable(docs) {
  const tbody = g('docs-tbody');
  if (!tbody) return;
  const sMap = { current: 'p-teal', expiring: 'p-amber', expired: 'p-red' };
  const sLabel = { current: 'Current', expiring: 'Expiring soon', expired: 'Expired' };
  tbody.innerHTML = docs.map(d => `
    <tr>
      <td style="font-size:11px;font-weight:500">${d.name}</td>
      <td><span class="pill p-blue" style="font-size:9px">${d.type}</span></td>
      <td style="font-size:11px;color:var(--t2)">${d.expiry}</td>
      <td><span class="pill ${sMap[d.status]}">${sLabel[d.status]}</span></td>
      <td>
        <span style="font-size:10px;color:var(--blue);cursor:pointer" onclick="toast('${d.file} downloaded')">&#8595; Download</span>
        <span style="font-size:10px;color:var(--t3);margin-left:8px;cursor:pointer" onclick="openModal('upload-doc-modal')">&#8593; Update</span>
      </td>
    </tr>`).join('');
}

// ═══════════════════════════════
// PHOTOS
// ═══════════════════════════════
function renderPhotos() {
  g('upload-photo-btn').style.display = 'block';
  const kpis = g('photo-kpis');
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Total uploaded</div><div class="kv">47</div></div>
    <div class="kpi"><div class="kl">This week</div><div class="kv">12</div></div>
    <div class="kpi"><div class="kl">Photo request</div><div class="kv amber">1</div><div class="ks">Maple Grove · Due Jul 5</div></div>`;
  const grid = g('photo-grid');
  if (grid) grid.innerHTML = CHG.data.photos.map(p => `
    <div class="photo-thumb" onclick="toast('Photo viewer — ${p.phase}')">
      <div class="photo-thumb-bg" style="background:${p.color}">${p.phase}</div>
      <div class="photo-count">${p.count}</div>
      ${p.requested ? '<div class="photo-request-badge">Requested</div>' : ''}
    </div>`).join('');
}
function uploadPhotos() {
  closeModal('upload-photo-modal');
  const badge = g('photo-req-badge');
  if (badge) badge.style.display = 'none';
  const reqCard = g('photo-request-card');
  if (reqCard) reqCard.style.display = 'none';
  CHG.data.photos[0].count += 4;
  CHG.data.photos[0].requested = false;
  toast('Photos uploaded and operator notified — Marcus Reed will review shortly', 'var(--teal)');
  renderPhotos();
}

// ═══════════════════════════════
// INVOICES
// ═══════════════════════════════
function renderInvoices() {
  const kpis = g('inv-kpis');
  const invoices = CHG.data.invoices;
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Total invoiced</div><div class="kv">${fmtC(invoices.reduce((s,i)=>s+i.amt,0))}</div></div>
    <div class="kpi"><div class="kl">Paid</div><div class="kv green">${fmtC(invoices.filter(i=>i.status==='paid').reduce((s,i)=>s+i.amt,0))}</div></div>
    <div class="kpi"><div class="kl">Pending approval</div><div class="kv amber">${fmtC(invoices.filter(i=>i.status==='pending').reduce((s,i)=>s+i.amt,0))}</div></div>
    <div class="kpi"><div class="kl">Approved, unpaid</div><div class="kv">${fmtC(invoices.filter(i=>i.status==='approved').reduce((s,i)=>s+i.amt,0))}</div></div>`;
  const tbody = g('inv-tbody');
  if (tbody) tbody.innerHTML = invoices.map(i => `
    <tr>
      <td style="font-size:11px;font-weight:600">${i.num}</td>
      <td>${i.job}</td>
      <td style="font-size:10px;color:var(--t2)">${i.desc}</td>
      <td style="font-weight:600;color:${i.status==='paid'?'var(--teal)':'var(--t1)'}">${fmtC(i.amt)}</td>
      <td style="color:var(--t2)">${i.date}</td>
      <td><span class="pill ${i.status==='paid'?'p-teal':i.status==='approved'?'p-blue':'p-amber'}">${i.status.charAt(0).toUpperCase()+i.status.slice(1)}</span></td>
    </tr>`).join('');
}
function submitInvoice() {
  const amt = g('inv-amt').value;
  if (!amt) { toast('Please enter an invoice amount', 'var(--coral)'); return; }
  CHG.data.invoices.unshift({
    num: 'INV-2025-0' + (Math.floor(Math.random() * 9) + 10),
    job: 'Maple Grove Apartments', desc: 'New submission',
    amt: parseFloat(amt), date: 'Today', status: 'pending',
  });
  closeModal('invoice-modal');
  renderInvoices();
  toast('Invoice submitted — operator will review within 2 business days');
}

// ═══════════════════════════════
// MESSAGES
// ═══════════════════════════════
function renderMessages() {
  renderMsgList(CHG.data.messages);
  if (!CHG.state.selectedMsg) selectMsg(1);
  g('msg-badge').style.display = 'none';
}
function filterMsgsByJob(jobFilter) {
  const msgs = jobFilter === 'all' ? CHG.data.messages : CHG.data.messages.filter(m => m.jobId === jobFilter);
  renderMsgList(msgs);
}
function renderMsgList(msgs) {
  const el = g('msg-thread-list');
  if (!el) return;
  el.innerHTML = msgs.map(m => `
    <div class="li-item${CHG.state.selectedMsg === m.id ? ' on' : ''}" onclick="selectMsg(${m.id})">
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:5px;margin-bottom:2px">
          <span style="font-size:9px;font-weight:600;padding:1px 5px;border-radius:4px;background:var(--coral-l);color:var(--coral-d)">${m.job}</span>
          ${m.unread ? '<div style="width:6px;height:6px;border-radius:50%;background:var(--coral);flex-shrink:0"></div>' : ''}
        </div>
        <div style="font-size:11px;font-weight:${m.unread ? 600 : 400};color:var(--t1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${m.subject}</div>
        <div style="font-size:10px;color:var(--t3)">${m.with} · ${m.date}</div>
      </div>
    </div>`).join('');
}
function selectMsg(id) {
  CHG.state.selectedMsg = id;
  const m = CHG.data.messages.find(x => x.id === id);
  if (!m) return;
  m.unread = false;
  const detail = g('msg-detail');
  if (!detail) return;
  detail.style.display = 'flex';
  detail.innerHTML = `
    <div style="padding:14px 16px;border-bottom:var(--bl);flex-shrink:0">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">
        <div>
          <div style="font-size:13px;font-weight:700;color:var(--t1);margin-bottom:3px">${m.subject}</div>
          <div style="font-size:11px;color:var(--t2)">${m.job} · ${m.with} · ${m.date}</div>
        </div>
        <button class="btn btn-sm" onclick="toast('Message archived')">Archive</button>
      </div>
    </div>
    <div class="msg-area" id="msg-bubble-area">
      ${m.thread.map(t => `
        <div class="${t.fromMe ? 'text-right' : ''}">
          <div class="msg-bubble ${t.fromMe ? 'msg-out' : 'msg-in'}">${t.msg}</div>
          <div class="msg-time ${t.fromMe ? 'msg-time-out' : ''}">${t.time}</div>
        </div>`).join('')}
    </div>
    <div class="msg-input-row">
      <textarea id="reply-box" style="flex:1;padding:8px 10px;border:var(--bm);border-radius:var(--r);font-size:11px;color:var(--t1);background:var(--bg1);resize:none;height:54px;font-family:inherit;outline:none" placeholder="Type your reply to ${m.with}..."></textarea>
      <div style="display:flex;flex-direction:column;gap:5px">
        <button class="btn btn-p btn-sm" onclick="sendReply(${m.id})">Send</button>
        <button class="btn btn-sm" onclick="toast('Photo attached to message')" title="Attach photo">&#128247;</button>
      </div>
    </div>`;
  renderMsgList(CHG.data.messages);
  // Scroll to bottom
  const area = g('msg-bubble-area');
  if (area) area.scrollTop = area.scrollHeight;
}
function sendReply(id) {
  const box = g('reply-box');
  if (!box || !box.value.trim()) { toast('Type a message first', 'var(--coral)'); return; }
  const m = CHG.data.messages.find(x => x.id === id);
  if (!m) return;
  m.thread.push({ from: 'Mike Torres', fromMe: true, msg: box.value.trim(), time: 'Just now' });
  selectMsg(id);
  toast('Message sent to ' + m.with);
}

// ═══════════════════════════════
// PAGE GUARDS
// ═══════════════════════════════
const _navTo = navTo;
window.navTo = function(p) {
  // Hide buttons that only show on specific pages
  const qsb = g('quote-send-btn');
  const upb = g('upload-photo-btn');
  if (qsb) qsb.style.display = p === 'quotes' ? 'block' : 'none';
  if (upb) upb.style.display = p === 'photos' ? 'block' : 'none';
  _navTo(p);
};

// INIT
document.addEventListener('DOMContentLoaded', () => {
  g('login-page').style.display = 'flex';
  g('app').style.display = 'none';
});
