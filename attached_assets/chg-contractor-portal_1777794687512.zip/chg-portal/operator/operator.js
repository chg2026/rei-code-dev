/* CHG Contractor Portal — Operator-side JavaScript */

function doLogin() {
  const e = g('l-email').value, p = g('l-pw').value;
  if (!e || !p) { toast('Please enter your credentials', 'var(--red)'); return; }
  g('login-page').style.display = 'none';
  g('app').style.display = 'block';
  navTo('op-dashboard');
}
function doLogout() {
  g('app').style.display = 'none';
  g('login-page').style.display = 'flex';
}
function handleOpAction() {
  const p = document.querySelector('.ni.on')?.dataset.p;
  const map = { 'op-jobs': 'new-job-modal', 'op-bids': 'new-bid-modal', 'op-onboarding': 'onboard-modal' };
  if (map[p]) openModal(map[p]);
  else toast('Action triggered');
}

// ═══════════════════════════════
// DASHBOARD
// ═══════════════════════════════
function renderOpDashboard() {
  const kpis = g('op-dash-kpis');
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Active contractors</div><div class="kv">18</div><div class="ks">across 6 trades</div></div>
    <div class="kpi"><div class="kl">Open work orders</div><div class="kv">11</div><div class="ks">3 behind schedule</div></div>
    <div class="kpi"><div class="kl">Pending invoices</div><div class="kv amber">4</div><div class="ks">${fmtC(CHG.data.opInvoices.reduce((s,i)=>s+i.amt,0))} awaiting</div></div>
    <div class="kpi"><div class="kl">Compliance alerts</div><div class="kv red">4</div><div class="ks">docs expiring / missing</div></div>`;

  const quotesEl = g('op-dash-quotes');
  if (quotesEl) quotesEl.innerHTML = CHG.data.opQuotes.filter(q => q.status === 'pending').map(q => `
    <div class="fi">
      <div style="display:flex;align-items:center;gap:7px;flex:1">
        <div class="av av-s ${q.fromAv}">${q.from.split(' ').map(w=>w[0]).join('')}</div>
        <div class="fi-body">
          <div class="fi-title">${q.from} — ${q.job}</div>
          <div class="fi-sub">${q.num} · ${fmtC(q.amt)} · Received ${q.sent}</div>
        </div>
      </div>
      ${!q.viewed ? '<span class="pill p-coral" style="font-size:9px;flex-shrink:0">New</span>' : ''}
      <button class="btn btn-sm btn-b" style="flex-shrink:0" onclick="navTo('op-quotes')">Review</button>
    </div>`).join('') || '<div style="font-size:11px;color:var(--t3);text-align:center;padding:16px 0">No pending quotes</div>';

  const jobsEl = g('op-dash-jobs');
  if (jobsEl) jobsEl.innerHTML = `
    <div class="fi">
      <div style="flex:1"><div class="fi-title">Maple Grove — HVAC</div><div class="fi-sub">Cruz HVAC · Due Jun 30 — overdue · 45% complete</div><div class="prog" style="margin-top:4px"><div class="prog-f" style="width:45%;background:#E24B4A"></div></div></div>
      <span class="pill p-red" style="flex-shrink:0">Behind</span>
    </div>
    <div class="fi">
      <div style="flex:1"><div class="fi-title">Riverside — Flooring</div><div class="fi-sub">Premier Floors · COI expires Jul 15 · 60% complete</div><div class="prog" style="margin-top:4px"><div class="prog-f" style="width:60%;background:#BA7517"></div></div></div>
      <span class="pill p-amber" style="flex-shrink:0">Doc expiring</span>
    </div>
    <div class="fi">
      <div style="flex:1"><div class="fi-title">Commerce Park — Electrical</div><div class="fi-sub">Peak Electric · Invoice pending 5 days · Complete</div></div>
      <button class="btn btn-sm" onclick="navTo('op-invoices')">Approve inv.</button>
    </div>`;

  const compEl = g('op-dash-compliance');
  if (compEl) compEl.innerHTML = `
    <div class="fi"><div class="fi-dot" style="background:var(--red)"></div><div class="fi-body"><div class="fi-title">Cruz HVAC — COI expires in 5 days</div><div class="fi-sub">Certificate of insurance · Exp Aug 1, 2025</div></div><button class="btn btn-sm" onclick="toast('Reminder sent to Cruz HVAC')">Remind</button></div>
    <div class="fi"><div class="fi-dot" style="background:var(--amber)"></div><div class="fi-body"><div class="fi-title">Premier Floors — COI expires in 15 days</div></div><button class="btn btn-sm" onclick="toast('Reminder sent to Premier Floors')">Remind</button></div>
    <div class="fi"><div class="fi-dot" style="background:var(--amber)"></div><div class="fi-body"><div class="fi-title">Torres Drywall — W-9 not on file</div></div><button class="btn btn-sm" onclick="toast('W-9 request sent to Torres Drywall')">Request</button></div>
    <div class="fi"><div class="fi-dot" style="background:var(--amber)"></div><div class="fi-body"><div class="fi-title">Peak Electric — License expires in 30 days</div></div><button class="btn btn-sm" onclick="toast('Reminder sent to Peak Electric')">Remind</button></div>`;

  const invEl = g('op-dash-invoices');
  if (invEl) invEl.innerHTML = CHG.data.opInvoices.map(i => `
    <div class="fi">
      <div style="display:flex;align-items:center;gap:7px;flex:1">
        <div class="av av-s ${i.av}">${i.ct.split(' ').map(w=>w[0]).join('')}</div>
        <div class="fi-body"><div class="fi-title">${i.ct} — ${i.job}</div><div class="fi-sub">${fmtC(i.amt)} · Submitted ${i.date} · ${i.days}d ago</div></div>
      </div>
      <button class="btn btn-sm btn-teal" onclick="approveInv(this,'${i.ct}')">Approve</button>
    </div>`).join('');
}

// ═══════════════════════════════
// RECEIVED QUOTES
// ═══════════════════════════════
function renderOpQuotes() {
  const kpis = g('opq-kpis');
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Total received</div><div class="kv">${CHG.data.opQuotes.length}</div></div>
    <div class="kpi"><div class="kl">Pending review</div><div class="kv amber">${CHG.data.opQuotes.filter(q=>q.status==='pending').length}</div></div>
    <div class="kpi"><div class="kl">Accepted</div><div class="kv green">${CHG.data.opQuotes.filter(q=>q.status==='accepted').length}</div></div>`;
  const tbody = g('opq-tbody');
  if (!tbody) return;
  const sp = { pending: 'p-amber', accepted: 'p-teal', declined: 'p-red' };
  tbody.innerHTML = CHG.data.opQuotes.map(q => `
    <tr onclick="navTo('op-quotes')" style="cursor:pointer">
      <td style="font-size:11px;font-weight:600">${q.num}${!q.viewed?'<span class="pill p-coral" style="font-size:9px;margin-left:5px">New</span>':''}</td>
      <td><div style="display:flex;align-items:center;gap:6px"><div class="av av-s ${q.fromAv}">${q.from.split(' ').map(w=>w[0]).join('')}</div>${q.from}</div></td>
      <td>${q.job}</td>
      <td style="font-weight:600">${fmtC(q.amt)}</td>
      <td class="muted">${q.sent}</td>
      <td><span class="pill ${sp[q.status]}">${q.status.charAt(0).toUpperCase()+q.status.slice(1)}</span></td>
      <td><button class="btn btn-sm ${q.status==='pending'?'btn-b':''}" onclick="q.status==='pending'?approveQuote():toast('Quote already processed')">${q.status==='pending'?'Review':'View'}</button></td>
    </tr>`).join('');
  // Mark all as viewed
  CHG.data.opQuotes.forEach(q => q.viewed = true);
  const badge = g('op-quote-badge');
  if (badge) badge.style.display = 'none';
}

function approveQuote() {
  const q = CHG.data.opQuotes.find(x => x.status === 'pending');
  if (q) q.status = 'accepted';
  toast('Quote accepted — work order created and contractor notified', 'var(--teal)');
  renderOpQuotes();
}
function rejectQuote() {
  const q = CHG.data.opQuotes.find(x => x.status === 'pending');
  if (q) q.status = 'declined';
  toast('Quote declined — contractor notified', 'var(--red)');
  renderOpQuotes();
}

// ═══════════════════════════════
// CONTRACTOR CRM
// ═══════════════════════════════
function renderOpCRM() {
  CHG.state.ctFilter = 'all';
  renderOpCRMList(CHG.data.contractors);
}
function filterOpCRM(q) {
  const items = q ? CHG.data.contractors.filter(c => c.name.toLowerCase().includes(q.toLowerCase()) || c.contact.toLowerCase().includes(q.toLowerCase())) : CHG.data.contractors;
  renderOpCRMList(items);
}
function setOpCRMFilter(f, el) {
  CHG.state.ctFilter = f;
  ['crmf-all','crmf-active','crmf-prospect'].forEach(id => {
    const b = g(id); if (!b) return;
    b.style.borderColor = 'rgba(0,0,0,.15)'; b.style.color = 'var(--t2)';
  });
  el.style.borderColor = 'var(--blue)'; el.style.color = 'var(--blue)';
  const items = f === 'all' ? CHG.data.contractors : CHG.data.contractors.filter(c => c.status === f);
  renderOpCRMList(items);
}
function renderOpCRMList(items) {
  const el = g('op-crm-list');
  if (!el) return;
  el.innerHTML = items.map(c => `
    <div class="li-item${CHG.state.selCRM === c.id ? ' on' : ''}" onclick="selectOpCRM('${c.id}')">
      <div class="av av-s ${c.av}">${c.id}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:11px;font-weight:600;color:var(--t1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${c.name}</div>
        <div style="font-size:10px;color:var(--t2)">${c.trade} · ${c.jobs} job${c.jobs!==1?'s':''}</div>
      </div>
      <span class="pill ${c.status==='active'?'p-teal':'p-amber'}" style="font-size:9px">${c.status}</span>
    </div>`).join('');
  const fc = g('crm-footer-count');
  if (fc) fc.textContent = items.length + ' contractor' + (items.length!==1?'s':'') + ' · ' + items.filter(c=>c.status==='active').length + ' active';
}
function selectOpCRM(id) {
  CHG.state.selCRM = id;
  const c = CHG.data.contractors.find(x => x.id === id);
  if (!c) return;
  const coiColor = c.coi === 'Current' ? 'var(--teal)' : c.coi === 'Expiring' ? 'var(--amber)' : 'var(--red)';
  const coiPill = c.coi === 'Current' ? 'p-teal' : c.coi === 'Expiring' ? 'p-amber' : 'p-red';
  const detail = g('op-crm-detail');
  if (!detail) return;
  detail.innerHTML = `
    <div class="card mb-12">
      <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:12px">
        <div class="av av-l ${c.av}">${c.id}</div>
        <div style="flex:1">
          <div style="font-size:15px;font-weight:700;color:var(--t1);margin-bottom:2px">${c.name}</div>
          <div style="font-size:11px;color:var(--t2);margin-bottom:6px">${c.trade} · ${c.loc}</div>
          <div style="display:flex;gap:6px"><span class="pill ${c.status==='active'?'p-teal':'p-amber'}">${c.status}</span><span class="pill p-blue">${c.trade}</span></div>
        </div>
        <div style="display:flex;gap:6px">
          <button class="btn btn-sm btn-b" onclick="toast('Message sent to ${c.name}')">+ Message</button>
          <button class="btn btn-sm" onclick="openModal('new-job-modal')">Assign job</button>
        </div>
      </div>
      <div class="g3" style="padding-top:12px;border-top:var(--bl)">
        <div><div style="font-size:10px;color:var(--t2);margin-bottom:2px">Email</div><div style="font-size:11px;color:var(--blue)">${c.email}</div></div>
        <div><div style="font-size:10px;color:var(--t2);margin-bottom:2px">Phone</div><div style="font-size:11px">${c.phone}</div></div>
        <div><div style="font-size:10px;color:var(--t2);margin-bottom:2px">Jobs · Rating</div><div style="font-size:11px;font-weight:600">${c.jobs} · ${c.rating} &#9733;</div></div>
      </div>
    </div>
    <div class="g4 mb-12">
      <div class="kpi"><div class="kl">YTD spend</div><div class="kv">${fmtC(c.ytd)}</div></div>
      <div class="kpi"><div class="kl">Rating</div><div class="kv">${c.rating} &#9733;</div></div>
      <div class="kpi"><div class="kl">COI</div><div class="kv" style="font-size:14px;color:${coiColor}">${c.coi}</div></div>
      <div class="kpi"><div class="kl">W-9</div><div class="kv" style="font-size:14px;color:${c.w9==='On file'?'var(--teal)':'var(--red)'}">${c.w9}</div></div>
    </div>
    <div class="card mb-12">
      <div class="ctitle mb-12">Compliance documents</div>
      <div class="crm-stat-row"><div class="crm-stat-label">Certificate of Insurance</div><span class="pill ${coiPill}">${c.coi}</span></div>
      <div class="crm-stat-row"><div class="crm-stat-label">W-9 on file</div><span class="pill ${c.w9==='On file'?'p-teal':'p-red'}">${c.w9}</span></div>
      <div class="crm-stat-row"><div class="crm-stat-label">Contractor license</div><span class="pill ${c.lic==='Current'?'p-teal':'p-amber'}">${c.lic}</span></div>
      <button class="btn btn-sm" style="margin-top:10px;width:100%" onclick="toast('Compliance reminder sent to ${c.name}')">Send compliance reminder</button>
    </div>
    <div class="card">
      <div class="ctitle mb-12">Internal notes</div>
      <textarea style="width:100%;padding:8px;border:var(--bm);border-radius:var(--r);font-size:11px;color:var(--t1);background:var(--bg1);resize:vertical;min-height:70px;font-family:inherit;outline:none" placeholder="Add private notes about this contractor...">Reliable drywall contractor. Preferred vendor for multifamily renovations. Prefers 50% upfront.</textarea>
      <button class="btn btn-sm btn-b" style="margin-top:8px" onclick="toast('Notes saved for ${c.name}')">Save notes</button>
    </div>`;
  renderOpCRMList(CHG.data.contractors);
}

// ═══════════════════════════════
// JOB MANAGEMENT
// ═══════════════════════════════
function renderOpJobs() {
  const kpis = g('opj-kpis');
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Total jobs</div><div class="kv">11</div></div>
    <div class="kpi"><div class="kl">On track</div><div class="kv green">8</div></div>
    <div class="kpi"><div class="kl">At risk</div><div class="kv amber">2</div></div>
    <div class="kpi"><div class="kl">Behind</div><div class="kv red">1</div></div>`;
  const stages = [
    { id: 'scoping', label: 'Scoping' },
    { id: 'awarded', label: 'Awarded' },
    { id: 'active', label: 'Active' },
    { id: 'complete', label: 'Complete' },
  ];
  const tradeColors = { Drywall: 'p-coral', HVAC: 'p-blue', Electrical: 'p-teal', Flooring: 'p-amber', Plumbing: 'p-purple' };
  const kanban = g('op-jobs-kanban');
  if (!kanban) return;
  kanban.innerHTML = stages.map(s => {
    const jobs = CHG.data.pipelineJobs.filter(j => j.stage === s.id);
    return `<div class="kcol">
      <div class="kch"><span>${s.label}</span><span style="background:var(--bg1);padding:1px 5px;border-radius:4px;font-size:9px">${jobs.length}</span></div>
      ${jobs.map(j => `
      <div class="kc" onclick="toast('${j.name} — full detail in dev build')">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:3px">
          <span class="pill ${tradeColors[j.trade]||'p-gray'}" style="font-size:9px">${j.trade}</span>
          <span style="font-size:10px;font-weight:600">${j.val}</span>
        </div>
        <div style="font-size:11px;font-weight:600;color:var(--t1);margin-bottom:1px">${j.name}</div>
        <div style="font-size:10px;color:var(--t2);margin-bottom:${j.prog!==undefined?'5px':'0'}">${j.ct}</div>
        ${j.prog !== undefined ? `<div style="font-size:10px;font-weight:600;color:${j.prog===100?'var(--teal)':j.prog<50?'var(--amber)':'var(--blue)'}">${j.prog}%</div><div class="prog"><div class="prog-f" style="width:${j.prog}%;background:${j.prog===100?'#1D9E75':j.prog<50?'#BA7517':'#378ADD'}"></div></div>` : ''}
        ${j.stage === 'active' ? `<button class="btn btn-sm" style="margin-top:6px;font-size:9px" onclick="event.stopPropagation();toast('Photo update request sent to ${j.ct}')">&#128247; Request photos</button>` : ''}
      </div>`).join('')}
      <div class="kc-add" onclick="openModal('new-job-modal')">+ Add job</div>
    </div>`;
  }).join('');
}

// ═══════════════════════════════
// BIDS
// ═══════════════════════════════
function renderOpBids() {
  const kpis = g('opb-kpis');
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Active invitations</div><div class="kv">3</div></div>
    <div class="kpi"><div class="kl">Proposals received</div><div class="kv">5</div></div>
    <div class="kpi"><div class="kl">Awaiting award</div><div class="kv amber">2</div></div>`;
  const openTbody = g('opb-open-tbody');
  if (openTbody) openTbody.innerHTML = `
    <tr><td><div style="font-size:11px;font-weight:600">Birchwood Townhomes</div><div style="font-size:10px;color:var(--t2)">Boise ID · 22 units</div></td><td>Drywall</td><td>$28K–$35K</td><td style="color:var(--amber);font-weight:600">Jul 5</td><td>3 of 5</td><td><button class="btn btn-sm btn-b" onclick="toast('Comparison view open')">Compare proposals</button> <button class="btn btn-sm" onclick="toast('Reminder sent to 2 pending contractors')">Remind</button></td></tr>
    <tr><td><div style="font-size:11px;font-weight:600">Lakeview Commons</div><div style="font-size:10px;color:var(--t2)">Nashville TN · 94 units</div></td><td>Drywall</td><td>$85K–$110K</td><td>Jul 20</td><td>1 of 6</td><td><button class="btn btn-sm" onclick="toast('Reminder sent to 5 contractors')">Send reminder</button></td></tr>
    <tr><td><div style="font-size:11px;font-weight:600">Lakeview Commons</div><div style="font-size:10px;color:var(--t2)">Nashville TN · 94 units</div></td><td>HVAC</td><td>$45K–$60K</td><td>Jul 20</td><td>2 of 4</td><td><button class="btn btn-sm btn-b" onclick="toast('Comparison view open')">Compare proposals</button></td></tr>`;
  const compareTbody = g('opb-compare-tbody');
  if (compareTbody) compareTbody.innerHTML = `
    <tr><td><div style="display:flex;align-items:center;gap:6px"><div class="av av-s a-coral">MT</div><span style="font-size:11px;font-weight:600">Torres Drywall</span></div></td><td style="font-weight:700;color:var(--teal)">$29,800</td><td>28 days</td><td>4.8 &#9733;</td><td><span class="pill p-teal">Compliant</span></td><td><button class="btn btn-sm btn-b" onclick="awardBid('Torres Drywall','$29,800')">Award job</button> <span class="pill p-teal" style="font-size:9px">Recommended</span></td></tr>
    <tr><td><div style="display:flex;align-items:center;gap:6px"><div class="av av-s a-blue">SW</div><span style="font-size:11px">Southwest Wall Co.</span></div></td><td>$31,500</td><td>35 days</td><td>4.2 &#9733;</td><td><span class="pill p-teal">Compliant</span></td><td><button class="btn btn-sm" onclick="awardBid('Southwest Wall Co.','$31,500')">Award job</button></td></tr>
    <tr><td><div style="display:flex;align-items:center;gap:6px"><div class="av av-s a-amber">PB</div><span style="font-size:11px">ProBoard Inc.</span></div></td><td>$34,200</td><td>30 days</td><td>3.9 &#9733;</td><td><span class="pill p-amber">COI expiring</span></td><td><button class="btn btn-sm" onclick="awardBid('ProBoard Inc.','$34,200')">Award job</button></td></tr>`;
}
function awardBid(name, amt) {
  CHG.data.pipelineJobs.push({ stage: 'awarded', name: 'Birchwood — Drywall', ct: name, val: amt, trade: 'Drywall' });
  toast(name + ' awarded — work order created and contractor notified via portal and SMS', 'var(--teal)');
  renderOpBids();
}

// ═══════════════════════════════
// COMPLIANCE
// ═══════════════════════════════
function renderOpCompliance() {
  const kpis = g('opc-kpis');
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Compliant</div><div class="kv green">14</div></div>
    <div class="kpi"><div class="kl">Expiring soon</div><div class="kv amber">3</div></div>
    <div class="kpi"><div class="kl">Expired / missing</div><div class="kv red">1</div></div>
    <div class="kpi"><div class="kl">Pending review</div><div class="kv">2</div></div>`;
  const tbody = g('opc-tbody');
  if (!tbody) return;
  const sMap = { Current: 'p-teal', 'On file': 'p-teal', Expiring: 'p-amber', 'Expiring soon': 'p-amber', Missing: 'p-red', 'Not submitted': 'p-red', Expired: 'p-red', 'Not on file': 'p-red' };
  tbody.innerHTML = CHG.data.contractors.map(c => {
    const bad = [c.coi, c.w9, c.lic].some(s => ['Expired','Missing','Not submitted','Not on file'].includes(s));
    const warn = [c.coi, c.w9, c.lic].some(s => ['Expiring','Expiring soon'].includes(s));
    const overall = bad ? 'p-red' : warn ? 'p-amber' : 'p-teal';
    const ol = bad ? 'Non-compliant' : warn ? 'Action needed' : 'Compliant';
    return `<tr>
      <td><div style="display:flex;align-items:center;gap:6px"><div class="av av-s ${c.av}">${c.id}</div><div><div style="font-size:11px;font-weight:600">${c.name}</div></div></div></td>
      <td style="font-size:10px;color:var(--t2)">${c.trade}</td>
      <td><span class="pill ${sMap[c.coi]||'p-gray'}">${c.coi}</span></td>
      <td><span class="pill ${sMap[c.w9]||'p-gray'}">${c.w9}</span></td>
      <td><span class="pill ${sMap[c.lic]||'p-gray'}">${c.lic}</span></td>
      <td><span class="pill ${overall}">${ol}</span></td>
      <td><span style="font-size:10px;color:var(--blue);cursor:pointer" onclick="toast('Reminder sent to ${c.name}')">Remind</span> <span style="font-size:10px;color:var(--t3);margin-left:6px;cursor:pointer" onclick="toast('Viewing docs for ${c.name}')">Docs</span></td>
    </tr>`;
  }).join('');
}
function sendBulkReminders() {
  toast('Bulk compliance reminders sent to all non-compliant contractors', 'var(--blue)');
}

// ═══════════════════════════════
// INVOICES
// ═══════════════════════════════
function renderOpInvoices() {
  const kpis = g('opi-kpis');
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Pending approval</div><div class="kv amber">${CHG.data.opInvoices.length}</div><div class="ks">${fmtC(CHG.data.opInvoices.reduce((s,i)=>s+i.amt,0))}</div></div>
    <div class="kpi"><div class="kl">Approved this month</div><div class="kv">12</div><div class="ks">$148,500</div></div>
    <div class="kpi"><div class="kl">Paid this month</div><div class="kv green">10</div><div class="ks">$124,000</div></div>
    <div class="kpi"><div class="kl">Outstanding</div><div class="kv">$24,500</div><div class="ks">approved, not paid</div></div>`;
  renderOpInvTable();
}
function renderOpInvTable() {
  const tbody = g('opi-pending-tbody');
  if (!tbody) return;
  tbody.innerHTML = CHG.data.opInvoices.map(i => `
    <tr>
      <td><div style="display:flex;align-items:center;gap:6px"><div class="av av-s ${i.av}">${i.ct.split(' ').map(w=>w[0]).join('')}</div><span style="font-size:11px">${i.ct}</span></div></td>
      <td style="font-size:11px">${i.job}</td>
      <td style="font-weight:600">${fmtC(i.amt)}</td>
      <td style="font-size:11px;color:var(--t2)">${i.date}<br><span style="font-size:10px;color:${i.days>14?'var(--red)':i.days>7?'var(--amber)':'var(--t3)'}">${i.days}d ago</span></td>
      <td><span class="pill p-amber">Pending</span></td>
      <td>
        <button class="btn btn-sm btn-teal" onclick="approveInv(this,'${i.ct}')">Approve</button>
        <button class="btn btn-sm" style="margin-left:4px;color:var(--red)" onclick="toast('Invoice rejected — note sent to ${i.ct}')">Reject</button>
      </td>
    </tr>`).join('');
}
function approveInv(btn, ct) {
  const row = btn.closest('tr');
  if (row) row.remove();
  CHG.data.opInvoices = CHG.data.opInvoices.filter(i => i.ct !== ct || CHG.data.opInvoices.indexOf(i) !== 0);
  toast(ct + ' invoice approved — marked for payment', 'var(--teal)');
}

// ═══════════════════════════════
// ONBOARDING
// ═══════════════════════════════
function renderOpOnboarding() {
  const kpis = g('opo-kpis');
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">In progress</div><div class="kv amber">2</div></div>
    <div class="kpi"><div class="kl">Completed this month</div><div class="kv green">2</div></div>
    <div class="kpi"><div class="kl">Awaiting documents</div><div class="kv">1</div></div>`;
  const tbody = g('opo-tbody');
  if (!tbody) return;
  const sp = { Complete: 'p-teal', 'Under review': 'p-blue', 'In progress': 'p-amber', 'Awaiting docs': 'p-red' };
  tbody.innerHTML = CHG.data.onboarding.map(o => `
    <tr>
      <td style="font-size:11px;font-weight:600">${o.name}</td>
      <td style="font-size:11px">${o.trade}</td>
      <td style="font-size:11px;color:var(--t2)">${o.invited}</td>
      <td><span class="pill ${o.w9==='Submitted'?'p-teal':'p-amber'}">${o.w9}</span></td>
      <td><span class="pill ${o.coi==='Submitted'?'p-teal':'p-amber'}">${o.coi}</span></td>
      <td><span class="pill ${sp[o.status]||'p-gray'}">${o.status}</span></td>
    </tr>`).join('');
}

// ═══════════════════════════════
// MESSAGES (OPERATOR SIDE)
// ═══════════════════════════════
function renderOpMessages() {
  const el = g('op-msg-list');
  if (!el) return;
  el.innerHTML = CHG.data.messages.map(m => `
    <div class="li-item${CHG.state.selectedMsg === m.id ? ' on' : ''}" onclick="selectOpMsg(${m.id})">
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:5px;margin-bottom:2px">
          <span style="font-size:9px;font-weight:600;padding:1px 5px;border-radius:4px;background:var(--blue-l);color:var(--blue-d)">${m.job}</span>
          ${m.unread ? '<div style="width:6px;height:6px;border-radius:50%;background:var(--blue);flex-shrink:0"></div>' : ''}
        </div>
        <div style="font-size:11px;font-weight:${m.unread?600:400};color:var(--t1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${m.subject}</div>
        <div style="font-size:10px;color:var(--t3)">Torres Drywall · ${m.date}</div>
      </div>
    </div>`).join('');
  if (!CHG.state.selectedMsg) selectOpMsg(1);
}
function selectOpMsg(id) {
  CHG.state.selectedMsg = id;
  const m = CHG.data.messages.find(x => x.id === id);
  if (!m) return;
  const detail = g('op-msg-detail');
  if (!detail) return;
  detail.style.display = 'flex';
  detail.innerHTML = `
    <div style="padding:14px 16px;border-bottom:var(--bl);flex-shrink:0">
      <div style="font-size:13px;font-weight:700;color:var(--t1);margin-bottom:3px">${m.subject}</div>
      <div style="font-size:11px;color:var(--t2)">Torres Drywall · ${m.job} · ${m.date}</div>
    </div>
    <div class="msg-area" id="op-msg-bubbles">
      ${m.thread.map(t => `
      <div class="${!t.fromMe ? 'text-right' : ''}">
        <div class="msg-bubble ${!t.fromMe ? 'msg-out' : 'msg-in'}" style="${!t.fromMe ? 'background:var(--blue);' : ''}">${t.msg}</div>
        <div class="msg-time ${!t.fromMe ? 'msg-time-out' : ''}">${t.time}</div>
      </div>`).join('')}
    </div>
    <div class="msg-input-row">
      <textarea id="op-reply-box" style="flex:1;padding:8px 10px;border:var(--bm);border-radius:var(--r);font-size:11px;color:var(--t1);background:var(--bg1);resize:none;height:54px;font-family:inherit;outline:none" placeholder="Reply to Torres Drywall..."></textarea>
      <div style="display:flex;flex-direction:column;gap:5px">
        <button class="btn btn-b btn-sm" onclick="sendOpReply(${m.id})">Send</button>
        <button class="btn btn-sm" onclick="toast('Photo attached')" title="Attach">&#128247;</button>
      </div>
    </div>`;
  renderOpMessages();
  const area = g('op-msg-bubbles');
  if (area) area.scrollTop = area.scrollHeight;
}
function sendOpReply(id) {
  const box = g('op-reply-box');
  if (!box || !box.value.trim()) { toast('Type a message first', 'var(--coral)'); return; }
  const m = CHG.data.messages.find(x => x.id === id);
  if (!m) return;
  m.thread.push({ from: 'Marcus Reed', fromMe: false, msg: box.value.trim(), time: 'Just now' });
  selectOpMsg(id);
  toast('Message sent to Torres Drywall', 'var(--blue)');
}

// ═══════════════════════════════
// REPORTING
// ═══════════════════════════════
function renderOpReporting() {
  const kpis = g('opr-kpis');
  if (kpis) kpis.innerHTML = `
    <div class="kpi"><div class="kl">Total spend YTD</div><div class="kv">$428,500</div><div class="ks">vs $480K budget</div></div>
    <div class="kpi"><div class="kl">Active contractors</div><div class="kv">18</div><div class="ks">6 trade types</div></div>
    <div class="kpi"><div class="kl">Jobs completed</div><div class="kv green">24</div><div class="ks">YTD 2025</div></div>
    <div class="kpi"><div class="kl">Avg cost variance</div><div class="kv green">-3.2%</div><div class="ks">under budget avg</div></div>`;
  const bars = g('op-trade-bars');
  if (!bars) return;
  const trades = [
    { n: 'HVAC', a: 142000, c: '#378ADD' }, { n: 'Drywall', a: 118000, c: '#D85A30' },
    { n: 'Electrical', a: 89000, c: '#1D9E75' }, { n: 'Flooring', a: 52000, c: '#BA7517' },
    { n: 'Plumbing', a: 27500, c: '#534AB7' },
  ];
  const max = Math.max(...trades.map(t => t.a));
  bars.innerHTML = trades.map(t => `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
      <div style="font-size:10px;color:var(--t2);width:72px;flex-shrink:0">${t.n}</div>
      <div style="flex:1;height:18px;background:var(--bg2);border-radius:3px;overflow:hidden">
        <div style="height:100%;background:${t.c};width:${Math.round((t.a/max)*100)}%;border-radius:3px;display:flex;align-items:center;padding-left:6px">
          <span style="font-size:9px;font-weight:600;color:#fff">$${Math.round(t.a/1000)}K</span>
        </div>
      </div>
    </div>`).join('');
}

// ═══════════════════════════════
// SETTINGS
// ═══════════════════════════════
function renderOpSettings() {}

function toggleSetting(btn, label) {
  btn.classList.toggle('on');
  const isOn = btn.classList.contains('on');
  toast(label + ' ' + (isOn ? 'enabled' : 'disabled'), isOn ? 'var(--teal)' : 'var(--t2)');
}

// ═══════════════════════════════
// INIT
// ═══════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  g('login-page').style.display = 'flex';
  g('app').style.display = 'none';
});
