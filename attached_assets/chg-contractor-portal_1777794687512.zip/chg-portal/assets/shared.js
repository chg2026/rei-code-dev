/* CHG Contractor Portal — Shared Data & Utilities */

const CHG = {
  version: '1.0.0',
  brand: 'CHG Contractor Portal',
  brandShort: 'CHG',
  supportEmail: 'support@chgportal.com',

  // Shared state
  state: {
    quotaUsed: 1,
    quotaMax: 3,
    planType: 'free', // 'free' | 'pro'
    messagingEnabled: true,
    contractorMessagingEnabled: true,
    selectedMsg: null,
    selectedCRM: null,
    selectedJob: null,
    docFilter: 'all',
    ctFilter: 'all',
    recipType: 'operator',
    lineItems: [
      { id: 1, desc: 'Labor — framing and drywall board installation', qty: 220, price: 45 },
      { id: 2, desc: 'Drywall board — 5/8" type X, 22 units', qty: 880, price: 18 },
      { id: 3, desc: 'Taping, mudding and finishing', qty: 220, price: 32 },
      { id: 4, desc: 'Materials — compound, tape, screws', qty: 1, price: 1800 },
    ],
    nextLineId: 5,
  },

  // Data
  data: {
    contractor: {
      name: 'Mike Torres',
      company: 'Torres Drywall LLC',
      initials: 'MT',
      email: 'mike@torresdrywall.com',
      phone: '(310) 555-0142',
      license: 'CA-DW-48291',
      trade: 'Drywall',
    },
    operator: {
      name: 'Marcus Reed',
      company: 'Vestry Capital',
      initials: 'MR',
      email: 'marcus@vestrycapital.com',
    },
    jobs: [
      { id: 'maple', name: 'Maple Grove Apartments', sub: 'Austin TX · 48 units', trade: 'Drywall', contract: 32000, progress: 68, invoiced: 21760, paid: 12500, due: 'Jul 31, 2025', status: 'active', photoRequested: true },
      { id: 'riverside', name: 'Riverside SFR — 3 Units', sub: 'Phoenix AZ · 3 homes', trade: 'Drywall', contract: 9600, progress: 25, invoiced: 2400, paid: 2400, due: 'Aug 15, 2025', status: 'active', photoRequested: false },
      { id: 'commerce', name: 'Commerce Park NW', sub: 'Portland OR · Office suite', trade: 'Drywall', contract: 14800, progress: 0, invoiced: 0, paid: 0, due: 'Sep 30, 2025', status: 'upcoming', photoRequested: false },
      { id: 'birchwood', name: 'Birchwood Townhomes', sub: 'Boise ID · 22 units', trade: 'Drywall', contract: 0, progress: 0, invoiced: 0, paid: 0, due: 'TBD', status: 'bid', photoRequested: false },
      { id: 'elm', name: 'Elm Street Duplex', sub: 'Denver CO', trade: 'Drywall', contract: 8400, progress: 100, invoiced: 8400, paid: 8400, due: 'Mar 2025', status: 'complete', photoRequested: false },
      { id: 'harbor', name: 'Harborview Flats', sub: 'San Diego CA', trade: 'Drywall', contract: 47500, progress: 0, invoiced: 0, paid: 0, due: 'TBD', status: 'bid', photoRequested: false },
    ],
    invoices: [
      { num: 'INV-2025-007', job: 'Maple Grove Apartments', desc: 'Units 1–20 complete', amt: 9260, date: 'Jun 28', status: 'pending' },
      { num: 'INV-2025-006', job: 'Maple Grove Apartments', desc: 'Units 21–34 board', amt: 8000, date: 'Jun 10', status: 'pending' },
      { num: 'INV-2025-005', job: 'Maple Grove Apartments', desc: 'Mobilization', amt: 4500, date: 'May 15', status: 'approved' },
      { num: 'INV-2025-004', job: 'Maple Grove Apartments', desc: 'Initial payment', amt: 12500, date: 'Mar 20', status: 'paid' },
      { num: 'INV-2025-003', job: 'Riverside SFR', desc: 'Unit 1 complete', amt: 2400, date: 'Jun 5', status: 'paid' },
      { num: 'INV-2025-002', job: 'Elm Street Duplex', desc: 'Final payment', amt: 4200, date: 'Mar 10', status: 'paid' },
    ],
    quotes: [
      { num: 'QTE-2025-012', job: 'Birchwood Townhomes — Drywall', recip: 'Vestry Capital', recipType: 'operator', amt: 29800, sent: 'Jul 1, 2025', status: 'pending', viewed: false },
      { num: 'QTE-2025-011', job: 'Maple Grove — Add scope', recip: 'Vestry Capital', recipType: 'operator', amt: 4200, sent: 'Jun 25, 2025', status: 'accepted', viewed: true },
      { num: 'QTE-2025-010', job: 'Riverside SFR Units 1–3', recip: 'Vestry Capital', recipType: 'operator', amt: 9600, sent: 'Mar 5, 2025', status: 'accepted', viewed: true },
      { num: 'QTE-2025-009', job: 'Harborview Flats', recip: 'Vestry Capital', recipType: 'operator', amt: 47500, sent: 'Jun 1, 2025', status: 'pending', viewed: true },
      { num: 'QTE-2025-008', job: 'Sub — 8 home framing', recip: 'Southwest Wall Co.', recipType: 'contractor', amt: 18400, sent: 'May 20, 2025', status: 'accepted', viewed: true },
      { num: 'QTE-2025-007', job: 'Sub — Birchwood framing', recip: 'ProBoard Inc.', recipType: 'contractor', amt: 12000, sent: 'May 10, 2025', status: 'declined', viewed: true },
    ],
    docs: [
      { name: 'Certificate of Insurance', type: 'compliance', expiry: 'Aug 1, 2025', status: 'expiring', file: 'COI_Torres_2025.pdf' },
      { name: 'W-9 Form (2025)', type: 'tax', expiry: 'N/A', status: 'current', file: 'W9_Torres_2025.pdf' },
      { name: 'Contractor License — CA', type: 'compliance', expiry: 'Dec 31, 2025', status: 'current', file: 'License_CA_48291.pdf' },
      { name: 'Maple Grove — Signed Contract', type: 'contract', expiry: 'N/A', status: 'current', file: 'Contract_Maple_2025.pdf' },
      { name: 'Riverside SFR — Signed Contract', type: 'contract', expiry: 'N/A', status: 'current', file: 'Contract_Riverside_2025.pdf' },
      { name: 'Commerce Park — Signed Contract', type: 'contract', expiry: 'N/A', status: 'current', file: 'Contract_Commerce_2025.pdf' },
      { name: 'General Liability Insurance', type: 'compliance', expiry: 'Aug 1, 2025', status: 'expiring', file: 'GL_Policy_2025.pdf' },
      { name: '1099-NEC 2024', type: 'tax', expiry: 'N/A', status: 'current', file: '1099_2024.pdf' },
    ],
    messages: [
      {
        id: 1, job: 'Maple Grove', jobId: 'maple', with: 'Marcus Reed', withInitials: 'MR', withAv: 'a-blue',
        subject: 'RFI — Unit 14B ceiling spec change', date: 'Jun 28', unread: true,
        thread: [
          { from: 'Marcus Reed', fromMe: false, msg: 'Hi Mike, we need to discuss the drywall spec for unit 14B. The architect updated the ceiling height to 9ft. Please review the attached revised drawing and confirm whether this affects your contract price and timeline.', time: 'Jun 28, 2:14pm' },
          { from: 'Mike Torres', fromMe: true, msg: 'Thanks Marcus. I reviewed the drawing — the height change will require approximately $400 in additional material and 4 hours extra labor. I\'ll submit a formal change order request for $650 to cover this. Let me know if you\'d like to discuss.', time: 'Jun 28, 4:45pm' },
          { from: 'Marcus Reed', fromMe: false, msg: 'That works. Please submit the change order through the portal and I\'ll approve it this week.', time: 'Jun 29, 9:12am' },
        ]
      },
      {
        id: 2, job: 'Maple Grove', jobId: 'maple', with: 'Marcus Reed', withInitials: 'MR', withAv: 'a-blue',
        subject: 'Photo update request — Units 21–34', date: 'Jun 26', unread: true,
        thread: [
          { from: 'Marcus Reed', fromMe: false, msg: 'Hi Mike, can you send over photos of the board installation progress on units 21–34? We have an investor site visit scheduled for July 8 and need to show progress documentation.', time: 'Jun 26, 11:00am' },
        ]
      },
      {
        id: 3, job: 'Riverside SFR', jobId: 'riverside', with: 'Marcus Reed', withInitials: 'MR', withAv: 'a-blue',
        subject: 'Schedule update — start date moved to July 8', date: 'Jun 10', unread: false,
        thread: [
          { from: 'Marcus Reed', fromMe: false, msg: 'Hi Mike, we need to push the Riverside SFR start date back by one week to July 8 due to a delay in the flooring installation on units 1 and 2. Please confirm this works with your crew schedule.', time: 'Jun 10, 11:30am' },
          { from: 'Mike Torres', fromMe: true, msg: 'Confirmed — July 8 works for us. I\'ll adjust my crew schedule accordingly and have materials on-site by July 7.', time: 'Jun 10, 1:15pm' },
        ]
      },
      {
        id: 4, job: 'Birchwood', jobId: 'birchwood', with: 'Marcus Reed', withInitials: 'MR', withAv: 'a-blue',
        subject: 'Bid invitation — Birchwood Townhomes drywall scope', date: 'Jun 5', unread: false,
        thread: [
          { from: 'Marcus Reed', fromMe: false, msg: 'Hi Mike, we\'d like to invite Torres Drywall to bid on the Birchwood Townhomes project in Boise, ID. 22 units, estimated scope value $28,000–$35,000. Bid due July 5. Please log in to the portal to review the full scope documents and submit your proposal.', time: 'Jun 5, 3:00pm' },
          { from: 'Mike Torres', fromMe: true, msg: 'Thanks Marcus — I\'ll review the scope documents and have a quote to you by July 3.', time: 'Jun 5, 4:30pm' },
        ]
      },
    ],
    contractors: [
      { id: 'MT', name: 'Torres Drywall', contact: 'Mike Torres', av: 'a-coral', trade: 'Drywall', status: 'active', jobs: 5, rating: 4.8, email: 'mike@torresdrywall.com', phone: '+1 310 555 0142', loc: 'Los Angeles CA', ytd: 41600, coi: 'Expiring', w9: 'On file', lic: 'Current' },
      { id: 'CC', name: 'Cruz HVAC', contact: 'Carlos Cruz', av: 'a-blue', trade: 'HVAC', status: 'active', jobs: 3, rating: 3.8, email: 'carlos@cruzhvac.com', phone: '+1 213 555 0198', loc: 'Los Angeles CA', ytd: 78000, coi: 'Expired', w9: 'On file', lic: 'Current' },
      { id: 'SP', name: 'Peak Electric', contact: 'Sandra Peak', av: 'a-teal', trade: 'Electrical', status: 'active', jobs: 4, rating: 4.5, email: 's.peak@peakelectric.com', phone: '+1 424 555 0177', loc: 'Los Angeles CA', ytd: 52000, coi: 'Current', w9: 'On file', lic: 'Expiring' },
      { id: 'JB', name: 'Premier Floors', contact: 'James Bauer', av: 'a-amber', trade: 'Flooring', status: 'active', jobs: 4, rating: 4.6, email: 'j.bauer@premierfloors.com', phone: '+1 323 555 0155', loc: 'San Diego CA', ytd: 38400, coi: 'Current', w9: 'On file', lic: 'Current' },
      { id: 'RP', name: 'Rivera Plumbing', contact: 'Rosa Rivera', av: 'a-purple', trade: 'Plumbing', status: 'active', jobs: 2, rating: 4.3, email: 'rosa@riveraplumbing.com', phone: '+1 626 555 0111', loc: 'Phoenix AZ', ytd: 22000, coi: 'Current', w9: 'Missing', lic: 'Current' },
      { id: 'SW', name: 'Southwest Wall Co.', contact: 'Dan Howell', av: 'a-gray', trade: 'Drywall', status: 'prospect', jobs: 0, rating: 4.2, email: 'd.howell@swwallco.com', phone: '+1 602 555 0133', loc: 'Phoenix AZ', ytd: 0, coi: 'Not submitted', w9: 'Not submitted', lic: 'Current' },
    ],
    opInvoices: [
      { ct: 'Torres Drywall', av: 'a-coral', job: 'Maple Grove Apts', amt: 9260, date: 'Jun 28', days: 3 },
      { ct: 'Torres Drywall', av: 'a-coral', job: 'Maple Grove Apts', amt: 8000, date: 'Jun 10', days: 21 },
      { ct: 'Cruz HVAC', av: 'a-blue', job: 'Maple Grove — HVAC', amt: 15400, date: 'Jun 25', days: 6 },
      { ct: 'Premier Floors', av: 'a-amber', job: 'Riverside SFR', amt: 7200, date: 'Jun 20', days: 11 },
    ],
    opQuotes: [
      { num: 'QTE-2025-012', from: 'Torres Drywall', fromAv: 'a-coral', job: 'Birchwood Townhomes', amt: 29800, sent: 'Jul 1', status: 'pending', viewed: false },
      { num: 'QTE-2025-009', from: 'Torres Drywall', fromAv: 'a-coral', job: 'Harborview Flats', amt: 47500, sent: 'Jun 1', status: 'pending', viewed: true },
      { num: 'QTE-2025-011', from: 'Torres Drywall', fromAv: 'a-coral', job: 'Maple Grove add scope', amt: 4200, sent: 'Jun 25', status: 'accepted', viewed: true },
    ],
    pipelineJobs: [
      { stage: 'scoping', name: 'Lakeview — Drywall', ct: 'Unassigned', val: '$95K', trade: 'Drywall' },
      { stage: 'scoping', name: 'Harborview — HVAC', ct: 'Unassigned', val: '$52K', trade: 'HVAC' },
      { stage: 'awarded', name: 'Birchwood — Drywall', ct: 'Torres Drywall', val: '$29.8K', trade: 'Drywall' },
      { stage: 'awarded', name: 'Lakeview — HVAC', ct: 'Cruz HVAC', val: '$48K', trade: 'HVAC' },
      { stage: 'active', name: 'Maple Grove — Drywall', ct: 'Torres Drywall', val: '$32K', trade: 'Drywall', prog: 68 },
      { stage: 'active', name: 'Maple Grove — HVAC', ct: 'Cruz HVAC', val: '$42K', trade: 'HVAC', prog: 45 },
      { stage: 'active', name: 'Riverside — Flooring', ct: 'Premier Floors', val: '$18K', trade: 'Flooring', prog: 60 },
      { stage: 'complete', name: 'Commerce Park — Elec.', ct: 'Peak Electric', val: '$19.5K', trade: 'Electrical', prog: 100 },
    ],
    onboarding: [
      { name: 'Southwest Wall Co.', trade: 'Drywall', invited: 'Jun 20', w9: 'Submitted', coi: 'Pending', status: 'In progress' },
      { name: 'Desert Tile Co.', trade: 'Flooring', invited: 'Jun 15', w9: 'Not submitted', coi: 'Not submitted', status: 'Awaiting docs' },
      { name: 'Apex Painting', trade: 'Painting', invited: 'Jun 10', w9: 'Submitted', coi: 'Submitted', status: 'Under review' },
      { name: 'CleanLine Plumbing', trade: 'Plumbing', invited: 'Jun 1', w9: 'Submitted', coi: 'Submitted', status: 'Complete' },
    ],
    photos: [
      { job: 'maple', phase: 'Board installation', count: 8, color: '#E1F5EE', requested: true },
      { job: 'maple', phase: 'Taping & mudding', count: 5, color: '#E6F1FB', requested: false },
      { job: 'maple', phase: 'Final finish', count: 3, color: '#FAEEDA', requested: false },
      { job: 'riverside', phase: 'Site prep', count: 2, color: '#EEEDFE', requested: false },
    ],
  },
};

// ═══════════════════════════════════════
// UTILITY FUNCTIONS
// ═══════════════════════════════════════

function g(id) { return document.getElementById(id); }

function fmt(n) {
  return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtC(n) {
  return '$' + Math.round(n).toLocaleString();
}

function fmtCDec(n) {
  return '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function toast(msg, color) {
  const t = g('toast');
  if (!t) return;
  t.textContent = msg;
  t.style.background = color || 'var(--teal)';
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2800);
}

function openModal(id) {
  const el = g(id);
  if (el) el.classList.add('show');
}

function closeModal(id) {
  const el = g(id);
  if (el) el.classList.remove('show');
}

function navTo(p) {
  document.querySelectorAll('.ni').forEach(n => n.classList.toggle('on', n.dataset.p === p));
  document.querySelectorAll('.page').forEach(pg => pg.classList.remove('on'));
  const pg = g('p-' + p);
  if (pg) pg.classList.add('on');
  const t = g('pg-title'), s = g('pg-sub');
  const titles = {
    'dashboard': 'Dashboard', 'jobs': 'My jobs & CRM', 'quotes': 'Quote builder',
    'quote-history': 'My quotes', 'bids': 'Bid board', 'docs': 'Documents',
    'photos': 'Photo uploads', 'invoices': 'Invoices', 'messages': 'Messages', 'upgrade': 'Upgrade plan',
    'op-dashboard': 'Dashboard', 'op-quotes': 'Received quotes', 'op-crm': 'Contractor CRM',
    'op-jobs': 'Job management', 'op-bids': 'Bids & proposals', 'op-compliance': 'Compliance tracker',
    'op-invoices': 'Invoice approval', 'op-onboarding': 'Onboarding', 'op-reporting': 'Reporting',
    'op-messages': 'Messages', 'op-settings': 'Admin settings',
  };
  const subs = {
    'dashboard': 'Torres Drywall LLC · Q2 2025',
    'jobs': 'All jobs, quotes and business overview',
    'quotes': 'Build and send professional quotes',
    'quote-history': 'All sent quotes and their status',
    'bids': 'Open bid invitations from operators',
    'docs': 'Compliance documents and contracts',
    'photos': 'Job photos and progress uploads',
    'invoices': 'Invoice history and payment tracking',
    'messages': 'Communications with operators and contractors',
    'upgrade': 'Free and Pro plan comparison',
    'op-dashboard': 'Vestry Capital · Contractor portal overview',
    'op-quotes': 'Quotes submitted by your contractors',
    'op-crm': 'All contractor profiles and compliance status',
    'op-jobs': 'Work orders across all properties',
    'op-bids': 'Bid invitations and proposal management',
    'op-compliance': 'Document expiry and compliance tracker',
    'op-invoices': 'Review and approve contractor invoices',
    'op-onboarding': 'Contractor onboarding pipeline',
    'op-reporting': 'Job cost and performance analytics',
    'op-messages': 'All contractor message threads',
    'op-settings': 'Portal settings and permissions',
  };
  if (t) t.textContent = titles[p] || p;
  if (s) s.textContent = subs[p] || '';

  // Render page content
  if (p === 'dashboard') renderCtDashboard();
  if (p === 'jobs') renderCtJobs();
  if (p === 'quotes') renderQuoteBuilder();
  if (p === 'quote-history') renderQuoteHistory();
  if (p === 'docs') renderDocs();
  if (p === 'invoices') renderInvoices();
  if (p === 'messages') renderMessages();
  if (p === 'photos') renderPhotos();
  if (p === 'bids') renderBids();
  if (p === 'op-dashboard') renderOpDashboard();
  if (p === 'op-quotes') renderOpQuotes();
  if (p === 'op-crm') renderOpCRM();
  if (p === 'op-jobs') renderOpJobs();
  if (p === 'op-compliance') renderOpCompliance();
  if (p === 'op-invoices') renderOpInvoices();
  if (p === 'op-onboarding') renderOpOnboarding();
  if (p === 'op-reporting') renderOpReporting();
  if (p === 'op-messages') renderOpMessages();
  if (p === 'op-settings') renderOpSettings();
}

function switchTab(groupId, tabId) {
  const group = g(groupId);
  if (!group) return;
  group.querySelectorAll('.tab').forEach(t => t.classList.toggle('on', t.dataset.tab === tabId));
  group.querySelectorAll('.tc').forEach(t => t.classList.toggle('on', t.dataset.tab === tabId));
}

// Quote calculation
function recalcQuote() {
  const items = CHG.state.lineItems;
  const sub = items.reduce((s, l) => s + (l.qty * l.price), 0);
  const taxRate = (parseFloat((g('q-tax') || {}).value || 0)) / 100;
  const taxAmt = sub * taxRate;
  const total = sub + taxAmt;
  ['q-subtotal', 'prev-sub'].forEach(id => { const el = g(id); if (el) el.textContent = fmtCDec(sub); });
  ['q-tax-amt', 'prev-tax'].forEach(id => { const el = g(id); if (el) el.textContent = fmtCDec(taxAmt); });
  ['q-total', 'prev-total'].forEach(id => { const el = g(id); if (el) el.textContent = fmtCDec(total); });
  items.forEach(l => { const el = g('lt-' + l.id); if (el) el.textContent = fmtCDec(l.qty * l.price); });
  syncPreview();
  return { sub, taxAmt, total };
}

function syncPreview() {
  const items = CHG.state.lineItems;
  const sub = items.reduce((s, l) => s + (l.qty * l.price), 0);
  const taxRate = (parseFloat((g('q-tax') || {}).value || 0)) / 100;
  const total = sub + (sub * taxRate);
  const set = (id, val) => { const el = g(id); if (el) el.textContent = val; };
  set('prev-title', (g('q-title') || {}).value || 'QUOTE');
  set('prev-num', (g('q-num') || {}).value || '—');
  const exp = (g('q-expiry') || {}).value;
  set('prev-date', exp ? 'Valid until: ' + new Date(exp + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '');
  const jobEl = g('q-job');
  set('prev-job', jobEl ? jobEl.options[jobEl.selectedIndex]?.text : '');
  set('prev-scope', (g('q-scope') || {}).value || '');
  set('prev-notes', (g('q-notes') || {}).value || '');
  const termsEl = g('q-terms');
  set('prev-terms', termsEl ? termsEl.options[termsEl.selectedIndex]?.text : '');
  set('prev-sub', fmtCDec(sub));
  set('prev-tax', fmtCDec(sub * taxRate));
  set('prev-total', fmtCDec(total));
  const tbody = g('prev-tbody');
  if (tbody) tbody.innerHTML = items.map(l => `
    <tr>
      <td style="padding:5px 7px;font-size:11px;border-bottom:.5px solid rgba(0,0,0,.06)">${l.desc || '—'}</td>
      <td style="padding:5px 7px;font-size:11px;text-align:right;border-bottom:.5px solid rgba(0,0,0,.06)">${l.qty}</td>
      <td style="padding:5px 7px;font-size:11px;text-align:right;border-bottom:.5px solid rgba(0,0,0,.06)">${fmtCDec(l.price)}</td>
      <td style="padding:5px 7px;font-size:11px;font-weight:600;text-align:right;border-bottom:.5px solid rgba(0,0,0,.06)">${fmtCDec(l.qty * l.price)}</td>
    </tr>`).join('');
}
