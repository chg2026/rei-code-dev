# CHG Acquisitions — Underwriting Module Handoff
**File:** `CHG_Calculator_v4.html`  
**Location:** `Desktop/claude - RE crm/1-CLAUDE SYSTEM COWORK/calculator v1/`  
**Date:** April 29, 2026  
**Status:** Production-ready — fully audited, 0 critical bugs

---

## 1. OVERVIEW

The Underwriting module is a fully functional, self-contained HTML calculator. It lives as one screen (`screen-calc`) within a larger platform (`CHG_Calculator_v4.html`) that also contains Pipeline, Rehab Manager, Contacts, Documents, Warehouse, Admin, Scenarios, and Reports modules.

**Technology stack:**
- Single HTML file — no framework, no build step, no dependencies except Chart.js 4.4.1 (CDN)
- Apple SF Pro design system — CSS custom properties, 8px grid, Apple semantic colors
- Vanilla JavaScript — all calculations, all state, all DOM manipulation

**Two calculators in one:** FLIP and BRRRR share a single assumption panel on the left. A centered pill toggle switches the results panel between FLIP analysis and BRRRR/Rental analysis.

---

## 2. DESIGN SYSTEM

### Color tokens (CSS custom properties)
```
--bg: #F5F5F7         (page background)
--surface: #fff       (card background)
--s2: #FAFAFA         (secondary surface)
--s3: #F2F2F7         (tertiary surface)
--b1: rgba(0,0,0,0.06)  (hairline border)
--b2: rgba(0,0,0,0.12)  (standard border)
--t1: #1D1D1F         (primary text)
--t2: #6E6E73         (secondary text)
--t3: #AEAEB2         (muted/tertiary text)
--grn: #34C759        (green — positive)
--grn-dk: #1A6B35     (dark green — text on green bg)
--grn-bg: #EDFAF2     (green background tint)
--amb: #FF9F0A        (amber — warning)
--amb-dk: #7D4A00     (dark amber)
--amb-bg: #FFF8EE     (amber background tint)
--red: #FF3B30        (red — negative/loss)
--red-dk: #8C1515     (dark red)
--red-bg: #FFF1F0     (red background tint)
--blue: #0071E3       (blue — interactive/info)
--blue-dk: #004499    (dark blue)
--blue-bg: #EBF3FF    (blue background tint)
--navy: #1B3A5C       (nav bar / assumption panel header)
```

### Typography
- Font: `-apple-system, BlinkMacSystemFont, "SF Pro Text", "Helvetica Neue", sans-serif`
- Base: 13px
- Section labels: 9px, uppercase, 0.08em letter-spacing, font-weight:700
- Row labels: 11px, font-weight:600 (primary) or 500 (secondary)
- Row values: 12–14px, font-weight:500–700
- Card titles (new header style): 15px, font-weight:700

### Key UI patterns
- **Leader dots** (`.leader`): flex:1, 1px dotted border-bottom, connects label to value in every data row
- **Pill badges**: border-radius:20px, used for section descriptors, status tags, deal strength
- **Tooltip system**: `.tip-wrap` + `.tip-icon` + `.tip-box` — uses `position:fixed` JS positioning to escape overflow:hidden containers
- **Collapsible panels**: `.detail-panel.collapsed` with max-height CSS animation
- **Cards**: `.card` — white, border-radius:12px, 0.5px border, shadow

---

## 3. NAVIGATION STRUCTURE

### Main nav (`.nav`)
Eight clickable modules: Pipeline | Underwriting | Rehab Manager | Property Record | Contacts | Documents | Warehouse | Admin

All nav buttons call `setModule(module, btn)` which:
1. Hides all `.screen` and `.mod-screen` elements
2. Clears all nav active states
3. Shows/hides deal bar, Row 1, Row 2 based on `isUW` flag
4. Activates the correct screen

**Critical:** Deal bar (`.deal-bar`), Row 1 (`.r1`), and Row 2 (`.r2`) are ONLY visible when Underwriting is active. All other modules hide these completely via `display:none`.

### Within Underwriting — Row 1 tabs
- **Flip** → `setTop('flip', this)` → shows rv-flip results
- **BRRRR** → `setTop('brrrr', this)` → shows rv-brrrr results
- **Wholesale** → `showPH('wholesale')` → placeholder
- **All calculators ▼** → `toggleMore()` → dropdown with Flip, BRRRR, Wholesale, MF Analyzer, Commercial CRE
- **≈ Scenarios** → `showPH('scenarios')` → opens Scenarios module
- **Reports** → `showPH('reports')` → opens Reports module

### Row 2 (Pinned calculators)
Three `+ Pin a calculator` slots — calls `toggleMore()` to open the calculator dropdown.

---

## 4. ASSUMPTION PANEL (shared — drives both FLIP and BRRRR)

**Width:** 258px, left side, always visible when Underwriting is active  
**Header:** Navy background, "Assumption panel" / "Shared — drives both FLIP & BRRRR"

### Section 1: Purchase
| Field | ID | Default | Notes |
|---|---|---|---|
| Price type | `ap-pt` | Purchase price | Dropdown: Purchase price / After repair value |
| Amount | `ap-price` | 195,000 | Drives allIn in both calculators |
| Closing costs | `ap-closing` | 2,810 | "title, escrow, inspection" |
| Monthly holding costs | `ap-holding` | 3,000 | "taxes, insurance, utilities" |

### Section 2: Rehab
| Field | ID | Default | Notes |
|---|---|---|---|
| Estimated rehab cost | `ap-rehab` | 20,000 | Has `i` tooltip explaining what to enter |
| Rehab period | `ap-rmo` | 2 months | Dropdown: 0 months (as-is) through 24 months |

**Important bug fixes applied:**
- `ap-rmo` uses `isNaN` guard in recalcFlip(): `const rmoRaw=parseInt($('ap-rmo').value); const rmo=isNaN(rmoRaw)?2:rmoRaw;` — allows true 0-month (as-is) rehab without fallback to 2
- Same pattern for `f-smo` (selling months)

### Section 3: Financing
| Field | ID | Default | Notes |
|---|---|---|---|
| Financing type | `ap-fin` | All cash | Dropdown: All cash / Hard money / Private lender |
| Lender cap basis | `ap-cap` | % of ARV | Shown only when not cash. Options: % of ARV / % of project cost |
| Max % financed | `ap-maxfin` | 70 | % |
| Origination & points | `ap-pts` | 2 | pts |
| Rate during rehab | `ap-rrate` | 10.5 | % |
| Back-end profit split | `ap-split` | 0 | % |

`toggleFin()` shows/hides the financing section based on `ap-fin` value.

**Interest cost formula (FIXED):** `intCost = loanAmt × (rRate/12) × (rmo + smo)` — charges interest for FULL hold period (rehab + selling), not just rehab period.

---

## 5. FLIP CALCULATOR

### Section A: Sale assumptions
Three inputs across the top of the results panel:

| Field | ID | Default | Notes |
|---|---|---|---|
| After-repair value (ARV) | `f-arv` | 340,000 | Triggers `syncCosDisplay()` + `recalcFlip()` |
| Months to sell after rehab | `f-smo` | 2 months | Dropdown: 1–12 months |
| Projected cost of sale (%) | `f-cos` | 7 | `cosFromPct()` — bidirectional sync |
| Projected cost of sale ($) | `f-cos-dollar` | 23,800 | `cosFromDollar()` — bidirectional sync |

**Bidirectional CoS sync:** Changing % updates $, changing $ updates %. Lock flag `_cosLock` prevents infinite loops. `syncCosDisplay()` called when ARV changes to keep dollar in sync.

**Summary bar (always visible):** ARV | Hold period | Cost of sale ($) | All-in as % of ARV

The **% of ARV** field has a tooltip explaining: "Total cost basis ÷ after-repair value. Lower is better — most lenders want this below 80%."

### Section B: Deal costs (waterfall)
Leader-dot rows showing the cost breakdown:
- Purchase price → `f-cost-price`
- + Closing costs → `f-cost-closing`
- + Holding costs → `f-cost-holding`
- + Rehab budget → `f-cost-rehab`
- + Financing costs → `f-cost-fin` (hidden when finCost=0 via `f-cost-fin-row` display toggle)
- + Cost of sale → `f-cost-cos` (in red)

**Footer (2-col):**
- All-in cost (excl. sale) → `f-allin`
- Cash required → `f-cashreq` (blue highlight)

### Section C: Return metrics

**Projected profit row** (green/amber/red based on deal strength):
- Left: deal strength badge `f-profit-badge` + context sub-line `f-hold-label` ("X-month hold · $Y cash in")
- Right (with leader dot): profit amount `f-profit`

**Deal strength tiers (profit as % of ARV):**
- ≥ 20% → "Strong deal ✓" (green)
- 15–19% → "Good deal" (teal)
- 10–14% → "Marginal deal" (amber)
- 1–9% → "Weak deal ⚠" (orange)
- < 0% → "Losing money ✗" (red)

The badge has a hover tooltip showing all 5 tiers with ranges.

**Primary return rows (14px bold):**
- ROI on cash invested → `f-roi` = (yourProfit/cashReq)×100
- ROI annualized (hold-adjusted) → `f-roiann` = (1+periodReturn)^(12/totalMo) - 1
- IRR (annualized) → `f-irr` = same as roiAnn for single-period flip

**Additional metrics section:**
- Equity multiple → `f-em` = (yourProfit + cashReq) / cashReq
- NPV at 8% discount rate → `f-npv` = -cashReq + (profit+cashReq)/(1+0.08×totalMo/12)
- Hold period → `f-hold` = rmo + smo months

### FLIP Charts

**1. Deal structure breakdown** (`chart-waterfall`)
- Horizontal bar chart (Chart.js)
- Bars: Purchase | Closing | Holding | Rehab | [Financing if applicable] | Cost of sale
- Profit shown separately below with spacer
- Colors: blue (purchase), amber (closing/holding), orange (rehab), purple (financing), red (cost of sale), green/red (profit)

**2. Deal allocation pie** (`chart-pie`)
- Doughnut chart showing every dollar of ARV and where it goes
- ARV shown in center
- Custom legend built dynamically with dollar amounts and percentages
- Slices filtered — only show slices with val > 0

**3. ARV / Sale price sensitivity** (HTML cards — NOT Chart.js)
- Three side-by-side cards inside outer `.card` wrapper
- Bear (−10%) | Base | Bull (+10%)
- Each card: scenario label, sale price (17px bold), divider, profit amount
- Colors driven by deal strength tier
- Base card always blue accent
- Outer wrapper has title "ARV / Sale price sensitivity" + pill "Profit at three sale price scenarios"

**4. Doomsday stress test** (`chart-stress`)
- Chart.js bar chart
- Same 3 scenarios BUT with rehab cost +10% overrun added
- Bar colors FIXED: Bear = red, Base = neutral gray, Bull = green (semantic, not profit-driven)
- Labels: "−10%" | "Base" | "+10%"
- Above-bar labels: profit in $k + sale price in $k (custom Chart.js plugin)
- Two pill descriptors: red pill (overrun amount) + neutral pill (sale price scenarios)

**5. Live deal stress tester** (interactive sliders)
Three sliders with LIVE recalculation:

| Slider | ID | Range | Step | Notes |
|---|---|---|---|---|
| Sale price / ARV | `slider-sale` | ±20% of ARV | $1k | Dynamic range, re-centers on ARV change |
| Construction costs | `slider-rehab` | ±20% of ARV | $1k | Dynamic range |
| Total hold time | `slider-hold` | 1 to baseline+12 months | 1 month | Baseline = rmo+smo, syncs with assumption panel |

**Critical:** Stress tester NOW reads all financing inputs (`ap-fin`, `ap-cap`, `ap-maxfin`, `ap-pts`, `ap-rrate`) via `calcFinCost()` inner function. This was the user-reported bug: changing financing type had no effect on stress tester. Now fixed.

`stressAllIn = basePrice + baseClosing + stressHolding + stressRehab + stressFinCost`

**stressRehab is clamped:** `Math.max(0, baseRehab + rehabV*1000)` — can't go negative.

Baseline property bar shows: sale price | rehab | hold | baseline profit (all from assumption panel).

Result panel (3 equal columns, centered):
- Stressed profit (colored by deal strength)
- Deal strength badge
- ROI on cash

Below: "Scenario" + leader dot + scenario summary text

---

## 6. BRRRR CALCULATOR

### Section A: Rental income — rent roll

**Unit table** (`unit-body`):
Columns: # (unit count, editable) | Beds | Baths | Sq ft | $/sqft/mo | Mo. rent | Ann. rent | % GSI | [delete]

- `calcUR(row)` — reads sq ft × $/sqft → auto-populates monthly rent
- `addUnit()` — adds new row with sequential label, default value=1
- `renumberUnits()` — called on delete, updates row numbers
- Helper text: "Enter each unit individually — or type directly into the fields above"
- `+ Add unit` button styled red (same as Edit rent roll button)
- GSI calculation: `gsiMo += u * r` per row (u = unit count from col 1, r = monthly rent)

**Below table (always visible summary):**
- Vacancy rate → `b-vac` (%)
- Annual rent growth → `b-rent-growth` (%/yr) — has `i` tooltip explaining 5-yr compounding
- Other income/yr → `b-other-inc` (laundry, parking)

**Income waterfall (always visible):**
- Gross scheduled income (GSI) → `b-gsi`
- Less: Vacancy loss → `b-vacloss` (red)
- Effective gross income (EGI) → `b-egi`
- Plus: Other income → `b-other-inc-display`
- **Gross operating income (GOI)** → `b-goi` (green highlighted)

**Collapsible:** The rent roll table and vacancy inputs collapse behind "Edit rent roll" red button (centered in card header). Default: collapsed.

### Section B: Operating expenses

**Management fee** (special field — bidirectional sync):
- `b-mgmt` — percentage field (oninput → `mgmtFromPct()`)
- `b-mgmt-dollar` — dollar/month field (oninput → `mgmtFromDollar()`)
- Formula: `mgmtMo = GOI/12 × (mgmtPct/100)`
- Dollar auto-populates from % when not being actively edited (activeElement guard)
- `_mgmtLock` flag prevents infinite loop
- `_lastGOI` stores current GOI for dollar→% conversion
- Display: `b-mgmt-display` (inside collapsible), `b-mgmt-summary` + `b-mgmt-pct-display` (always visible footer)

**Fixed expense inputs (all monthly, all in collapsible panel):**
| Field | ID | Default |
|---|---|---|
| Advertising | `b-adv` | 0 |
| Insurance (hazard) | `b-ins` | 100 |
| Janitorial | `b-jan` | 0 |
| Landscape maintenance | `b-land` | 0 |
| Legal & professional | `b-legal` | 0 |
| Miscellaneous | `b-misc` | 0 |
| Referrals & commissions | `b-ref` | 0 |
| Repairs & maintenance | `b-repairs` | 75 |
| Reserves (CapEx) | `b-reserves` | 50 |
| Taxes — property | `b-taxes` | 200 |
| Other (editable name) | `b-other` | 0 |
| Water / Sewer | `b-water` | 0 |
| Electricity | `b-elec` | 0 |
| Gas | `b-gas` | 0 |
| Fuel oil | `b-fuel` | 0 |
| Other utilities | `b-util-other` | 0 |

Each expense has a calc display (`d-adv`, `d-ins`, etc.) showing: `$X/yr · X% opex · X% GOI`

**Custom expenses:** `+ Add custom expense` button (red) adds `.custom-exp-row` with editable name and `/mo` input. Included in all opex calculations and stress tester. Delete button removes row.

**Always-visible footer (3-col):**
- Management fee/mo → `b-mgmt-summary` + `b-mgmt-pct-display`
- Total operating expenses/mo → `b-opex-mo` + `b-opex-yr-display` (/yr)
- Net operating income (NOI)/yr → `b-noi` + `b-noi-mo` (/mo, green)

**Formula:** `totalOpexMo = mgmtMo + fixedExpenses + customExpenses`; `NOI = GOI - totalOpexMo×12`

**Collapsible:** All inputs collapse behind "Edit expenses" red button (centered in card header). Default: collapsed.

### Section C: Refinance into permanent financing

**Toggle:** `refi-tog` checkbox — `toggleRefi()` shows/hides Section C content, updates text "Yes — refinancing" / "No — holding cash". Also calls `updateBrrrStressTester()`.

**Inputs (6 fields):**
| Field | ID | Default | Notes |
|---|---|---|---|
| ARV / Appraised value | `b-arv` | 280,000 | Row 32 — base for refi loan |
| Months to rent after rehab | `b-rent-delay` | 2 months | Dropdown 0–12. Reduces Year 1 income by rentDelay months |
| Refi % of appraisal / LTV | `b-ltv` | 75 | % |
| New mortgage rate | `b-rate` | 7.0 | % |
| Amortization / interest only | `b-years` | 30 years | Dropdown: 30/25/20/15 years + "Interest only" |
| Refi discount points & misc costs | `b-pts` | 1 | % |

**Refi output rows (leader-dot rows):**
| Label | ID | Formula |
|---|---|---|
| Total capital needed (prior to refi) | `b-capital-needed` | = allIn |
| Cash required (prior to refi) | `b-cash-req` | = allIn |
| Total all-in cost at end of rehab | `b-allin-display` | = allIn |
| % of ARV | `b-pct-arv` | allIn/arv×100 — has `i` tooltip |
| New mortgage payment (monthly) | `b-rpmt` | Standard amortization or IO formula |
| Refi loan amount | `b-rloan` | = arv × ltv |

**Green highlighted rows:**
| Label | ID | Formula |
|---|---|---|
| Cash out at refi | `b-cashout` | = refiLoan - ptsCost |
| Profit at refi | `b-profit-refi` | = cashOut - allIn |
| Original money tied up after refi | `b-tied` | = max(0, allIn - grossCashOut) |
| Equity left in the deal after refi | `b-equity` | = arv - refiLoan |
| **Value created** | `b-forced-appr` | = arv - (price + rehab) — has `i` tooltip explaining forced appreciation + equity capture + market appreciation |

**BRRRR complete banner** (`brrrr-banner`): Shows when tied ≤ $50 — "BRRRR complete — infinite return. You refinanced out 100% of your invested capital..."

**Interest-only formula:** `refiPmt = refiLoan × mr` (when IO selected)

**`calcBal()` function:** Calculates remaining loan balance after N months. Guards: `if(rate<=0) return loan` — prevents division by zero at 0% rate.

### Section D: Cash flow & return metrics

**New: Capital invested context row** (above Total return):
- `b-capital-invested` — shows tied capital (or "$0 — fully recycled" for BRRRR complete)
- Cleared to "—" when refi is OFF

**Primary return rows:**
| Label | ID | Formula |
|---|---|---|
| Capital invested | `b-capital-invested` | = tied |
| Total return on capital (5-yr) | `b-roi` | = totalReturns/tied × 100 |
| Cash flow (monthly, pre-tax) | `b-cfmo` | = (NOI - annDS)/12 |
| Cash-on-cash (annual, pre-tax) | `b-coc` | = (NOI - annDS)/tied × 100 |

**Additional ratios section:**
| Label | ID | Notes |
|---|---|---|
| Property DSCR | `b-dscr` + `b-dscr-badge` | NOI/annDS. Badge: ✓ Meets 1.25× / ⚠ Below 1.25× / ✗ Below 1.0× |
| Payback period | `b-payback` | tied/yrCF in years |
| Cap rate — cost basis | `b-cap-c` | NOI/allIn × 100 |
| Cap rate — ARV basis | `b-cap-a` | NOI/arv × 100 |
| IRR (5-yr hold) | `b-irr` | Newton-Raphson, 150 iterations, convergence at $0.01 NPV |
| Equity multiple (5-yr) | `b-em` | totalReturns/tied — FIXED (was erroneously +tied before) |

**IRR inputs (inline editable in the row):**
- `b-irr-appr` — appreciation % (default 3%)
- `b-irr-exit` — exit costs % (default 6%)
- Both trigger `recalcB()` via oninput

**5-year cash flow model:**
- `annualCFs[y]` = (GOI × (1+rentGrowth)^y − mgmt% of yGOI − fixedOpex) − annDS
- Year 1 reduced by rent delay: `incMos = max(0, 12-rentDelay)`
- mgmt fee compounds with rent growth; fixed opex stays flat

**Footer:**
- Annual cash flow (Year 1) → `b-cfyr` (with rent growth arrow if >0%)

**Benchmark targets section (editable, at bottom of Section D):**
| Field | ID | Default | Notes |
|---|---|---|---|
| DSCR minimum | `tgt-dscr` | 1.25× | |
| CoC target | `tgt-coc` | 10% | |
| Cap rate target (cost) | `tgt-cap-cost` | blank | Has `i` tooltip. Only appears on DSCR chart when filled |
| Cap rate target (ARV) | `tgt-cap-arv` | blank | Has `i` tooltip. Only appears on DSCR chart when filled |

### BRRRR Charts

**1. Annual cash flow — 5-year projection** (full-width hero card)
- Bar chart (Chart.js) — 5 bars, one per year
- Line overlay — cumulative cash returned
- **3-stat summary row above chart:**
  - Year 1 cash flow / mo → `cf-stat-yr1`
  - Year 5 cash flow / mo → `cf-stat-yr5`
  - Cumulative 5-yr return → `cf-stat-cumul`
- Height: 280px

**2. DSCR & return snapshot** (custom HTML rows — NOT Chart.js)
- Replaced Chart.js bar chart entirely
- Two independent gauge rows: DSCR (scale 0–3×) and Cash-on-cash (scale 0–30%)
- Each row: label | progress bar with target marker | badge (✓ green / ✗ red, binary — no amber) | actual value
- Cap rate rows appear ONLY when target fields in Section D are filled in
- Subtitle: "Actuals vs. your benchmark targets set in section D above"

### BRRRR Live Stress Tester

Five sliders with LIVE recalculation of all metrics:

| Slider | ID | Range | Step | Notes |
|---|---|---|---|---|
| Monthly rents | `bsl-rent` | ±25% | 1% | Scales all unit rents |
| Rehab costs | `bsl-rehab` | ±25% | 1% | Scales rehab budget. Clamped to $0 minimum |
| ARV / Appraised value | `bsl-arv` | ±30% | 1% | Affects refi loan, cash out, equity |
| Interest rate (refi) | `bsl-rate` | ±30% of baseline rate | 0.125% steps | Absolute % values (e.g. 4.9% to 9.1% for 7% baseline) |
| Property management fee | `bsl-mgmt` | 0–30% | 0.5% | Fixed range, starts at current baseline mgmt % |

**`calcMetrics()` inner function** (arrow function, closes over all refi/expense variables):
- Takes: (gsiMo, rehab, arv, stressRate, stressMgmtPct)
- Returns: {noi, moCF, coc, dscr, cashOut, tied, allIn, profitAtRefi, equity}
- Custom expenses included in fixedOpexMo via `querySelectorAll('.custom-exp-input')`

**Result panel (6 metrics in 2 rows):**
Row 1: Monthly CF | Cash-on-cash | DSCR | Cash out at refi
Row 2: Profit at refi | Equity left in deal
Each metric has delta vs baseline.

**Slider track colors:**
- Rate/mgmt sliders: custom `updateRateSliderTrack()` — green left of baseline, red right of baseline
- Other sliders: `updateSliderTrack()` — bidirectional gradient

**All slider labels follow format:** "+X% from baseline" (not amber/close — just no-change/from-baseline)

---

## 7. KEY JAVASCRIPT FUNCTIONS

### Core calculation
| Function | Purpose |
|---|---|
| `recalc()` | Calls both recalcFlip() and recalcB() |
| `recalcFlip()` | Full FLIP calculation. Reads all inputs, computes all outputs, updates all charts and stress tester |
| `recalcB()` | Full BRRRR calculation. GSI→GOI→expenses→NOI→refi→cash flows→IRR |
| `calcBal(loan,rate,years,months)` | Remaining loan balance after N months. Guards against rate=0 |

### Flip utilities
| Function | Purpose |
|---|---|
| `cosFromPct()` | CoS % changes → updates $ field |
| `cosFromDollar()` | CoS $ changes → updates % field |
| `syncCosDisplay()` | ARV changes → keeps $ in sync with current % |
| `toggleFin()` | Shows/hides financing section based on `ap-fin` value |

### BRRRR utilities
| Function | Purpose |
|---|---|
| `mgmtFromPct()` | Mgmt % changes → clears $ field (recalcB repopulates) |
| `mgmtFromDollar()` | Mgmt $ changes → converts to % using `_lastGOI` |
| `toggleRefi()` | Shows/hides refi section. Calls `updateBrrrStressTester()` |
| `addUnit()` | Adds new rent roll row, value=1 |
| `renumberUnits()` | Renumbers rows after delete |
| `calcUR(row)` | Sq ft × $/sqft → auto-fills monthly rent |
| `addCustomExp()` | Creates `.custom-exp-row` with editable name |

### Charts
| Function | Updates |
|---|---|
| `updateWaterfallChart()` | FLIP deal structure breakdown |
| `updateSensitivityChart()` | FLIP ARV sensitivity cards (HTML, not chart) |
| `updateStressChart()` | FLIP doomsday stress test (Chart.js) |
| `updatePieChart()` | FLIP deal allocation doughnut |
| `updateCashFlowChart()` | BRRRR 5-yr projection bars + cumulative line. Populates cf-stat-yr1/yr5/cumul |
| `updateDSCRChart()` | BRRRR DSCR + CoC metric rows (DOM, not chart). Adds cap rate rows only when targets filled |

### Navigation
| Function | Purpose |
|---|---|
| `setModule(module, btn)` | Switches between platform modules. Hides/shows deal-bar/r1/r2 based on isUW |
| `setTop(which, btn)` | Switches between Flip and BRRRR within Underwriting |
| `switchRV(w)` | Switches rv-flip/rv-brrrr result panels |
| `showPH(id)` | Shows placeholder/other screens (wholesale, scenarios, reports) |
| `toggleMore()` / `closeMore()` | Calculator dropdown menu |
| `togglePanel(which)` | Collapses/expands income or expense section |

### Stress testers
| Function | Purpose |
|---|---|
| `updateStressTester()` | FLIP stress tester — reads all financing inputs, calculates stressed profit, updates 3-col result panel |
| `onStressSlide(which)` | Called by FLIP slider oninput. Updates track, calls updateStressTester() |
| `resetStressSliders()` | Resets all 3 FLIP sliders to baseline |
| `updateBrrrStressTester()` | BRRRR stress tester — runs calcMetrics() for base and stressed scenarios |
| `onBrrrSlide(which)` | Called by BRRRR slider oninput. Handles rate/mgmt specially |
| `resetBrrrSliders()` | Resets all 5 BRRRR sliders to baseline |
| `updateRateSliderTrack(slider, baseVal)` | Custom track gradient for rate/mgmt sliders (green below base, red above) |
| `updateSliderTrack(slider, unidirectional)` | Standard track gradient for other sliders |

### Scenarios integration
| Function | Purpose |
|---|---|
| `pushDealToScenarios()` | Reads assumption panel → populates property bar in Scenarios → navigates to Scenarios |
| `recalcScenario(sc)` | Recalculates one scenario column (a, b, or c) |
| `recalcAllScenarios()` | Calls recalcScenario for all three |
| `updateScenarioType(sc)` | Shows income or flip section based on strategy type |
| `updateScenarioComparison()` | Updates head-to-head comparison table |

---

## 8. BUGS FIXED DURING THIS SESSION

1. **Duplicate `const allIn`** in recalcB() — removed duplicate declaration
2. **`opex` undefined** in annualCFs loop — replaced with `fixedOpexMo*12`
3. **`mgmtPct2`** in rent growth loop — replaced with `mgmtPctVal`
4. **`calcBal()` division by zero** at rate=0 — added `if(rate<=0) return loan`
5. **`b-rads` write to non-existent element** — removed stale set() call
6. **FLIP stress tester ignoring financing** — built `calcFinCost()` inside `updateStressTester()`
7. **Selling period interest missing** — intCost now uses `(rmo+smo)` not just `rmo`
8. **Equity Multiple formula wrong** — was `(totalReturns+tied)/tied`, fixed to `totalReturns/tied`
9. **Hold slider init falsy bug** — `parseInt('0')||2=2` fixed to `isNaN` guard
10. **stressRehab negative** — clamped to `Math.max(0,...)`
11. **Management fee zero bug** — `||` operator replaced with `isNaN` check
12. **screen-calc unclosed `</div>`** — causing ALL placeholder/module screens to be nested inside screen-calc, making them invisible when screen-calc lost active class
13. **Tooltip clipping** — replaced CSS hover with JS `position:fixed` positioning via DOMContentLoaded listener

---

## 9. DESIGN DECISIONS (LOCKED)

1. **No chart library for sensitivity cards** — replaced Chart.js bars with HTML cards (3 side-by-side, each owning their scenario)
2. **DSCR chart replaced with DOM rows** — independent scales per metric (DSCR 0–3×, CoC 0–30%) — bar chart was misleading with shared scale
3. **Management fee bidirectional** — works both as % and $ input, converts between the two using live GOI
4. **Custom expenses** — user can rename "Other" field and add unlimited additional expense rows
5. **Rehab delay** — reduces Year 1 income by N months, accurate BRRRR cash flow modeling
6. **Rent growth compounding** — management fee scales with income; fixed expenses stay flat over 5 years
7. **All assumption panel inputs shared** — both FLIP and BRRRR read from same ap-* fields
8. **Apple design language** — SF Pro font, semantic colors, 8px grid, pill badges, leader dots, tooltip i-icons
9. **Edit rent roll / Edit expenses buttons** — red, centered in card header, collapse by default
10. **Value created field** — arv-(price+rehab), covers forced appreciation + equity capture + market appreciation

---

## 10. INITIALIZATION SEQUENCE

```javascript
recalcFlip();           // Initializes FLIP calculator
recalcB();              // Initializes BRRRR calculator
// FLIP sliders
['sale','rehab'].forEach(id=>updateSliderTrack($('slider-'+id),false));
// Scenario init (wrapped in try/catch so errors don't crash main calculators)
try{recalcAllScenarios();['a','b','c'].forEach(sc=>updateScenarioType(sc));}catch(e){}
// BRRRR sliders
['rent','rehab','arv'].forEach(id=>updateSliderTrack($('bsl-'+id),false));
// Hold slider baseline = rmo + smo
const _initHold=Math.max(1,(isNaN(_rmoInit)?2:_rmoInit)+(isNaN(_smoInit)?1:Math.max(1,_smoInit)));
$('slider-hold').value=_initHold;
updateSliderTrack($('slider-hold'),true);
// Tooltip fixed positioning
DOMContentLoaded → querySelectorAll('.tip-wrap') → mouseenter sets position:fixed
```

---

## 11. WHAT IS NOT BUILT IN UNDERWRITING

- Address lookup / property import (Phase 2 — requires ATTOM/CoreLogic API)
- ARV estimator from comps (Phase 2 — requires MLS API)
- Rent roll import / parsing (Phase 2 — requires AI document extraction)
- T12 income statement analysis (Phase 2 — AI parsing)
- MF Analyzer (placeholder exists — unit mix, capital stack, waterfall — not built)
- Wholesale / MAO calculator (placeholder exists — not built)
- PDF report generation (Reports module placeholder — not built)
- Print functionality (button exists, calls `window.print()`)

---

## 12. FILE STRUCTURE

All code is in one file: `CHG_Calculator_v4.html`

Sections in order:
1. `<head>` — Chart.js CDN, all CSS
2. `<nav>` — main nav with all module buttons
3. `.deal-bar` — current deal context bar
4. `.r1` — calculator tab row (Flip/BRRRR/Wholesale/Scenarios/Reports)
5. `.r2` — pinned calculators row
6. `#screen-calc` — main calculator screen (FLIP + BRRRR)
7. `#screen-wholesale`, `#screen-mf`, `#screen-commercial` — placeholders
8. `#screen-scenarios` — fully interactive Scenarios module
9. `#screen-reports` — Reports screen with all 5 report types
10. `#screen-pipeline` — Pipeline kanban + list view
11. `#screen-rehab` — Rehab Manager (budget/scope/schedule tabs)
12. `#screen-property-record` — Property Record
13. `#screen-contacts` — Contacts with filter system
14. `#screen-documents` — Documents with folders + recent files
15. `#screen-warehouse` — Warehouse (suppliers + orders)
16. `#screen-admin` — Admin Settings
17. `<script>` — all JavaScript (~2,300 lines)
