import { Link, useLocation, Outlet } from "react-router-dom";
import { LayoutDashboard, Building2, Users, Kanban, FileText, BarChart3, Settings, Bell, ChevronRight, Menu, X, Zap, ShoppingBag, Handshake, UserCheck, Eye, Globe } from "lucide-react";
import { useState } from "react";

const navGroups = [
  {
    label: null,
    items: [
      { label: "Dashboard", path: "/", icon: LayoutDashboard },
    ]
  },
  {
    label: "Deals",
    items: [
      { label: "Properties", path: "/properties", icon: Building2 },
      { label: "Pipeline", path: "/pipeline", icon: Kanban },
      { label: "Offers", path: "/offers", icon: FileText },
      { label: "Marketplace", path: "/marketplace", icon: Globe },
    ]
  },
  {
    label: "Buyers",
    items: [
      { label: "Buyers List", path: "/buyers", icon: Users },
      { label: "JV Deals", path: "/jv-deals", icon: Handshake },
      { label: "Buyer Rental", path: "/buyer-rental", icon: UserCheck },
    ]
  },
  {
    label: "Enterprise",
    items: [
      { label: "AI Deal Blast", path: "/deal-blast", icon: Zap },
      { label: "God Mode", path: "/god-mode", icon: Eye },
      { label: "Artemis Mode", path: "/artemis-mode", icon: Eye },
    ]
  },
  {
    label: "Reports",
    items: [
      { label: "Analytics", path: "/analytics", icon: BarChart3 },
    ]
  },
];

// Flatten for matching
const allNavItems = navGroups.flatMap(g => g.items);

export default function Layout() {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-5 py-4 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-amber-400 rounded-lg flex items-center justify-center">
            <Building2 className="w-5 h-5 text-slate-900" />
          </div>
          <span className="text-white font-bold text-lg tracking-tight">DealFlow<span className="text-amber-400">Pro</span></span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-3 space-y-4 overflow-y-auto">
        {navGroups.map((group, gi) => (
          <div key={gi}>
            {group.label && (
              <p className="text-slate-500 text-xs font-semibold uppercase tracking-wider px-3 mb-1">{group.label}</p>
            )}
            <div className="space-y-0.5">
              {group.items.map(({ label, path, icon: Icon }) => {
                const active = location.pathname === path;
                const isEnterprise = group.label === "Enterprise";
                return (
                  <Link
                    key={path}
                    to={path}
                    onClick={() => setMobileOpen(false)}
                    className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                      active
                        ? "bg-amber-400 text-slate-900"
                        : "text-slate-400 hover:text-white hover:bg-slate-700"
                    }`}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span className="flex-1">{label}</span>
                    {isEnterprise && !active && (
                      <span className="text-xs bg-amber-400/20 text-amber-400 px-1.5 py-0.5 rounded font-medium">E</span>
                    )}
                    {active && <ChevronRight className="w-3 h-3 ml-auto" />}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Bottom */}
      <div className="px-3 py-3 border-t border-slate-700">
        <Link to="/settings" className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-slate-400 hover:text-white hover:bg-slate-700 transition-all">
          <Settings className="w-4 h-4" />
          Settings
        </Link>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-56 bg-slate-900 flex-col flex-shrink-0 border-r border-slate-700">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-56 bg-slate-900 border-r border-slate-700">
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="h-14 bg-slate-900 border-b border-slate-700 flex items-center px-4 gap-4 flex-shrink-0">
          <button className="md:hidden text-slate-400 hover:text-white" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <div className="flex-1" />
          <button className="relative text-slate-400 hover:text-white">
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-amber-400 rounded-full" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-400 flex items-center justify-center text-slate-900 font-bold text-sm">A</div>
            <span className="text-white text-sm font-medium hidden sm:block">Admin</span>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto bg-slate-950 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}