import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Properties from './pages/Properties';
import Buyers from './pages/Buyers';
import Pipeline from './pages/Pipeline';
import Offers from './pages/Offers';
import Analytics from './pages/Analytics';
import GodMode from './pages/GodMode';
import ArtemisMode from './pages/ArtemisMode';
import DealBlast from './pages/DealBlast';
import Marketplace from './pages/Marketplace';
import JVDeals from './pages/JVDeals';
import BuyerRental from './pages/BuyerRental';
import Handoff from './pages/Handoff';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-slate-950">
        <div className="w-8 h-8 border-4 border-slate-700 border-t-amber-400 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/properties" element={<Properties />} />
        <Route path="/buyers" element={<Buyers />} />
        <Route path="/pipeline" element={<Pipeline />} />
        <Route path="/offers" element={<Offers />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/god-mode" element={<GodMode />} />
        <Route path="/artemis-mode" element={<ArtemisMode />} />
        <Route path="/deal-blast" element={<DealBlast />} />
        <Route path="/marketplace" element={<Marketplace />} />
        <Route path="/jv-deals" element={<JVDeals />} />
        <Route path="/buyer-rental" element={<BuyerRental />} />
        <Route path="/handoff" element={<Handoff />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App