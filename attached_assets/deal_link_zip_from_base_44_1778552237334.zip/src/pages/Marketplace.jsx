import { useState } from "react";
import { Building2, Bed, Bath, Ruler, Heart, Eye, Filter, Search, Tag, Zap, ChevronDown } from "lucide-react";

const listings = [
  { id: 1, address: "1234 Oak Street", city: "Atlanta", state: "GA", price: 85000, arv: 140000, beds: 3, baths: 2, sqft: 1400, type: "Single Family", status: "Active", tags: ["Turnkey"], views: 47, photos: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400&q=80" },
  { id: 2, address: "5678 Pine Ave", city: "Dallas", state: "TX", price: 120000, arv: 195000, beds: 4, baths: 3, sqft: 2100, type: "Single Family", status: "Active", tags: ["Subject To"], views: 31, photos: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=400&q=80" },
  { id: 3, address: "9012 Maple Dr", city: "Phoenix", state: "AZ", price: 67000, arv: 110000, beds: 2, baths: 1, sqft: 980, type: "Single Family", status: "Active", tags: ["Creative Financing"], views: 22, photos: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80" },
  { id: 4, address: "7890 Cedar Ln", city: "Memphis", state: "TN", price: 45000, arv: 89000, beds: 3, baths: 1, sqft: 1200, type: "Single Family", status: "Active", tags: ["Seller Financing"], views: 18, photos: "https://images.unsplash.com/photo-1449844908441-8829872d2607?w=400&q=80" },
  { id: 5, address: "2345 Birch Ct", city: "Birmingham", state: "AL", price: 55000, arv: 98000, beds: 4, baths: 2, sqft: 1800, type: "Multi Family", status: "Active", tags: ["Short Term Rental"], views: 29, photos: "https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?w=400&q=80" },
  { id: 6, address: "6543 Willow Way", city: "Nashville", state: "TN", price: 78000, arv: 130000, beds: 3, baths: 2, sqft: 1550, type: "Single Family", status: "Active", tags: ["Turnkey"], views: 35, photos: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=400&q=80" },
];

const tagColors = {
  "Turnkey": "bg-green-400/20 text-green-300",
  "Subject To": "bg-purple-400/20 text-purple-300",
  "Creative Financing": "bg-blue-400/20 text-blue-300",
  "Seller Financing": "bg-amber-400/20 text-amber-300",
  "Short Term Rental": "bg-rose-400/20 text-rose-300",
  "Portfolio": "bg-cyan-400/20 text-cyan-300",
};

const allTags = ["Turnkey", "Subject To", "Creative Financing", "Seller Financing", "Short Term Rental", "Portfolio"];

export default function Marketplace() {
  const [search, setSearch] = useState("");
  const [tagFilter, setTagFilter] = useState("All");
  const [saved, setSaved] = useState([]);

  const filtered = listings.filter(l => {
    const matchSearch = l.address.toLowerCase().includes(search.toLowerCase()) || l.city.toLowerCase().includes(search.toLowerCase());
    const matchTag = tagFilter === "All" || l.tags.includes(tagFilter);
    return matchSearch && matchTag;
  });

  const toggleSave = id => setSaved(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const equity = l => Math.round((l.arv - l.price) / l.arv * 100);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Deal Marketplace</h1>
        <p className="text-slate-400 text-sm mt-1">Browse live wholesale deals — subscribe to get notified of new listings</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by address or city..."
            className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400" />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setTagFilter("All")}
            className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${tagFilter === "All" ? "bg-amber-400 text-slate-900" : "bg-slate-800 text-slate-400 border border-slate-700 hover:text-white"}`}>
            All Deals
          </button>
          {allTags.map(t => (
            <button key={t} onClick={() => setTagFilter(t)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${tagFilter === t ? "bg-amber-400 text-slate-900" : "bg-slate-800 text-slate-400 border border-slate-700 hover:text-white"}`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Listings grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {filtered.map(l => (
          <div key={l.id} className="bg-slate-900 border border-slate-700 rounded-xl overflow-hidden hover:border-slate-500 transition-colors group">
            {/* Photo */}
            <div className="relative h-44 overflow-hidden">
              <img src={l.photos} alt={l.address} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent" />
              {/* Tags */}
              <div className="absolute top-3 left-3 flex gap-1.5 flex-wrap">
                {l.tags.map(t => (
                  <span key={t} className={`text-xs px-2 py-0.5 rounded-full font-medium ${tagColors[t] || "bg-slate-400/20 text-slate-300"}`}>{t}</span>
                ))}
              </div>
              {/* Save */}
              <button onClick={() => toggleSave(l.id)} className="absolute top-3 right-3">
                <Heart className={`w-5 h-5 transition-colors ${saved.includes(l.id) ? "fill-red-400 text-red-400" : "text-white/70 hover:text-white"}`} />
              </button>
              {/* Views */}
              <div className="absolute bottom-3 right-3 flex items-center gap-1 text-white/70 text-xs">
                <Eye className="w-3 h-3" />{l.views}
              </div>
            </div>

            {/* Info */}
            <div className="p-4">
              <p className="text-white font-semibold text-sm">{l.address}</p>
              <p className="text-slate-400 text-xs mt-0.5">{l.city}, {l.state} · {l.type}</p>
              <div className="flex items-center gap-3 text-slate-400 text-xs mt-2">
                <span className="flex items-center gap-1"><Bed className="w-3 h-3" />{l.beds}</span>
                <span className="flex items-center gap-1"><Bath className="w-3 h-3" />{l.baths}</span>
                <span className="flex items-center gap-1"><Ruler className="w-3 h-3" />{l.sqft.toLocaleString()} sqft</span>
              </div>
              <div className="mt-3 pt-3 border-t border-slate-700 flex items-center justify-between">
                <div>
                  <p className="text-white font-bold text-lg">${l.price.toLocaleString()}</p>
                  <p className="text-green-400 text-xs">ARV ${l.arv.toLocaleString()} · {equity(l)}% equity</p>
                </div>
                <button className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-semibold px-3 py-2 rounded-lg text-xs transition-colors">
                  <Zap className="w-3 h-3" /> Make Offer
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}