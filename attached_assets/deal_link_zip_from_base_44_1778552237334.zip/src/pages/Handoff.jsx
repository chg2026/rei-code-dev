export default function Handoff() {
  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans p-10 space-y-16 max-w-5xl mx-auto">

      {/* Title */}
      <div className="border-b pb-6">
        <p className="text-xs font-semibold uppercase tracking-widest text-slate-400 mb-1">Design Handoff</p>
        <h1 className="text-4xl font-bold text-slate-900">DealFlowPro — Dashboard</h1>
        <p className="text-slate-500 mt-2 text-sm">UI Specification · May 2026 · v1.0</p>
      </div>

      {/* Color Palette */}
      <section>
        <SectionTitle>Color Palette</SectionTitle>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { name: "Background", hex: "#020817", class: "bg-[#020817]" },
            { name: "Surface / Card", hex: "#0F172A", class: "bg-[#0F172A]" },
            { name: "Border", hex: "#1E293B", class: "bg-[#1E293B]" },
            { name: "Muted Text", hex: "#64748B", class: "bg-[#64748B]" },
            { name: "Body Text", hex: "#CBD5E1", class: "bg-[#CBD5E1]" },
            { name: "White", hex: "#FFFFFF", class: "bg-white border border-slate-200" },
            { name: "Amber (Primary)", hex: "#FBBF24", class: "bg-[#FBBF24]" },
            { name: "Amber Hover", hex: "#FCD34D", class: "bg-[#FCD34D]" },
          ].map(c => (
            <div key={c.name}>
              <div className={`h-14 rounded-lg ${c.class} mb-2`} />
              <p className="text-xs font-semibold text-slate-700">{c.name}</p>
              <p className="text-xs text-slate-400 font-mono">{c.hex}</p>
            </div>
          ))}
        </div>
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-5 gap-4">
          {[
            { name: "Status: New", hex: "#94A3B8", class: "bg-slate-400/20 text-slate-300" },
            { name: "Status: Marketed", hex: "#60A5FA", class: "bg-blue-400/20 text-blue-300" },
            { name: "Status: Under Contract", hex: "#FBBF24", class: "bg-amber-400/20 text-amber-300" },
            { name: "Status: Closed", hex: "#4ADE80", class: "bg-green-400/20 text-green-300" },
            { name: "Status: Dead", hex: "#F87171", class: "bg-red-400/20 text-red-300" },
          ].map(c => (
            <div key={c.name}>
              <div className={`h-10 rounded-lg flex items-center justify-center text-xs font-semibold ${c.class} mb-2`}>
                {c.name.replace("Status: ", "")}
              </div>
              <p className="text-xs font-semibold text-slate-700">{c.name}</p>
              <p className="text-xs text-slate-400 font-mono">{c.hex}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Typography */}
      <section>
        <SectionTitle>Typography</SectionTitle>
        <div className="space-y-5 border border-slate-200 rounded-xl p-6">
          <TypographyRow label="Page Title" sample="Dashboard" cls="text-4xl font-bold text-slate-900" spec="text-4xl / font-bold / #0F172A" />
          <TypographyRow label="Section Header" sample="Recent Deals" cls="text-xl font-bold text-slate-900" spec="text-xl / font-bold / #0F172A" />
          <TypographyRow label="Card Metric" sample="$142,500" cls="text-3xl font-bold text-slate-900" spec="text-3xl / font-bold / #0F172A" />
          <TypographyRow label="Card Label" sample="REVENUE (MTD)" cls="text-xs font-semibold uppercase tracking-wider text-slate-400" spec="text-xs / font-semibold / uppercase / #64748B" />
          <TypographyRow label="Body / Row Text" sample="1234 Oak Street, Atlanta, GA" cls="text-sm text-slate-700" spec="text-sm / regular / #334155" />
          <TypographyRow label="Muted / Subtext" sample="+12% vs last month" cls="text-xs text-slate-400" spec="text-xs / regular / #64748B" />
          <TypographyRow label="Nav Item" sample="Buyers List" cls="text-sm font-medium text-slate-400" spec="text-sm / medium / #64748B" />
          <TypographyRow label="Nav Group Label" sample="BUYERS" cls="text-xs font-semibold uppercase tracking-widest text-slate-500" spec="text-xs / semibold / uppercase / #64748B" />
        </div>
      </section>

      {/* Spacing & Layout */}
      <section>
        <SectionTitle>Layout & Spacing</SectionTitle>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <SpecCard title="Overall Layout">
            <SpecRow label="Type" value="Fixed sidebar + scrollable main" />
            <SpecRow label="Sidebar width" value="224px (w-56)" />
            <SpecRow label="Top bar height" value="56px (h-14)" />
            <SpecRow label="Page padding" value="24px (p-6)" />
            <SpecRow label="Content max-width" value="Full-width fluid" />
          </SpecCard>
          <SpecCard title="Sidebar">
            <SpecRow label="Background" value="#0F172A (slate-900)" />
            <SpecRow label="Border" value="Right 1px #1E293B" />
            <SpecRow label="Logo area height" value="~64px with bottom border" />
            <SpecRow label="Nav item padding" value="px-3 py-2" />
            <SpecRow label="Nav item radius" value="8px (rounded-lg)" />
            <SpecRow label="Active state" value="bg-amber-400, text-slate-900" />
          </SpecCard>
          <SpecCard title="Stat Cards (top row)">
            <SpecRow label="Background" value="#0F172A (slate-900)" />
            <SpecRow label="Border" value="1px solid #1E293B" />
            <SpecRow label="Border radius" value="12px (rounded-xl)" />
            <SpecRow label="Padding" value="20px (p-5)" />
            <SpecRow label="Grid" value="4 columns, gap-4" />
            <SpecRow label="Icon container" value="w-10 h-10, rounded-lg" />
          </SpecCard>
          <SpecCard title="Table / List Rows">
            <SpecRow label="Row padding" value="px-5 py-4" />
            <SpecRow label="Divider" value="1px solid #1E293B" />
            <SpecRow label="Hover state" value="bg-slate-800/50" />
            <SpecRow label="Icon cell" value="w-9 h-9, bg-slate-700, rounded-lg" />
          </SpecCard>
        </div>
      </section>

      {/* Component Specs */}
      <section>
        <SectionTitle>Component Specs</SectionTitle>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">

          <SpecCard title="Primary Button (Amber CTA)">
            <SpecRow label="Background" value="#FBBF24" />
            <SpecRow label="Text color" value="#0F172A (slate-900)" />
            <SpecRow label="Font weight" value="font-semibold" />
            <SpecRow label="Padding" value="px-4 py-2" />
            <SpecRow label="Border radius" value="8px (rounded-lg)" />
            <SpecRow label="Hover" value="#FCD34D (amber-300)" />
            <SpecRow label="Icon gap" value="gap-2, icon size w-4 h-4" />
          </SpecCard>

          <SpecCard title="Status Badge">
            <SpecRow label="Font size" value="text-xs" />
            <SpecRow label="Font weight" value="font-medium" />
            <SpecRow label="Padding" value="px-2 py-1" />
            <SpecRow label="Border radius" value="rounded-full" />
            <SpecRow label="Style" value="bg-[color]/20 + text-[color]-300" />
          </SpecCard>

          <SpecCard title="Top Bar">
            <SpecRow label="Background" value="#0F172A (slate-900)" />
            <SpecRow label="Border" value="Bottom 1px #1E293B" />
            <SpecRow label="Height" value="56px" />
            <SpecRow label="Avatar" value="w-8 h-8, rounded-full, bg-amber-400" />
            <SpecRow label="Notification dot" value="w-2 h-2, bg-amber-400, absolute" />
          </SpecCard>

          <SpecCard title="Section Card (Recent Deals / Activity)">
            <SpecRow label="Background" value="#0F172A" />
            <SpecRow label="Border" value="1px solid #1E293B" />
            <SpecRow label="Border radius" value="12px" />
            <SpecRow label="Padding" value="p-6 header, px-5 py-4 rows" />
            <SpecRow label="Header divider" value="mb-4 / row divider divide-y" />
          </SpecCard>

          <SpecCard title="Enterprise Badge">
            <SpecRow label="Text" value="E" />
            <SpecRow label="Background" value="bg-amber-400/20" />
            <SpecRow label="Text color" value="text-amber-400" />
            <SpecRow label="Size" value="text-xs px-1.5 py-0.5" />
            <SpecRow label="Border radius" value="rounded" />
          </SpecCard>

          <SpecCard title="Logo Lockup">
            <SpecRow label="Icon" value="Building2, w-5 h-5, text-slate-900" />
            <SpecRow label="Icon bg" value="w-8 h-8, bg-amber-400, rounded-lg" />
            <SpecRow label="Wordmark" value="DealFlow (white) + Pro (amber-400)" />
            <SpecRow label="Font" value="font-bold text-lg tracking-tight" />
          </SpecCard>
        </div>
      </section>

      {/* Screen Sections */}
      <section>
        <SectionTitle>Screen Anatomy</SectionTitle>
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-5 py-3 font-semibold text-slate-600">Zone</th>
                <th className="text-left px-5 py-3 font-semibold text-slate-600">Component</th>
                <th className="text-left px-5 py-3 font-semibold text-slate-600">Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[
                ["Left", "Sidebar Navigation", "Fixed, 224px, grouped nav with labels, amber active state"],
                ["Top", "Top Bar", "56px, notification bell + user avatar, mobile hamburger"],
                ["Top Row", "4× Stat Cards", "Active Deals, Total Buyers, Revenue MTD, Deals Closed"],
                ["Left 2/3", "Recent Deals Table", "5 rows, address + city, price + ARV, status badge"],
                ["Right 1/3", "Recent Activity Feed", "Icon + text + timestamp, 5 activity items"],
              ].map(([zone, comp, note]) => (
                <tr key={zone} className="hover:bg-slate-50">
                  <td className="px-5 py-3 font-medium text-slate-700 whitespace-nowrap">{zone}</td>
                  <td className="px-5 py-3 text-slate-600">{comp}</td>
                  <td className="px-5 py-3 text-slate-400 text-xs">{note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Grid & Responsiveness */}
      <section>
        <SectionTitle>Responsive Breakpoints</SectionTitle>
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-5 py-3 font-semibold text-slate-600">Breakpoint</th>
                <th className="text-left px-5 py-3 font-semibold text-slate-600">Sidebar</th>
                <th className="text-left px-5 py-3 font-semibold text-slate-600">Stat Cards</th>
                <th className="text-left px-5 py-3 font-semibold text-slate-600">Recent Deals / Activity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[
                ["Mobile (<768px)", "Hidden (hamburger)", "2×2 grid", "Stacked, full width"],
                ["Tablet (768–1280px)", "Visible, collapsed labels", "4 columns", "Side by side"],
                ["Desktop (>1280px)", "Full sidebar, labels visible", "4 columns", "2/3 + 1/3 split"],
              ].map(([bp, sb, sc, rd]) => (
                <tr key={bp} className="hover:bg-slate-50">
                  <td className="px-5 py-3 font-mono text-xs text-slate-700">{bp}</td>
                  <td className="px-5 py-3 text-slate-600 text-xs">{sb}</td>
                  <td className="px-5 py-3 text-slate-600 text-xs">{sc}</td>
                  <td className="px-5 py-3 text-slate-600 text-xs">{rd}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Icon Library */}
      <section>
        <SectionTitle>Icons Used (lucide-react)</SectionTitle>
        <div className="flex flex-wrap gap-3 text-xs text-slate-500">
          {["LayoutDashboard", "Building2", "Kanban", "FileText", "Globe", "Users", "Handshake", "UserCheck", "Zap", "Eye", "BarChart3", "Settings", "Bell", "Menu", "X", "ChevronRight", "Bed", "Bath", "Ruler", "Search", "Plus", "GripVertical", "DollarSign", "TrendingUp"].map(icon => (
            <span key={icon} className="bg-slate-100 px-3 py-1.5 rounded-lg font-mono">{icon}</span>
          ))}
        </div>
      </section>

      {/* Footer */}
      <div className="border-t pt-6 text-xs text-slate-400 flex justify-between">
        <span>DealFlowPro · Design Handoff v1.0</span>
        <span>Generated May 2026</span>
      </div>

    </div>
  );
}

function SectionTitle({ children }) {
  return (
    <div className="flex items-center gap-3 mb-5">
      <h2 className="text-lg font-bold text-slate-900">{children}</h2>
      <div className="flex-1 h-px bg-slate-200" />
    </div>
  );
}

function TypographyRow({ label, sample, cls, spec }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6 border-b border-slate-100 pb-4 last:border-0 last:pb-0">
      <div className="w-36 flex-shrink-0">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{label}</span>
      </div>
      <div className="flex-1">
        <p className={cls}>{sample}</p>
      </div>
      <div className="w-64 flex-shrink-0">
        <span className="text-xs font-mono text-slate-400">{spec}</span>
      </div>
    </div>
  );
}

function SpecCard({ title, children }) {
  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden">
      <div className="bg-slate-50 px-5 py-3 border-b border-slate-200">
        <h3 className="text-sm font-semibold text-slate-700">{title}</h3>
      </div>
      <div className="divide-y divide-slate-100">{children}</div>
    </div>
  );
}

function SpecRow({ label, value }) {
  return (
    <div className="flex justify-between px-5 py-2.5 text-xs">
      <span className="text-slate-500">{label}</span>
      <span className="font-mono text-slate-700 text-right">{value}</span>
    </div>
  );
}