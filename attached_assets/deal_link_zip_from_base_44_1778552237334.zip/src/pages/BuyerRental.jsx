import { useState } from "react";
import { Users, DollarSign, Clock, CheckCircle2, Plus, Eye, ToggleLeft, ToggleRight } from "lucide-react";

const myRentals = [
  { id: 1, listName: "Atlanta GA Cash Buyers (450)", rentedTo: "Mike Thompson", price: 299, period: "Monthly", status: "Active", expires: "2026-06-11", earned: 897 },
  { id: 2, listName: "Dallas TX Flippers (180)", rentedTo: "Sarah Kim", price: 199, period: "Monthly", status: "Active", expires: "2026-05-28", earned: 398 },
  { id: 3, listName: "Full National List (1,284)", rentedTo: "ProWholesale Co.", price: 799, period: "Monthly", status: "Expired", expires: "2026-04-30", earned: 2397 },
];

const available = [
  { id: 1, wholesaler: "James Carter", listName: "Memphis TN Buyers (320)", price: 249, size: 320, markets: ["Memphis, TN", "Nashville, TN"], types: ["Cash Buyer", "Landlord"], rating: 4.8, reviews: 14 },
  { id: 2, wholesaler: "Angela White", listName: "SE Region Portfolio Buyers (95)", price: 349, size: 95, markets: ["Atlanta, GA", "Birmingham, AL", "Charlotte, NC"], types: ["Developer", "Cash Buyer"], rating: 5.0, reviews: 7 },
  { id: 3, wholesaler: "Marcus Hill", listName: "Phoenix AZ Investors (210)", price: 179, size: 210, markets: ["Phoenix, AZ", "Scottsdale, AZ"], types: ["Flipper", "Landlord"], rating: 4.6, reviews: 22 },
];

export default function BuyerRental() {
  const [tab, setTab] = useState("my");
  const [enabled, setEnabled] = useState({ 1: true, 2: true, 3: false });

  const totalEarned = myRentals.reduce((s, r) => s + r.earned, 0);

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-white">Buyer Rental</h1>
          <span className="text-xs bg-rose-400/20 text-rose-300 px-2 py-0.5 rounded-full font-medium border border-rose-400/30">Enterprise</span>
        </div>
        <p className="text-slate-400 text-sm mt-1">Monetize your buyers list — rent it to other wholesalers, or rent theirs</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-slate-800 p-1 rounded-lg w-fit">
        {[["my", "My Rentals"], ["browse", "Browse Lists"]].map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${tab === key ? "bg-amber-400 text-slate-900" : "text-slate-400 hover:text-white"}`}>
            {label}
          </button>
        ))}
      </div>

      {tab === "my" && (
        <>
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: "Active Rentals", value: myRentals.filter(r => r.status === "Active").length, color: "text-green-400" },
              { label: "Total Earned", value: `$${totalEarned.toLocaleString()}`, color: "text-amber-400" },
              { label: "Lists Available", value: "3", color: "text-blue-400" },
            ].map(s => (
              <div key={s.label} className="bg-slate-900 border border-slate-700 rounded-xl p-4 text-center">
                <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
                <p className="text-slate-400 text-xs mt-1">{s.label}</p>
              </div>
            ))}
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-white font-semibold">Your Rented Lists</h2>
              <button className="flex items-center gap-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-semibold px-3 py-2 rounded-lg text-xs transition-colors">
                <Plus className="w-3 h-3" /> List My Buyers
              </button>
            </div>
            {myRentals.map(r => (
              <div key={r.id} className="bg-slate-900 border border-slate-700 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className="text-white font-semibold text-sm">{r.listName}</p>
                  <p className="text-slate-400 text-xs mt-1">Rented to: <span className="text-white">{r.rentedTo}</span></p>
                  <p className="text-slate-500 text-xs">Expires: {r.expires}</p>
                </div>
                <div className="flex items-center gap-5">
                  <div className="text-right">
                    <p className="text-white font-bold">${r.price}<span className="text-slate-400 text-xs font-normal">/{r.period.toLowerCase().replace("monthly","mo")}</span></p>
                    <p className="text-green-400 text-xs">${r.earned.toLocaleString()} earned</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${r.status === "Active" ? "bg-green-400/20 text-green-300" : "bg-slate-600 text-slate-400"}`}>{r.status}</span>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === "browse" && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {available.map(a => (
            <div key={a.id} className="bg-slate-900 border border-slate-700 rounded-xl p-5 hover:border-slate-500 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-white font-semibold text-sm">{a.listName}</p>
                  <p className="text-slate-400 text-xs mt-0.5">by {a.wholesaler}</p>
                </div>
                <div className="text-right">
                  <p className="text-white font-bold text-lg">${a.price}</p>
                  <p className="text-slate-400 text-xs">/month</p>
                </div>
              </div>
              <div className="space-y-2 text-xs text-slate-400">
                <div className="flex items-center gap-1.5"><Users className="w-3 h-3" /> {a.size.toLocaleString()} verified buyers</div>
                <div>Markets: <span className="text-slate-300">{a.markets.join(", ")}</span></div>
                <div>Buyer types: <span className="text-slate-300">{a.types.join(", ")}</span></div>
              </div>
              <div className="mt-3 pt-3 border-t border-slate-700 flex items-center justify-between">
                <div className="flex items-center gap-1 text-amber-400 text-xs font-medium">
                  ★ {a.rating} <span className="text-slate-500 ml-1">({a.reviews} reviews)</span>
                </div>
                <button className="bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold px-3 py-1.5 rounded-lg text-xs transition-colors">
                  Rent List
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}