import { useState } from "react";
import { Plus, Building2, User, DollarSign, CheckCircle2, XCircle, Clock, MessageSquare } from "lucide-react";

const mockOffers = [
  { id: 1, property: "1234 Oak Street, Atlanta GA", buyer: "James Carter", amount: 82000, asking: 85000, status: "Pending", date: "2026-05-10", notes: "Cash, can close in 10 days" },
  { id: 2, property: "1234 Oak Street, Atlanta GA", buyer: "Angela White", amount: 80000, asking: 85000, status: "Rejected", date: "2026-05-09", notes: "Too low" },
  { id: 3, property: "5678 Pine Ave, Dallas TX", buyer: "Maria Rodriguez", amount: 118000, asking: 120000, status: "Accepted", date: "2026-05-08", notes: "Approved financing, 14 day close" },
  { id: 4, property: "7890 Cedar Ln, Memphis TN", buyer: "Sandra Lee", amount: 44000, asking: 45000, status: "Countered", date: "2026-05-07", notes: "Countered at $46,500" },
  { id: 5, property: "9012 Maple Dr, Phoenix AZ", buyer: "Derek Thompson", amount: 65000, asking: 67000, status: "Pending", date: "2026-05-11", notes: "Subject to inspection" },
];

const statusConfig = {
  "Pending": { color: "bg-amber-400/20 text-amber-300", icon: Clock },
  "Accepted": { color: "bg-green-400/20 text-green-300", icon: CheckCircle2 },
  "Rejected": { color: "bg-red-400/20 text-red-300", icon: XCircle },
  "Countered": { color: "bg-blue-400/20 text-blue-300", icon: MessageSquare },
};

export default function Offers() {
  const [showModal, setShowModal] = useState(false);

  const pendingCount = mockOffers.filter(o => o.status === "Pending").length;
  const acceptedCount = mockOffers.filter(o => o.status === "Accepted").length;
  const totalVolume = mockOffers.filter(o => o.status === "Accepted").reduce((sum, o) => sum + o.amount, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Offers</h1>
          <p className="text-slate-400 text-sm mt-1">{mockOffers.length} total offers received</p>
        </div>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-semibold px-4 py-2 rounded-lg text-sm transition-colors">
          <Plus className="w-4 h-4" /> Log Offer
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Pending Review", value: pendingCount, color: "text-amber-400" },
          { label: "Accepted", value: acceptedCount, color: "text-green-400" },
          { label: "Accepted Volume", value: `$${totalVolume.toLocaleString()}`, color: "text-white" },
        ].map(s => (
          <div key={s.label} className="bg-slate-900 border border-slate-700 rounded-xl p-4 text-center">
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-slate-400 text-xs mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Offers list */}
      <div className="space-y-3">
        {mockOffers.map(offer => {
          const { color, icon: StatusIcon } = statusConfig[offer.status];
          const diff = offer.amount - offer.asking;
          return (
            <div key={offer.id} className="bg-slate-900 border border-slate-700 rounded-xl p-5 hover:border-slate-500 transition-colors">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 bg-slate-700 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Building2 className="w-4 h-4 text-slate-400" />
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{offer.property}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <User className="w-3 h-3 text-slate-400" />
                      <span className="text-slate-400 text-xs">{offer.buyer}</span>
                      <span className="text-slate-600 text-xs mx-1">·</span>
                      <span className="text-slate-500 text-xs">{offer.date}</span>
                    </div>
                    {offer.notes && <p className="text-slate-500 text-xs mt-1 italic">"{offer.notes}"</p>}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-white font-bold text-lg">${offer.amount.toLocaleString()}</p>
                    <p className={`text-xs font-medium ${diff >= 0 ? "text-green-400" : "text-red-400"}`}>
                      {diff >= 0 ? "+" : ""}${diff.toLocaleString()} vs asking
                    </p>
                  </div>
                  <span className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full font-medium ${color}`}>
                    <StatusIcon className="w-3 h-3" />{offer.status}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowModal(false)} />
          <div className="relative bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-md">
            <h2 className="text-white font-bold text-lg mb-4">Log New Offer</h2>
            <div className="space-y-3">
              {[["Property", "property"], ["Buyer Name", "buyer"], ["Offer Amount", "amount"], ["Notes", "notes"]].map(([label, key]) => (
                <div key={key}>
                  <label className="text-slate-400 text-xs block mb-1">{label}</label>
                  {key === "notes"
                    ? <textarea className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 h-20 resize-none" placeholder={label} />
                    : <input className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400" placeholder={label} />
                  }
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowModal(false)} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-lg text-sm font-medium">Cancel</button>
              <button className="flex-1 bg-amber-400 hover:bg-amber-300 text-slate-900 px-4 py-2 rounded-lg text-sm font-bold">Save Offer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}