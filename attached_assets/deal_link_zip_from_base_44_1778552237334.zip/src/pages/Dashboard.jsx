import { Building2, Users, DollarSign, TrendingUp, ArrowUpRight, Clock, CheckCircle2, AlertCircle } from "lucide-react";

const stats = [
  { label: "Active Deals", value: "24", change: "+3 this week", icon: Building2, color: "text-blue-400", bg: "bg-blue-400/10" },
  { label: "Total Buyers", value: "1,284", change: "+47 this month", icon: Users, color: "text-green-400", bg: "bg-green-400/10" },
  { label: "Revenue (MTD)", value: "$142,500", change: "+12% vs last month", icon: DollarSign, color: "text-amber-400", bg: "bg-amber-400/10" },
  { label: "Deals Closed", value: "8", change: "This month", icon: TrendingUp, color: "text-purple-400", bg: "bg-purple-400/10" },
];

const recentDeals = [
  { address: "1234 Oak Street", city: "Atlanta, GA", price: "$85,000", arv: "$140,000", status: "Marketed", statusColor: "bg-blue-400/20 text-blue-300" },
  { address: "5678 Pine Ave", city: "Dallas, TX", price: "$120,000", arv: "$195,000", status: "Under Contract", statusColor: "bg-amber-400/20 text-amber-300" },
  { address: "9012 Maple Dr", city: "Phoenix, AZ", price: "$67,000", arv: "$110,000", status: "New", statusColor: "bg-slate-400/20 text-slate-300" },
  { address: "3456 Elm Blvd", city: "Houston, TX", price: "$95,000", arv: "$158,000", status: "Closed", statusColor: "bg-green-400/20 text-green-300" },
  { address: "7890 Cedar Ln", city: "Memphis, TN", price: "$45,000", arv: "$89,000", status: "Marketed", statusColor: "bg-blue-400/20 text-blue-300" },
];

const recentActivity = [
  { icon: CheckCircle2, color: "text-green-400", text: "Offer accepted on 5678 Pine Ave", time: "2 hours ago" },
  { icon: Users, color: "text-blue-400", text: "New buyer John Smith added", time: "4 hours ago" },
  { icon: Building2, color: "text-amber-400", text: "New property listed at 9012 Maple Dr", time: "6 hours ago" },
  { icon: AlertCircle, color: "text-purple-400", text: "Deal blast sent to 248 buyers", time: "1 day ago" },
  { icon: Clock, color: "text-slate-400", text: "Follow-up reminder: 1234 Oak Street", time: "1 day ago" },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-slate-400 text-sm mt-1">Welcome back — here's what's happening today.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-slate-400 text-xs font-medium uppercase tracking-wider">{stat.label}</p>
                <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
                <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                  <ArrowUpRight className="w-3 h-3 text-green-400" />{stat.change}
                </p>
              </div>
              <div className={`${stat.bg} p-2.5 rounded-lg`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Recent Deals */}
        <div className="xl:col-span-2 bg-slate-900 border border-slate-700 rounded-xl">
          <div className="px-5 py-4 border-b border-slate-700 flex items-center justify-between">
            <h2 className="text-white font-semibold">Recent Deals</h2>
            <a href="/properties" className="text-amber-400 text-xs hover:underline">View all →</a>
          </div>
          <div className="divide-y divide-slate-700">
            {recentDeals.map((deal, i) => (
              <div key={i} className="px-5 py-3 flex items-center justify-between hover:bg-slate-800/50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-slate-700 rounded-lg flex items-center justify-center">
                    <Building2 className="w-4 h-4 text-slate-400" />
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium">{deal.address}</p>
                    <p className="text-slate-400 text-xs">{deal.city}</p>
                  </div>
                </div>
                <div className="text-right hidden sm:block">
                  <p className="text-white text-sm font-semibold">{deal.price}</p>
                  <p className="text-slate-400 text-xs">ARV: {deal.arv}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${deal.statusColor}`}>{deal.status}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Activity Feed */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl">
          <div className="px-5 py-4 border-b border-slate-700">
            <h2 className="text-white font-semibold">Recent Activity</h2>
          </div>
          <div className="p-5 space-y-4">
            {recentActivity.map((item, i) => (
              <div key={i} className="flex gap-3">
                <item.icon className={`w-4 h-4 mt-0.5 flex-shrink-0 ${item.color}`} />
                <div>
                  <p className="text-slate-300 text-sm">{item.text}</p>
                  <p className="text-slate-500 text-xs mt-0.5">{item.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}