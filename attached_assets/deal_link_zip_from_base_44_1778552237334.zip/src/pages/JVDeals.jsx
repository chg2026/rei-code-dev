import { useState } from "react";
import { Handshake, Plus, Users, DollarSign, Building2, CheckCircle2, Clock, XCircle } from "lucide-react";

const jvDeals = [
  { id: 1, property: "3456 Elm Blvd, Houston TX", partner: "Maria Rodriguez", myRole: "Buyer Finder", partnerRole: "Deal Sourcer", splitPercent: 50, status: "Active", dealValue: 95000, projectedProfit: 28000, created: "2026-04-20" },
  { id: 2, property: "8765 Sunset Dr, Orlando FL", partner: "Kevin Brooks", myRole: "Deal Sourcer", partnerRole: "Buyer Finder", splitPercent: 60, status: "Pending", dealValue: 140000, projectedProfit: 35000, created: "2026-05-01" },
  { id: 3, property: "1122 River Rd, Charlotte NC", partner: "James Carter", myRole: "Buyer Finder", partnerRole: "Deal Sourcer", splitPercent: 50, status: "Closed", dealValue: 78000, projectedProfit: 18500, created: "2026-03-10" },
  { id: 4, property: "4433 Market St, Denver CO", partner: "Sandra Lee", myRole: "Deal Sourcer", partnerRole: "Buyer Finder", splitPercent: 40, status: "Pending", dealValue: 210000, projectedProfit: 45000, created: "2026-05-08" },
];

const statusConfig = {
  Active: { color: "bg-blue-400/20 text-blue-300", icon: Clock },
  Pending: { color: "bg-amber-400/20 text-amber-300", icon: Clock },
  Closed: { color: "bg-green-400/20 text-green-300", icon: CheckCircle2 },
  Declined: { color: "bg-red-400/20 text-red-300", icon: XCircle },
};

export default function JVDeals() {
  const [showModal, setShowModal] = useState(false);

  const totalProfit = jvDeals.filter(j => j.status === "Closed").reduce((s, j) => s + j.projectedProfit, 0);
  const activeCount = jvDeals.filter(j => j.status === "Active").length;
  const pendingCount = jvDeals.filter(j => j.status === "Pending").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-white">JV Deals</h1>
            <span className="text-xs bg-green-400/20 text-green-300 px-2 py-0.5 rounded-full font-medium border border-green-400/30">Enterprise</span>
          </div>
          <p className="text-slate-400 text-sm mt-1">Collaborate with other wholesalers — split profits, share buyers and deals</p>
        </div>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-semibold px-4 py-2 rounded-lg text-sm transition-colors">
          <Plus className="w-4 h-4" /> New JV Deal
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Active JVs", value: activeCount, color: "text-blue-400" },
          { label: "Pending", value: pendingCount, color: "text-amber-400" },
          { label: "Closed Profit", value: `$${totalProfit.toLocaleString()}`, color: "text-green-400" },
        ].map(s => (
          <div key={s.label} className="bg-slate-900 border border-slate-700 rounded-xl p-4 text-center">
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-slate-400 text-xs mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* JV list */}
      <div className="space-y-4">
        {jvDeals.map(jv => {
          const { color, icon: StatusIcon } = statusConfig[jv.status];
          return (
            <div key={jv.id} className="bg-slate-900 border border-slate-700 rounded-xl p-5 hover:border-slate-500 transition-colors">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-slate-700 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Handshake className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{jv.property}</p>
                    <div className="flex items-center gap-4 mt-1 text-xs text-slate-400">
                      <span className="flex items-center gap-1"><Users className="w-3 h-3" /> Partner: <span className="text-white ml-1">{jv.partner}</span></span>
                      <span>Created {jv.created}</span>
                    </div>
                    <div className="flex items-center gap-3 mt-2">
                      <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded">Your role: {jv.myRole}</span>
                      <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded">Split: {jv.splitPercent}/{100 - jv.splitPercent}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-5">
                  <div className="text-right">
                    <p className="text-white font-bold">${jv.dealValue.toLocaleString()}</p>
                    <p className="text-green-400 text-xs">+${jv.projectedProfit.toLocaleString()} projected</p>
                  </div>
                  <span className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full font-medium ${color}`}>
                    <StatusIcon className="w-3 h-3" />{jv.status}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowModal(false)} />
          <div className="relative bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-md">
            <h2 className="text-white font-bold text-lg mb-4">Create JV Deal</h2>
            <div className="space-y-3">
              {[["Property Address", "property"], ["Partner Name or Email", "partner"], ["Your Role", "role"], ["Your Split %", "split"]].map(([label, key]) => (
                <div key={key}>
                  <label className="text-slate-400 text-xs block mb-1">{label}</label>
                  <input className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400" placeholder={label} />
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowModal(false)} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-lg text-sm font-medium">Cancel</button>
              <button className="flex-1 bg-amber-400 hover:bg-amber-300 text-slate-900 px-4 py-2 rounded-lg text-sm font-bold">Send Invite</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}