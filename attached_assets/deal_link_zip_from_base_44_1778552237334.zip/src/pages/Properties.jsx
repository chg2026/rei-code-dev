import { useState } from "react";
import { Plus, Search, Filter, Building2, Bed, Bath, Ruler, Eye } from "lucide-react";

const mockProperties = [
  { id: 1, address: "1234 Oak Street", city: "Atlanta", state: "GA", asking_price: 85000, arv: 140000, beds: 3, baths: 2, sqft: 1400, property_type: "Single Family", status: "Marketed" },
  { id: 2, address: "5678 Pine Ave", city: "Dallas", state: "TX", asking_price: 120000, arv: 195000, beds: 4, baths: 3, sqft: 2100, property_type: "Single Family", status: "Under Contract" },
  { id: 3, address: "9012 Maple Dr", city: "Phoenix", state: "AZ", asking_price: 67000, arv: 110000, beds: 2, baths: 1, sqft: 980, property_type: "Single Family", status: "New" },
  { id: 4, address: "3456 Elm Blvd", city: "Houston", state: "TX", asking_price: 95000, arv: 158000, beds: 3, baths: 2, sqft: 1650, property_type: "Single Family", status: "Closed" },
  { id: 5, address: "7890 Cedar Ln", city: "Memphis", state: "TN", asking_price: 45000, arv: 89000, beds: 3, baths: 1, sqft: 1200, property_type: "Single Family", status: "Marketed" },
  { id: 6, address: "2345 Birch Ct", city: "Birmingham", state: "AL", asking_price: 55000, arv: 98000, beds: 4, baths: 2, sqft: 1800, property_type: "Multi Family", status: "New" },
];

const statusColors = {
  "New": "bg-slate-400/20 text-slate-300",
  "Marketed": "bg-blue-400/20 text-blue-300",
  "Under Contract": "bg-amber-400/20 text-amber-300",
  "Closed": "bg-green-400/20 text-green-300",
  "Dead": "bg-red-400/20 text-red-300",
};

export default function Properties() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);

  const filtered = mockProperties.filter(p => {
    const matchSearch = p.address.toLowerCase().includes(search.toLowerCase()) || p.city.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "All" || p.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Properties</h1>
          <p className="text-slate-400 text-sm mt-1">{mockProperties.length} active listings</p>
        </div>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-semibold px-4 py-2 rounded-lg text-sm transition-colors">
          <Plus className="w-4 h-4" /> Add Property
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by address or city..."
            className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {["All", "New", "Marketed", "Under Contract", "Closed"].map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${statusFilter === s ? "bg-amber-400 text-slate-900" : "bg-slate-800 text-slate-400 border border-slate-700 hover:text-white"}`}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-slate-900 border border-slate-700 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left px-5 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider">Property</th>
                <th className="text-left px-5 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider hidden sm:table-cell">Asking Price</th>
                <th className="text-left px-5 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider hidden md:table-cell">ARV</th>
                <th className="text-left px-5 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider hidden lg:table-cell">Details</th>
                <th className="text-left px-5 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider">Status</th>
                <th className="px-5 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {filtered.map(p => (
                <tr key={p.id} className="hover:bg-slate-800/50 transition-colors">
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 bg-slate-700 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Building2 className="w-4 h-4 text-slate-400" />
                      </div>
                      <div>
                        <p className="text-white text-sm font-medium">{p.address}</p>
                        <p className="text-slate-400 text-xs">{p.city}, {p.state} · {p.property_type}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-4 hidden sm:table-cell">
                    <p className="text-white text-sm font-semibold">${p.asking_price.toLocaleString()}</p>
                  </td>
                  <td className="px-5 py-4 hidden md:table-cell">
                    <p className="text-green-400 text-sm font-semibold">${p.arv.toLocaleString()}</p>
                    <p className="text-slate-500 text-xs">{Math.round((p.arv - p.asking_price) / p.arv * 100)}% equity</p>
                  </td>
                  <td className="px-5 py-4 hidden lg:table-cell">
                    <div className="flex items-center gap-3 text-slate-400 text-xs">
                      <span className="flex items-center gap-1"><Bed className="w-3 h-3" />{p.beds}</span>
                      <span className="flex items-center gap-1"><Bath className="w-3 h-3" />{p.baths}</span>
                      <span className="flex items-center gap-1"><Ruler className="w-3 h-3" />{p.sqft.toLocaleString()}</span>
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${statusColors[p.status]}`}>{p.status}</span>
                  </td>
                  <td className="px-5 py-4">
                    <button className="text-slate-400 hover:text-amber-400 transition-colors">
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Property Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowModal(false)} />
          <div className="relative bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-lg">
            <h2 className="text-white font-bold text-lg mb-4">Add New Property</h2>
            <div className="grid grid-cols-2 gap-4">
              {[["Address", "address"], ["City", "city"], ["State", "state"], ["ZIP", "zip"], ["Asking Price", "asking_price"], ["ARV", "arv"], ["Beds", "beds"], ["Baths", "baths"]].map(([label, key]) => (
                <div key={key} className={key === "address" ? "col-span-2" : ""}>
                  <label className="text-slate-400 text-xs block mb-1">{label}</label>
                  <input className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400" placeholder={label} />
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowModal(false)} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">Cancel</button>
              <button className="flex-1 bg-amber-400 hover:bg-amber-300 text-slate-900 px-4 py-2 rounded-lg text-sm font-bold transition-colors">Save Property</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}