import { useState } from "react";
import { Search, MapPin, Plus, Star, Shield, TrendingUp, Filter } from "lucide-react";

const mockBuyerResults = [
  { id: 1, name: "James Carter", type: "Cash Buyer", location: "Atlanta, GA", lastPurchase: "2026-04-15", purchasePrice: 87000, propType: "Single Family", deals: 14, score: 94, vetted: true, vip: true },
  { id: 2, name: "Angela White", type: "Flipper", location: "Atlanta, GA", lastPurchase: "2026-03-22", purchasePrice: 92000, propType: "Single Family", deals: 8, score: 81, vetted: true, vip: false },
  { id: 3, name: "Marcus Hill", type: "Landlord", location: "Decatur, GA", lastPurchase: "2026-02-18", purchasePrice: 74000, propType: "Multi Family", deals: 22, score: 97, vetted: true, vip: true },
  { id: 4, name: "Tanya Brooks", type: "Cash Buyer", location: "Smyrna, GA", lastPurchase: "2026-04-30", purchasePrice: 81000, propType: "Single Family", deals: 5, score: 67, vetted: false, vip: false },
  { id: 5, name: "Devon Ray", type: "Developer", location: "Atlanta, GA", lastPurchase: "2026-01-12", purchasePrice: 155000, propType: "Multi Family", deals: 3, score: 58, vetted: true, vip: false },
  { id: 6, name: "Lucia Fernandez", type: "Wholesaler", location: "Marietta, GA", lastPurchase: "2026-05-01", purchasePrice: 65000, propType: "Land", deals: 11, score: 88, vetted: true, vip: false },
];

const propTypes = ["Any", "Single Family", "Multi Family", "Condo", "Land", "Commercial"];

const scoreColor = (score) => {
  if (score >= 90) return "text-green-400";
  if (score >= 70) return "text-amber-400";
  return "text-red-400";
};

export default function GodMode() {
  const [address, setAddress] = useState("");
  const [radius, setRadius] = useState("10");
  const [propType, setPropType] = useState("Any");
  const [searched, setSearched] = useState(true);
  const [selected, setSelected] = useState([]);

  const toggleSelect = (id) => setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-white">God Mode</h1>
            <span className="text-xs bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded-full font-medium border border-amber-400/30">Enterprise</span>
          </div>
          <p className="text-slate-400 text-sm mt-1">Find exactly who's buying in any market — add them to your list instantly</p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-64">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400" />
            <input value={address} onChange={e => setAddress(e.target.value)}
              placeholder="Enter any address or zip code..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400" />
          </div>
          <select value={radius} onChange={e => setRadius(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400">
            {["1","5","10","25","50"].map(r => <option key={r} value={r}>{r} mile radius</option>)}
          </select>
          <select value={propType} onChange={e => setPropType(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400">
            {propTypes.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <button onClick={() => setSearched(true)}
            className="bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold px-5 py-2.5 rounded-lg text-sm transition-colors flex items-center gap-2">
            <Search className="w-4 h-4" /> Find Buyers
          </button>
        </div>
      </div>

      {searched && (
        <>
          {/* Results header */}
          <div className="flex items-center justify-between">
            <p className="text-slate-400 text-sm"><span className="text-white font-semibold">{mockBuyerResults.length} buyers</span> found buying in this market</p>
            {selected.length > 0 && (
              <button className="bg-amber-400 hover:bg-amber-300 text-slate-900 font-semibold px-4 py-2 rounded-lg text-sm transition-colors flex items-center gap-2">
                <Plus className="w-4 h-4" /> Add {selected.length} to My List
              </button>
            )}
          </div>

          {/* Market heat stats */}
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: "Avg Purchase Price", value: "$92,800" },
              { label: "Deals Last 90 Days", value: "63" },
              { label: "Market Activity", value: "🔥 Very Hot" },
            ].map(s => (
              <div key={s.label} className="bg-slate-900 border border-slate-700 rounded-xl p-4 text-center">
                <p className="text-white font-bold text-lg">{s.value}</p>
                <p className="text-slate-400 text-xs mt-1">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Buyer results */}
          <div className="bg-slate-900 border border-slate-700 rounded-xl overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="w-10 px-4 py-3"></th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider">Buyer</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider hidden md:table-cell">Last Purchase</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider hidden lg:table-cell">Price Paid</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider hidden sm:table-cell">Type</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider">Score</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {mockBuyerResults.map(b => (
                  <tr key={b.id} className={`hover:bg-slate-800/50 transition-colors ${selected.includes(b.id) ? "bg-amber-400/5" : ""}`}>
                    <td className="px-4 py-3">
                      <input type="checkbox" checked={selected.includes(b.id)} onChange={() => toggleSelect(b.id)}
                        className="w-4 h-4 rounded accent-amber-400" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                          {b.name.split(" ").map(n => n[0]).join("")}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <p className="text-white text-sm font-medium">{b.name}</p>
                            {b.vip && <span className="text-xs bg-amber-400/20 text-amber-300 px-1.5 py-0.5 rounded font-medium">VIP</span>}
                            {b.vetted && <Shield className="w-3 h-3 text-blue-400" title="Vetted" />}
                          </div>
                          <p className="text-slate-500 text-xs">{b.location} · {b.deals} deals</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <p className="text-slate-300 text-sm">{b.lastPurchase}</p>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      <p className="text-white text-sm font-semibold">${b.purchasePrice.toLocaleString()}</p>
                      <p className="text-slate-500 text-xs">{b.propType}</p>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded">{b.type}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <span className={`font-bold text-sm ${scoreColor(b.score)}`}>{b.score}</span>
                        <Star className="w-3 h-3 text-slate-500" />
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <button onClick={() => toggleSelect(b.id)}
                        className="text-xs bg-slate-700 hover:bg-amber-400 hover:text-slate-900 text-white px-3 py-1.5 rounded-lg transition-colors font-medium">
                        {selected.includes(b.id) ? "Added ✓" : "+ Add"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}