import { useState } from "react";
import { Plus, Search, Users, Mail, Phone, MapPin, Star } from "lucide-react";

const mockBuyers = [
  { id: 1, name: "James Carter", email: "james@example.com", phone: "404-555-0101", markets: ["Atlanta, GA", "Birmingham, AL"], min_price: 50000, max_price: 150000, buyer_type: "Cash Buyer", status: "Active" },
  { id: 2, name: "Maria Rodriguez", email: "maria@example.com", phone: "214-555-0202", markets: ["Dallas, TX", "Houston, TX"], min_price: 80000, max_price: 250000, buyer_type: "Flipper", status: "Active" },
  { id: 3, name: "Derek Thompson", email: "derek@example.com", phone: "602-555-0303", markets: ["Phoenix, AZ"], min_price: 40000, max_price: 120000, buyer_type: "Landlord", status: "Active" },
  { id: 4, name: "Sandra Lee", email: "sandra@example.com", phone: "901-555-0404", markets: ["Memphis, TN", "Nashville, TN"], min_price: 30000, max_price: 100000, buyer_type: "Wholesaler", status: "Inactive" },
  { id: 5, name: "Kevin Brooks", email: "kevin@example.com", phone: "713-555-0505", markets: ["Houston, TX"], min_price: 100000, max_price: 500000, buyer_type: "Developer", status: "Active" },
  { id: 6, name: "Angela White", email: "angela@example.com", phone: "404-555-0606", markets: ["Atlanta, GA"], min_price: 60000, max_price: 200000, buyer_type: "Cash Buyer", status: "Active" },
];

const typeColors = {
  "Cash Buyer": "bg-green-400/20 text-green-300",
  "Wholesaler": "bg-blue-400/20 text-blue-300",
  "Flipper": "bg-amber-400/20 text-amber-300",
  "Landlord": "bg-purple-400/20 text-purple-300",
  "Developer": "bg-rose-400/20 text-rose-300",
};

export default function Buyers() {
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);

  const filtered = mockBuyers.filter(b => {
    const matchSearch = b.name.toLowerCase().includes(search.toLowerCase()) || b.email.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "All" || b.buyer_type === typeFilter;
    return matchSearch && matchType;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Buyers List</h1>
          <p className="text-slate-400 text-sm mt-1">{mockBuyers.length} buyers in your network</p>
        </div>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-semibold px-4 py-2 rounded-lg text-sm transition-colors">
          <Plus className="w-4 h-4" /> Add Buyer
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search buyers..."
            className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400" />
        </div>
        <div className="flex gap-2 flex-wrap">
          {["All", "Cash Buyer", "Flipper", "Landlord", "Wholesaler", "Developer"].map(t => (
            <button key={t} onClick={() => setTypeFilter(t)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${typeFilter === t ? "bg-amber-400 text-slate-900" : "bg-slate-800 text-slate-400 border border-slate-700 hover:text-white"}`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(b => (
          <div key={b.id} className="bg-slate-900 border border-slate-700 rounded-xl p-5 hover:border-slate-500 transition-colors">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center text-white font-bold text-sm">
                  {b.name.split(" ").map(n => n[0]).join("")}
                </div>
                <div>
                  <p className="text-white font-semibold text-sm">{b.name}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${typeColors[b.buyer_type]}`}>{b.buyer_type}</span>
                </div>
              </div>
              <div className={`w-2 h-2 rounded-full mt-2 ${b.status === "Active" ? "bg-green-400" : "bg-slate-500"}`} title={b.status} />
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-slate-400 text-xs">
                <Mail className="w-3 h-3" /><span className="truncate">{b.email}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400 text-xs">
                <Phone className="w-3 h-3" /><span>{b.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400 text-xs">
                <MapPin className="w-3 h-3" /><span className="truncate">{b.markets.join(", ")}</span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-700 flex items-center justify-between">
              <div>
                <p className="text-slate-500 text-xs">Budget Range</p>
                <p className="text-white text-xs font-semibold">${b.min_price.toLocaleString()} – ${b.max_price.toLocaleString()}</p>
              </div>
              <button className="text-xs bg-slate-700 hover:bg-amber-400 hover:text-slate-900 text-white px-3 py-1.5 rounded-lg transition-colors font-medium">
                Send Deal
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Buyer Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowModal(false)} />
          <div className="relative bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-lg">
            <h2 className="text-white font-bold text-lg mb-4">Add New Buyer</h2>
            <div className="grid grid-cols-2 gap-4">
              {[["Full Name", "name"], ["Email", "email"], ["Phone", "phone"], ["Markets", "markets"], ["Min Budget", "min_price"], ["Max Budget", "max_price"]].map(([label, key]) => (
                <div key={key} className={key === "name" || key === "markets" ? "col-span-2" : ""}>
                  <label className="text-slate-400 text-xs block mb-1">{label}</label>
                  <input className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400" placeholder={label} />
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowModal(false)} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-lg text-sm font-medium">Cancel</button>
              <button className="flex-1 bg-amber-400 hover:bg-amber-300 text-slate-900 px-4 py-2 rounded-lg text-sm font-bold">Save Buyer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}