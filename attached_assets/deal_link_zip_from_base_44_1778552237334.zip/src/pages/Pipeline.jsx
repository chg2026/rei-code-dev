import { Building2, DollarSign, GripVertical } from "lucide-react";

const columns = [
  { id: "New", label: "New", color: "border-slate-500", dot: "bg-slate-400" },
  { id: "Marketed", label: "Marketed", color: "border-blue-500", dot: "bg-blue-400" },
  { id: "Under Contract", label: "Under Contract", color: "border-amber-500", dot: "bg-amber-400" },
  { id: "Closed", label: "Closed", color: "border-green-500", dot: "bg-green-400" },
  { id: "Dead", label: "Dead", color: "border-red-500", dot: "bg-red-400" },
];

const deals = [
  { id: 1, address: "9012 Maple Dr", city: "Phoenix, AZ", price: 67000, arv: 110000, type: "Single Family", status: "New" },
  { id: 2, address: "2345 Birch Ct", city: "Birmingham, AL", price: 55000, arv: 98000, type: "Multi Family", status: "New" },
  { id: 3, address: "1234 Oak Street", city: "Atlanta, GA", price: 85000, arv: 140000, type: "Single Family", status: "Marketed" },
  { id: 4, address: "7890 Cedar Ln", city: "Memphis, TN", price: 45000, arv: 89000, type: "Single Family", status: "Marketed" },
  { id: 5, address: "5678 Pine Ave", city: "Dallas, TX", price: 120000, arv: 195000, type: "Single Family", status: "Under Contract" },
  { id: 6, address: "3456 Elm Blvd", city: "Houston, TX", price: 95000, arv: 158000, type: "Single Family", status: "Closed" },
];

export default function Pipeline() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Deal Pipeline</h1>
        <p className="text-slate-400 text-sm mt-1">Track every deal from lead to close</p>
      </div>

      {/* Pipeline board */}
      <div className="flex gap-4 overflow-x-auto pb-4">
        {columns.map(col => {
          const colDeals = deals.filter(d => d.status === col.id);
          const totalValue = colDeals.reduce((sum, d) => sum + d.price, 0);

          return (
            <div key={col.id} className="flex-shrink-0 w-64">
              {/* Column Header */}
              <div className={`flex items-center justify-between mb-3 pb-3 border-b-2 ${col.color}`}>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${col.dot}`} />
                  <span className="text-white font-semibold text-sm">{col.label}</span>
                  <span className="bg-slate-700 text-slate-300 text-xs w-5 h-5 rounded-full flex items-center justify-center">{colDeals.length}</span>
                </div>
                {totalValue > 0 && (
                  <span className="text-slate-400 text-xs">${(totalValue / 1000).toFixed(0)}k</span>
                )}
              </div>

              {/* Cards */}
              <div className="space-y-3">
                {colDeals.map(deal => (
                  <div key={deal.id} className="bg-slate-900 border border-slate-700 rounded-xl p-4 cursor-grab hover:border-slate-500 transition-colors">
                    <div className="flex items-start gap-2">
                      <GripVertical className="w-3 h-3 text-slate-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-white text-xs font-semibold truncate">{deal.address}</p>
                        <p className="text-slate-400 text-xs">{deal.city}</p>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-slate-700">
                      <div className="flex justify-between text-xs">
                        <div>
                          <p className="text-slate-500">Asking</p>
                          <p className="text-white font-semibold">${deal.price.toLocaleString()}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-slate-500">ARV</p>
                          <p className="text-green-400 font-semibold">${deal.arv.toLocaleString()}</p>
                        </div>
                      </div>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-slate-500 text-xs">{deal.type}</span>
                      <button className="text-xs text-amber-400 hover:underline">View →</button>
                    </div>
                  </div>
                ))}

                {/* Drop zone placeholder */}
                <div className="border-2 border-dashed border-slate-700 rounded-xl h-16 flex items-center justify-center">
                  <span className="text-slate-600 text-xs">+ Drop here</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}