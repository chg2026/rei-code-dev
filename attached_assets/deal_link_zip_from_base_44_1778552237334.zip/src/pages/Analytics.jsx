import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";

const monthlyRevenue = [
  { month: "Nov", revenue: 98000, deals: 5 },
  { month: "Dec", revenue: 115000, deals: 6 },
  { month: "Jan", revenue: 87000, deals: 4 },
  { month: "Feb", revenue: 132000, deals: 7 },
  { month: "Mar", revenue: 120000, deals: 6 },
  { month: "Apr", revenue: 158000, deals: 8 },
  { month: "May", revenue: 142500, deals: 8 },
];

const dealsByType = [
  { name: "Single Family", value: 62 },
  { name: "Multi Family", value: 18 },
  { name: "Condo", value: 10 },
  { name: "Land", value: 7 },
  { name: "Commercial", value: 3 },
];

const COLORS = ["#f59e0b", "#3b82f6", "#8b5cf6", "#10b981", "#ef4444"];

const topBuyers = [
  { name: "Maria Rodriguez", deals: 7, volume: "$892,000" },
  { name: "James Carter", deals: 5, volume: "$520,000" },
  { name: "Kevin Brooks", deals: 4, volume: "$610,000" },
  { name: "Derek Thompson", deals: 3, volume: "$278,000" },
  { name: "Angela White", deals: 3, volume: "$315,000" },
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-800 border border-slate-600 rounded-lg p-3">
        <p className="text-slate-300 text-xs mb-1">{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color }} className="text-sm font-semibold">
            {p.name === "revenue" ? `$${p.value.toLocaleString()}` : `${p.value} deals`}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Analytics</h1>
        <p className="text-slate-400 text-sm mt-1">Performance overview — last 7 months</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          { label: "Total Revenue (YTD)", value: "$852,500", sub: "+23% vs last year" },
          { label: "Deals Closed (YTD)", value: "44", sub: "Avg 6.3/month" },
          { label: "Avg Days to Close", value: "18", sub: "Industry avg: 24" },
          { label: "Avg Deal Profit", value: "$19,375", sub: "Per transaction" },
        ].map(k => (
          <div key={k.label} className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <p className="text-slate-400 text-xs uppercase tracking-wider font-medium">{k.label}</p>
            <p className="text-2xl font-bold text-white mt-1">{k.value}</p>
            <p className="text-green-400 text-xs mt-1">{k.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="xl:col-span-2 bg-slate-900 border border-slate-700 rounded-xl p-5">
          <h2 className="text-white font-semibold mb-4">Monthly Revenue</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthlyRevenue}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="revenue" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie Chart */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
          <h2 className="text-white font-semibold mb-4">Deals by Type</h2>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={dealsByType} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                {dealsByType.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip formatter={(v) => `${v}%`} contentStyle={{ background: "#1e293b", border: "1px solid #475569", borderRadius: 8 }} labelStyle={{ color: "#fff" }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {dealsByType.map((d, i) => (
              <div key={d.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ background: COLORS[i] }} />
                  <span className="text-slate-400 text-xs">{d.name}</span>
                </div>
                <span className="text-slate-300 text-xs font-semibold">{d.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Deals trend */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
          <h2 className="text-white font-semibold mb-4">Deals Closed / Month</h2>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={monthlyRevenue}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="deals" stroke="#3b82f6" strokeWidth={2} dot={{ fill: "#3b82f6", r: 4 }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Top Buyers */}
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
          <h2 className="text-white font-semibold mb-4">Top Buyers</h2>
          <div className="space-y-3">
            {topBuyers.map((b, i) => (
              <div key={b.name} className="flex items-center gap-3">
                <span className="text-slate-600 text-xs w-4 font-bold">{i + 1}</span>
                <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {b.name.split(" ").map(n => n[0]).join("")}
                </div>
                <div className="flex-1">
                  <p className="text-white text-sm">{b.name}</p>
                  <p className="text-slate-500 text-xs">{b.deals} deals</p>
                </div>
                <p className="text-amber-400 text-sm font-semibold">{b.volume}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}