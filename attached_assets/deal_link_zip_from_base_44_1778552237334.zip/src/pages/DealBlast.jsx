import { useState } from "react";
import { Zap, Building2, Users, Send, CheckCircle2, Shield, Star, ChevronRight } from "lucide-react";

const properties = [
  { id: 1, address: "1234 Oak Street", city: "Atlanta, GA", price: 85000, arv: 140000, beds: 3, baths: 2 },
  { id: 2, address: "7890 Cedar Ln", city: "Memphis, TN", price: 45000, arv: 89000, beds: 3, baths: 1 },
  { id: 3, address: "9012 Maple Dr", city: "Phoenix, AZ", price: 67000, arv: 110000, beds: 2, baths: 1 },
];

const aiMatches = [
  { id: 1, name: "James Carter", type: "Cash Buyer", score: 94, vip: true, vetted: true, reason: "Bought 3 SFR in Atlanta at $80-95k in last 90 days" },
  { id: 2, name: "Marcus Hill", type: "Landlord", score: 97, vip: true, vetted: true, reason: "Owns 22 rentals, actively buying in Atlanta metro" },
  { id: 3, name: "Angela White", type: "Flipper", score: 81, vip: false, vetted: true, reason: "Flipped 2 Atlanta SFRs, matches price range" },
  { id: 4, name: "Tanya Brooks", type: "Cash Buyer", score: 67, vip: false, vetted: false, reason: "New buyer, price range matches" },
  { id: 5, name: "Lucia Fernandez", type: "Wholesaler", score: 88, vip: false, vetted: true, reason: "Active in GA market, JV potential" },
  { id: 6, name: "Devon Ray", type: "Developer", score: 58, vip: false, vetted: true, reason: "Occasional SFR buyer in SE region" },
];

const scoreColor = s => s >= 90 ? "text-green-400" : s >= 70 ? "text-amber-400" : "text-red-400";

const dealTags = ["Turnkey", "Creative Financing", "Seller Financing", "Subject To", "Short Term Rental", "Portfolio"];
const financeOptions = ["Cash Only", "Creative Financing OK", "Seller Finance Available", "Subject To Available"];

export default function DealBlast() {
  const [step, setStep] = useState(1);
  const [selectedProp, setSelectedProp] = useState(null);
  const [selectedBuyers, setSelectedBuyers] = useState([1, 2, 3]);
  const [tags, setTags] = useState([]);
  const [finance, setFinance] = useState("Cash Only");
  const [blasted, setBlasted] = useState(false);

  const toggleBuyer = id => setSelectedBuyers(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  const toggleTag = t => setTags(prev => prev.includes(t) ? prev.filter(x => x !== t) : [...prev, t]);

  const handleBlast = () => { setBlasted(true); };

  if (blasted) {
    return (
      <div className="flex flex-col items-center justify-center min-h-96 space-y-4">
        <div className="w-20 h-20 rounded-full bg-green-400/20 flex items-center justify-center">
          <CheckCircle2 className="w-10 h-10 text-green-400" />
        </div>
        <h2 className="text-2xl font-bold text-white">Deal Blasted!</h2>
        <p className="text-slate-400 text-center max-w-sm">
          Your deal was sent to <span className="text-white font-semibold">{selectedBuyers.length} AI-matched buyers</span>. 
          Expect responses within 24–48 hours. Track engagement in Artemis Mode.
        </p>
        <button onClick={() => { setBlasted(false); setStep(1); setSelectedProp(null); }}
          className="bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold px-6 py-2.5 rounded-lg text-sm transition-colors">
          Blast Another Deal
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-white">AI Deal Blast</h1>
          <span className="text-xs bg-blue-400/20 text-blue-300 px-2 py-0.5 rounded-full font-medium border border-blue-400/30">AI Powered</span>
        </div>
        <p className="text-slate-400 text-sm mt-1">AI matches your deal to the most relevant buyers and sends it instantly</p>
      </div>

      {/* Steps */}
      <div className="flex items-center gap-2 text-sm">
        {["Select Deal", "Configure", "Review & Blast"].map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold
              ${step > i + 1 ? "bg-green-400 text-slate-900" : step === i + 1 ? "bg-amber-400 text-slate-900" : "bg-slate-700 text-slate-400"}`}>
              {step > i + 1 ? "✓" : i + 1}
            </div>
            <span className={step === i + 1 ? "text-white font-medium" : "text-slate-500"}>{s}</span>
            {i < 2 && <ChevronRight className="w-4 h-4 text-slate-600" />}
          </div>
        ))}
      </div>

      {/* Step 1: Pick deal */}
      {step === 1 && (
        <div className="space-y-3">
          <p className="text-slate-400 text-sm">Choose a property to blast:</p>
          {properties.map(p => (
            <button key={p.id} onClick={() => { setSelectedProp(p); setStep(2); }}
              className={`w-full text-left p-4 rounded-xl border transition-all flex items-center justify-between
                ${selectedProp?.id === p.id ? "bg-amber-400/10 border-amber-400" : "bg-slate-900 border-slate-700 hover:border-slate-500"}`}>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-slate-700 rounded-lg flex items-center justify-center">
                  <Building2 className="w-4 h-4 text-slate-400" />
                </div>
                <div>
                  <p className="text-white font-semibold text-sm">{p.address}</p>
                  <p className="text-slate-400 text-xs">{p.city} · {p.beds}bd/{p.baths}ba</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-white font-bold">${p.price.toLocaleString()}</p>
                <p className="text-green-400 text-xs">ARV ${p.arv.toLocaleString()}</p>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Step 2: Configure */}
      {step === 2 && (
        <div className="space-y-5">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-4">
            <p className="text-slate-400 text-xs mb-2 font-medium uppercase tracking-wider">Deal Tags</p>
            <div className="flex flex-wrap gap-2">
              {dealTags.map(t => (
                <button key={t} onClick={() => toggleTag(t)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border
                    ${tags.includes(t) ? "bg-amber-400/20 text-amber-300 border-amber-400/40" : "bg-slate-800 text-slate-400 border-slate-600 hover:border-slate-400"}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-4">
            <p className="text-slate-400 text-xs mb-2 font-medium uppercase tracking-wider">Financing Type</p>
            <div className="flex flex-wrap gap-2">
              {financeOptions.map(f => (
                <button key={f} onClick={() => setFinance(f)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border
                    ${finance === f ? "bg-blue-400/20 text-blue-300 border-blue-400/40" : "bg-slate-800 text-slate-400 border-slate-600 hover:border-slate-400"}`}>
                  {f}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep(1)} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors">Back</button>
            <button onClick={() => setStep(3)} className="flex-1 bg-amber-400 hover:bg-amber-300 text-slate-900 px-4 py-2.5 rounded-lg text-sm font-bold transition-colors">Continue →</button>
          </div>
        </div>
      )}

      {/* Step 3: Review & blast */}
      {step === 3 && (
        <div className="space-y-5">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold">AI-Matched Buyers</h3>
              <span className="text-slate-400 text-xs">{selectedBuyers.length} selected</span>
            </div>
            <div className="space-y-3">
              {aiMatches.map(b => (
                <div key={b.id} onClick={() => toggleBuyer(b.id)}
                  className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all
                    ${selectedBuyers.includes(b.id) ? "bg-amber-400/5 border-amber-400/30" : "bg-slate-800 border-slate-600 opacity-50"}`}>
                  <input type="checkbox" checked={selectedBuyers.includes(b.id)} onChange={() => {}} className="w-4 h-4 accent-amber-400" />
                  <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                    {b.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5">
                      <p className="text-white text-sm font-medium">{b.name}</p>
                      {b.vip && <span className="text-xs bg-amber-400/20 text-amber-300 px-1.5 py-0.5 rounded">VIP</span>}
                      {b.vetted && <Shield className="w-3 h-3 text-blue-400" />}
                    </div>
                    <p className="text-slate-500 text-xs">{b.reason}</p>
                  </div>
                  <span className={`font-bold text-sm ${scoreColor(b.score)}`}>{b.score}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep(2)} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors">Back</button>
            <button onClick={handleBlast} className="flex-1 bg-amber-400 hover:bg-amber-300 text-slate-900 px-5 py-2.5 rounded-lg text-sm font-bold transition-colors flex items-center justify-center gap-2">
              <Zap className="w-4 h-4" /> Blast to {selectedBuyers.length} Buyers
            </button>
          </div>
        </div>
      )}
    </div>
  );
}