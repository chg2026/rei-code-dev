import { Eye, Clock, Phone, TrendingUp, Star, Shield, Flame, ChevronDown } from "lucide-react";
import { useState } from "react";

const deals = [
  { id: 1, address: "1234 Oak Street", city: "Atlanta, GA", price: 85000, arv: 140000, views: 47, offers: 3 },
  { id: 2, address: "7890 Cedar Ln", city: "Memphis, TN", price: 45000, arv: 89000, views: 22, offers: 1 },
  { id: 3, address: "9012 Maple Dr", city: "Phoenix, AZ", price: 67000, arv: 110000, views: 31, offers: 0 },
];

const engagement = {
  1: [
    { name: "James Carter", type: "Cash Buyer", score: 94, vip: true, vetted: true, views: 8, timeSpent: "4m 32s", lastSeen: "2 hours ago", action: "Viewed photos, opened offer form" },
    { name: "Marcus Hill", type: "Landlord", score: 97, vip: true, vetted: true, views: 5, timeSpent: "2m 18s", lastSeen: "5 hours ago", action: "Viewed listing, checked comps" },
    { name: "Tanya Brooks", type: "Cash Buyer", score: 67, vip: false, vetted: false, views: 2, timeSpent: "0m 45s", lastSeen: "1 day ago", action: "Quick view" },
    { name: "Angela White", type: "Flipper", score: 81, vip: false, vetted: true, views: 4, timeSpent: "3m 10s", lastSeen: "3 hours ago", action: "Viewed photos + description" },
  ],
  2: [
    { name: "Sandra Lee", type: "Wholesaler", score: 72, vip: false, vetted: true, views: 6, timeSpent: "3m 05s", lastSeen: "4 hours ago", action: "Opened deal PDF" },
  ],
  3: [
    { name: "Derek Thompson", type: "Landlord", score: 88, vip: false, vetted: true, views: 9, timeSpent: "5m 22s", lastSeen: "1 hour ago", action: "Viewed multiple times, saved deal" },
    { name: "Kevin Brooks", type: "Developer", score: 76, vip: false, vetted: true, views: 3, timeSpent: "1m 50s", lastSeen: "6 hours ago", action: "Viewed listing" },
  ],
};

const scoreColor = s => s >= 90 ? "text-green-400" : s >= 70 ? "text-amber-400" : "text-red-400";
const heatColor = s => s >= 90 ? "text-red-400" : s >= 70 ? "text-amber-400" : "text-slate-400";

export default function ArtemisMode() {
  const [activeDeal, setActiveDeal] = useState(1);
  const viewers = engagement[activeDeal] || [];

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-white">Artemis Mode</h1>
          <span className="text-xs bg-purple-400/20 text-purple-300 px-2 py-0.5 rounded-full font-medium border border-purple-400/30">Enterprise</span>
        </div>
        <p className="text-slate-400 text-sm mt-1">See exactly who's viewing your deals and rank them by interest before they even submit an offer</p>
      </div>

      {/* Deal selector */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {deals.map(d => (
          <button key={d.id} onClick={() => setActiveDeal(d.id)}
            className={`text-left p-4 rounded-xl border transition-all ${activeDeal === d.id ? "bg-amber-400/10 border-amber-400" : "bg-slate-900 border-slate-700 hover:border-slate-500"}`}>
            <p className="text-white font-semibold text-sm">{d.address}</p>
            <p className="text-slate-400 text-xs">{d.city}</p>
            <div className="flex items-center gap-4 mt-3 text-xs">
              <span className="flex items-center gap-1 text-slate-300"><Eye className="w-3 h-3" />{d.views} views</span>
              <span className={`flex items-center gap-1 font-semibold ${d.offers > 0 ? "text-green-400" : "text-slate-500"}`}>
                {d.offers} offers
              </span>
            </div>
          </button>
        ))}
      </div>

      {/* Engagement table */}
      <div className="bg-slate-900 border border-slate-700 rounded-xl">
        <div className="px-5 py-4 border-b border-slate-700 flex items-center justify-between">
          <h2 className="text-white font-semibold">Buyer Engagement — {deals.find(d => d.id === activeDeal)?.address}</h2>
          <span className="text-slate-400 text-xs">{viewers.length} buyers engaged</span>
        </div>
        <div className="divide-y divide-slate-700">
          {viewers.sort((a, b) => b.score - a.score).map((v, i) => (
            <div key={i} className="px-5 py-4 flex flex-wrap items-center justify-between gap-4 hover:bg-slate-800/40 transition-colors">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center text-white font-bold text-sm">
                    {v.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  {i === 0 && <Flame className="w-4 h-4 text-red-400 absolute -top-1 -right-1" />}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-white text-sm font-medium">{v.name}</p>
                    {v.vip && <span className="text-xs bg-amber-400/20 text-amber-300 px-1.5 py-0.5 rounded font-medium">VIP</span>}
                    {v.vetted && <Shield className="w-3 h-3 text-blue-400" />}
                  </div>
                  <p className="text-slate-500 text-xs">{v.type} · {v.action}</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-center">
                  <p className="text-slate-400 text-xs">Views</p>
                  <p className="text-white font-semibold">{v.views}x</p>
                </div>
                <div className="text-center">
                  <p className="text-slate-400 text-xs">Time Spent</p>
                  <p className="text-white font-semibold">{v.timeSpent}</p>
                </div>
                <div className="text-center">
                  <p className="text-slate-400 text-xs">Last Seen</p>
                  <p className="text-slate-300 text-xs">{v.lastSeen}</p>
                </div>
                <div className="text-center">
                  <p className="text-slate-400 text-xs">Score</p>
                  <p className={`font-bold text-sm ${scoreColor(v.score)}`}>{v.score}</p>
                </div>
                <button className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-semibold px-3 py-1.5 rounded-lg text-xs transition-colors">
                  <Phone className="w-3 h-3" /> Call Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}